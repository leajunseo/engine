#include "Systems/BehaviorSystem.hpp"

#include <vector>

#include "Systems/StandardComponents.hpp"

namespace engine {

void UpdateBehaviors(Scene& scene, double dt) {
    static thread_local std::vector<Entity> snapshot;
    std::vector<Entity> list;
    list.swap(snapshot);                                   // 재진입(콜백 안에서 UpdateBehaviors) 시에도 안전하도록 소유권을 가져옴
    list.clear();
    scene.Each<Behavior>([&](Entity e, Behavior&) { list.push_back(e); });

    for (Entity e : list) {
        Behavior* b = scene.TryGet<Behavior>(e);           // 이전 콜백이 삭제했을 수 있음
        if (!b || !b->enabled) continue;
        if (!b->started) {
            b->started = true;
            auto start = b->onStart;                       // 복사: 콜백이 풀을 재할당해도 실행 중인 함수 객체는 유효
            if (start) start(e, scene);
            b = scene.TryGet<Behavior>(e);
            if (!b || !b->enabled) continue;
        }
        auto update = b->onUpdate;
        if (update) update(e, scene, dt);
    }
    list.clear();
    snapshot.swap(list);
}

} // namespace engine
