#pragma once
#include <cstddef>

#include "Renderer/SpriteBatch.hpp"
#include "Scene/Scene.hpp"

namespace engine {

/// Transform + SpriteRenderer 를 가진 모든 엔티티를 batch 에 제출 (Renderer::BeginScene ~ EndScene 사이에서 호출).
/// 위치/회전은 alpha 로 보간한 월드 값을 쓴다. 제출한 스프라이트 수를 반환.
std::size_t DrawSprites(Scene& scene, SpriteBatch& batch, float alpha);

} // namespace engine
