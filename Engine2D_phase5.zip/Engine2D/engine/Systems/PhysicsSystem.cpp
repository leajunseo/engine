#include "Systems/PhysicsSystem.hpp"

namespace engine {

PhysicsSystem::PhysicsSystem(Scene& scene, PhysicsWorld& world, EventBus& bus) : scene_(scene), world_(world) {
    subDestroyed_ = bus.Subscribe<EntityDestroyedEvent>([this](const EntityDestroyedEvent& ev) { DetachBody(ev.entity); });
    subBegin_ = bus.Subscribe<CollisionBeginEvent>([this, &bus](const CollisionBeginEvent& e) {
        const Entity a = EntityOf(e.a), b = EntityOf(e.b);
        if (a.Valid() && b.Valid()) bus.Publish(EntityCollisionBeginEvent{a, b, e.normal, e.point, e.depth, e.impactSpeed});
    });
    subEnd_ = bus.Subscribe<CollisionEndEvent>([this, &bus](const CollisionEndEvent& e) {
        const Entity a = EntityOf(e.a), b = EntityOf(e.b);
        if (a.Valid() && b.Valid()) bus.Publish(EntityCollisionEndEvent{a, b});
    });
    subEnter_ = bus.Subscribe<TriggerEnterEvent>([this, &bus](const TriggerEnterEvent& e) {
        const Entity s = EntityOf(e.sensor), o = EntityOf(e.other);
        if (s.Valid() && o.Valid()) bus.Publish(EntityTriggerEnterEvent{s, o});
    });
    subExit_ = bus.Subscribe<TriggerExitEvent>([this, &bus](const TriggerExitEvent& e) {
        const Entity s = EntityOf(e.sensor), o = EntityOf(e.other);
        if (s.Valid() && o.Valid()) bus.Publish(EntityTriggerExitEvent{s, o});
    });
}

void PhysicsSystem::Bind(BodyId id, Entity e) {
    if (id.index >= byBody_.size()) byBody_.resize(static_cast<std::size_t>(id.index) + 1);
    byBody_[id.index] = e;
}

BodyId PhysicsSystem::AttachBody(Entity e, BodyDef def) {
    if (!scene_.IsAlive(e)) return BodyId{};
    Transform* t = scene_.TryGet<Transform>(e);
    if (!t) return BodyId{};
    DetachBody(e);
    const bool root = !scene_.Parent(e).Valid();
    def.position = root ? t->position : t->WorldPosition();
    def.rotation = root ? t->rotation : t->WorldRotation();
    const BodyId id = world_.CreateBody(def);
    if (!id.Valid()) return BodyId{};
    scene_.Add<RigidBody>(e, RigidBody{id});
    Bind(id, e);
    return id;
}

void PhysicsSystem::DetachBody(Entity e) {
    RigidBody* rb = scene_.TryGet<RigidBody>(e);
    if (!rb) return;
    const BodyId id = rb->body;
    if (id.index < byBody_.size() && byBody_[id.index] == e) byBody_[id.index] = kNullEntity;
    world_.DestroyBody(id);
    scene_.Remove<RigidBody>(e);
}

BodyId PhysicsSystem::BodyOf(Entity e) const {
    const RigidBody* rb = scene_.TryGet<RigidBody>(e);
    return rb ? rb->body : BodyId{};
}

Entity PhysicsSystem::EntityOf(BodyId id) const {
    if (!id.Valid() || id.index >= byBody_.size()) return kNullEntity;
    const Entity e = byBody_[id.index];
    const RigidBody* rb = e.Valid() ? scene_.TryGet<RigidBody>(e) : nullptr;
    return (rb && rb->body == id) ? e : kNullEntity;
}

void PhysicsSystem::Teleport(Entity e, Vec2 worldPosition, float worldRotation) {
    Transform* t = scene_.TryGet<Transform>(e);
    if (!t) return;
    const Entity parent = scene_.Parent(e);
    const Transform* pt = parent.Valid() ? scene_.TryGet<Transform>(parent) : nullptr;
    if (pt && pt->world.Invertible()) {
        t->position = pt->world.Inverse().TransformPoint(worldPosition);
        t->rotation = worldRotation - pt->world.Rotation();
    } else {
        t->position = worldPosition;
        t->rotation = worldRotation;
    }
    t->hasPrev = false;
    const RigidBody* rb = scene_.TryGet<RigidBody>(e);
    if (rb) world_.SetTransform(rb->body, worldPosition, worldRotation);
}

void PhysicsSystem::SyncFromPhysics() {
    scene_.Each<RigidBody, Transform, Node>([&](Entity, RigidBody& rb, Transform& t, Node& n) {
        const Body* b = world_.Get(rb.body);
        if (!b || b->type == BodyType::Static) return;
        const Transform* pt = n.parent.Valid() ? scene_.TryGet<Transform>(n.parent) : nullptr;
        if (pt && pt->world.Invertible()) {
            t.position = pt->world.Inverse().TransformPoint(b->position);
            t.rotation = b->rotation - pt->world.Rotation();
        } else {
            t.position = b->position;
            t.rotation = b->rotation;
        }
    });
}

} // namespace engine
