#pragma once
// ---------------------------------------------------------------------------
// Scene <-> PhysicsWorld 연결.
//   * AttachBody: 엔티티에 물리 바디를 만들어 RigidBody 컴포넌트로 연결. 엔티티가 삭제되면 바디도 함께 삭제.
//   * SyncFromPhysics: world.Step 직후 Dynamic/Kinematic 바디의 위치/회전을 Transform 에 기록 (Static 은 건드리지 않음).
//   * 물리 이벤트(BodyId) -> 엔티티 이벤트로 번역해 같은 EventBus 로 재발행.
//
// 틱 순서:   scene.BeginTick(); UpdateBehaviors(); world.Step(dt); physicsSys.SyncFromPhysics();
//            scene.UpdateTransforms(); scene.FlushDestroyed();
//
// 제약: 물리 도형은 엔티티 스케일을 반영하지 않는다(BodyDef 의 도형 그대로). 바디를 가진 엔티티는 루트(부모 없음)로 두는 것을 권장
//   (자식이면 부모의 '직전 틱' 월드 행렬 기준으로 로컬 값을 역산하므로 부모가 움직이면 한 틱 늦다).
// ---------------------------------------------------------------------------
#include <vector>

#include "Core/EventBus.hpp"
#include "Physics/PhysicsWorld.hpp"
#include "Scene/Scene.hpp"
#include "Systems/StandardComponents.hpp"

namespace engine {

struct EntityCollisionBeginEvent { Entity a, b; Vec2 normal, point; float depth, impactSpeed; };
struct EntityCollisionEndEvent   { Entity a, b; };
struct EntityTriggerEnterEvent   { Entity sensor, other; };
struct EntityTriggerExitEvent    { Entity sensor, other; };

class PhysicsSystem {
public:
    /// world / scene / bus 는 PhysicsSystem 보다 오래 살아야 한다. world.SetEventBus(&bus) 도 호출되어 있어야 이벤트가 번역된다.
    PhysicsSystem(Scene& scene, PhysicsWorld& world, EventBus& bus);
    PhysicsSystem(const PhysicsSystem&)            = delete;
    PhysicsSystem& operator=(const PhysicsSystem&) = delete;

    /// def.position/rotation 은 엔티티의 현재 Transform 으로 덮어쓴다 (루트면 로컬 값, 자식이면 월드 값).
    /// 이미 바디가 있으면 기존 것을 먼저 제거. 반환: 새 BodyId (실패하면 무효 id).
    BodyId AttachBody(Entity e, BodyDef def);
    void   DetachBody(Entity e);
    BodyId BodyOf(Entity e) const;
    Entity EntityOf(BodyId id) const;                  // 없으면 kNullEntity

    /// 순간이동: 바디와 Transform 을 함께 옮기고 보간을 끊는다 (월드 좌표).
    void Teleport(Entity e, Vec2 worldPosition, float worldRotation);

    void SyncFromPhysics();

private:
    void Bind(BodyId id, Entity e);

    Scene&        scene_;
    PhysicsWorld& world_;
    std::vector<Entity> byBody_;                       // BodyId.index -> Entity
    Subscription  subDestroyed_, subBegin_, subEnd_, subEnter_, subExit_;
};

} // namespace engine
