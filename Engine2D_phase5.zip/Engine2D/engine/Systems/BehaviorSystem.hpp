#pragma once
#include "Scene/Scene.hpp"

namespace engine {

/// Behavior 컴포넌트의 onStart/onUpdate 실행 (고정 틱에서 호출). 실행 중 구조 변경 안전.
/// [Bottleneck] 콜백마다 std::function 복사 + 엔티티 스냅샷 벡터 -> 수천 개 이상의 Behavior 는 전용 컴포넌트/시스템으로 빼는 것이 낫다.
void UpdateBehaviors(Scene& scene, double dt);

} // namespace engine
