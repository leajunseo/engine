#pragma once
// 렌더러/물리/에셋과 Scene 을 이어주는 표준 컴포넌트. (Scene 모듈 자체는 이들을 몰라도 된다 - 의존 방향: Systems -> Scene/Physics/Renderer/Assets)
#include <functional>

#include "Assets/AssetManager.hpp"
#include "Math/Math.hpp"
#include "Physics/PhysicsWorld.hpp"
#include "Renderer/Texture.hpp"
#include "Scene/ECS.hpp"

namespace engine {

class Scene;

/// 스프라이트 그리기. 크기는 월드 스케일과 곱해진다 (스케일 음수 = 반전).
struct SpriteRenderer {
    const Texture* texture = nullptr;       // nullptr = 단색 사각형. asset 이 유효하면 asset 이 우선
    Asset<Texture> asset;                   // (선택) 에셋 핸들을 쥐어 수명을 보장. 핫 리로드된 텍스처도 같은 주소라 그대로 반영
    TextureRegion  region{};
    Vec2           size{32.0f, 32.0f};
    Vec2           origin{0.5f, 0.5f};
    Color          color{};
    int            layer = 0;
    bool           flipX = false, flipY = false;
    bool           visible = true;

    void SetTexture(const Asset<Texture>& a) { asset = a; texture = a.Get(); }
    const Texture* ResolveTexture() const { return asset.IsValid() ? asset.Get() : texture; }
};

/// 물리 바디 연결 (PhysicsSystem::AttachBody 가 붙인다).
struct RigidBody { BodyId body; };

/// 간단한 스크립트 슬롯. onStart 는 첫 업데이트 직전에 1회, onUpdate 는 매 고정 틱마다.
/// 콜백 안에서 엔티티 생성/삭제/컴포넌트 추가를 해도 안전 (UpdateBehaviors 가 스냅샷을 순회).
struct Behavior {
    std::function<void(Entity, Scene&)>         onStart;
    std::function<void(Entity, Scene&, double)> onUpdate;
    bool enabled = true;
    bool started = false;
};

} // namespace engine
