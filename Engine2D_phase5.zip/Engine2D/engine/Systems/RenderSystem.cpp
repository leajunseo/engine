#include "Systems/RenderSystem.hpp"

#include <cmath>

#include "Systems/StandardComponents.hpp"

namespace engine {

std::size_t DrawSprites(Scene& scene, SpriteBatch& batch, float alpha) {
    std::size_t n = 0;
    scene.Each<Transform, SpriteRenderer>([&](Entity, Transform& t, SpriteRenderer& sr) {
        if (!sr.visible) return;
        const Vec2 sc = t.WorldScale();
        Sprite s;
        s.texture  = sr.ResolveTexture();
        s.region   = sr.region;
        s.position = t.InterpolatedPosition(alpha);
        s.rotation = t.InterpolatedRotation(alpha);
        s.size     = {sr.size.x * std::fabs(sc.x), sr.size.y * std::fabs(sc.y)};
        s.origin   = sr.origin;
        s.color    = sr.color;
        s.layer    = sr.layer;
        s.flipX    = sr.flipX != (sc.x < 0.0f);
        s.flipY    = sr.flipY != (sc.y < 0.0f);
        batch.Draw(s);
        ++n;
    });
    return n;
}

} // namespace engine
