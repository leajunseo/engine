#pragma once
// ---------------------------------------------------------------------------
// AssetManager: 키(보통 파일 경로) -> 에셋 캐시 + 레퍼런스 카운팅 + 핫 리로드.
//
//   auto tex  = assets.LoadTexture("player.bmp");            // 같은 경로를 또 부르면 캐시된 같은 객체
//   auto blob = assets.Load<Blob>("data/level1.bin");
//   auto proc = assets.Add<Texture>("white", std::move(t));   // 파일 없는 절차적 에셋 등록
//   Sprite s; s.texture = tex.Get();                          // 엔진 API 에는 원시 포인터를 넘긴다
//
// 수명 / 레퍼런스 카운팅
//  * Asset<T> 핸들은 복사 가능한 shared_ptr 래퍼. 매니저도 1개의 참조를 가진다.
//    -> 핸들이 모두 사라져도 에셋은 캐시에 남아 있다(다시 Load 하면 즉시 반환).
//       CollectUnused() 를 부르면 아무도 안 쓰는 에셋만 해제한다 (씬 전환 시점에 호출하면 좋다).
//  * Clear() 는 모든 에셋의 실제 데이터(GL 텍스처 등)를 '지금' 파괴한다. 남아있는 핸들은 안전하게 비어있는 상태가 된다
//    (Get() == nullptr). Application 이 GL 컨텍스트 파괴 전에 Clear() 를 호출하므로, 핸들을 보관하는 쪽은 신경 쓸 필요 없음.
//
// 핫 리로드
//  * ReloadChanged() 가 파일 수정 시각을 비교해 바뀐 에셋을 다시 읽는다. T 가 move-assignable(Texture, Blob 등)이면
//    '같은 주소'에 덮어쓰므로 Sprite::texture 같은 원시 포인터가 그대로 유효하다. 읽기에 실패하면 이전 데이터를 유지한다.
//
// 스레딩: 메인(GL) 스레드 전용. GL 객체를 만드는 로더(Texture)는 반드시 GL 컨텍스트가 current 인 스레드에서 호출.
// [Bottleneck] 로딩은 동기 I/O + 디코딩이라 큰 이미지를 읽는 프레임에 끊김이 생긴다. 비동기 로딩은 후속 단계
//   (워커 스레드에서 ImageData 디코딩 -> 메인 스레드에서 Texture 업로드)에서 추가.
// ---------------------------------------------------------------------------
#include <cstddef>
#include <cstdint>
#include <filesystem>
#include <functional>
#include <memory>
#include <string>
#include <type_traits>
#include <unordered_map>
#include <utility>
#include <vector>

#include "Assets/ImageLoader.hpp"
#include "Core/Log.hpp"
#include "Renderer/Texture.hpp"

namespace engine {

/// 파일 내용 그대로 (바이너리/데이터 에셋)
struct Blob { std::vector<std::uint8_t> bytes; };
/// UTF-8 텍스트 파일
struct TextAsset { std::string text; };

namespace detail {

inline std::size_t NextAssetTypeId() { static std::size_t counter = 0; return counter++; }
template <class T> std::size_t AssetTypeId() { static const std::size_t id = NextAssetTypeId(); return id; }

template <class T>
struct AssetEntry {
    std::string key;
    std::string fullPath;                                    // 파일 에셋이면 해석된 경로
    std::unique_ptr<T> value;
    std::function<std::unique_ptr<T>()> reload;              // 비어있으면 리로드 불가 (절차적 에셋)
    std::filesystem::file_time_type stamp{};
    std::uint32_t version = 1;                               // 리로드될 때마다 증가
};

struct IAssetStore {
    virtual ~IAssetStore() = default;
    virtual void Clear() = 0;
    virtual std::size_t CollectUnused() = 0;
    virtual std::size_t ReloadChanged() = 0;
    virtual std::size_t Count() const = 0;
};

} // namespace detail

/// 에셋 핸들 (복사 가능, 참조 카운트). 비어있거나 Clear() 된 뒤에는 Get() == nullptr.
template <class T>
class Asset {
public:
    Asset() = default;
    T*   Get() const        { return entry_ ? entry_->value.get() : nullptr; }
    T*   operator->() const { return Get(); }
    T&   operator*() const  { return *Get(); }
    bool IsValid() const    { return Get() != nullptr; }
    explicit operator bool() const { return IsValid(); }
    const std::string& Key() const { static const std::string empty; return entry_ ? entry_->key : empty; }
    std::uint32_t Version() const  { return entry_ ? entry_->version : 0; }   // 리로드 감지용
    /// 이 에셋을 쥔 핸들 수 (매니저의 캐시 참조 제외)
    long UseCount() const   { return entry_ ? entry_.use_count() - 1 : 0; }
    void Reset()            { entry_.reset(); }
    bool operator==(const Asset& o) const { return entry_ == o.entry_; }
    bool operator!=(const Asset& o) const { return entry_ != o.entry_; }

private:
    friend class AssetManager;
    explicit Asset(std::shared_ptr<detail::AssetEntry<T>> e) : entry_(std::move(e)) {}
    std::shared_ptr<detail::AssetEntry<T>> entry_;
};

class AssetManager {
public:
    AssetManager();                                          // Texture / ImageData / Blob / TextAsset 로더 등록
    ~AssetManager() { Clear(); }
    AssetManager(const AssetManager&)            = delete;
    AssetManager& operator=(const AssetManager&) = delete;

    /// 상대 경로를 root 기준으로 해석 (절대 경로는 그대로). 빈 문자열이면 현재 작업 폴더.
    void SetRoot(std::string root) { root_ = std::move(root); }
    const std::string& Root() const { return root_; }
    std::string Resolve(const std::string& path) const;

    template <class T> using Loader = std::function<std::unique_ptr<T>(const std::string& fullPath)>;
    template <class T> void RegisterLoader(Loader<T> loader) { Typed<T>().loader = std::move(loader); }

    /// 캐시에 있으면 반환, 없으면 등록된 로더로 읽어서 캐시. 실패하면 빈 핸들(+에러 로그).
    template <class T> Asset<T> Load(const std::string& path);
    /// 로드 없이 캐시에서만 찾음. 없으면 빈 핸들.
    template <class T> Asset<T> Get(const std::string& key) const;
    /// 이미 만들어진 객체를 키로 등록 (절차적 에셋). 같은 키가 있으면 기존 핸들을 반환하고 새 객체는 버린다.
    template <class T> Asset<T> Add(const std::string& key, std::unique_ptr<T> value);
    template <class T> bool     Contains(const std::string& key) const { return Get<T>(key).IsValid(); }

    /// 텍스처 로드 (필터/랩 지정). 캐시 키 = 경로 이므로 이미 캐시된 경우 필터 인자는 무시된다.
    Asset<Texture> LoadTexture(const std::string& path, TextureFilter filter = TextureFilter::Nearest,
                               TextureWrap wrap = TextureWrap::Clamp);

    /// 핸들이 하나도 없는 에셋 해제. 해제한 개수 반환.
    std::size_t CollectUnused();
    /// 파일이 바뀐 에셋 다시 읽기. 다시 읽은 개수 반환 (프레임당 한 번 또는 1초마다 호출하면 충분).
    std::size_t ReloadChanged();
    /// 모든 에셋 데이터를 즉시 파괴 (GL 컨텍스트 파괴 전에 호출).
    void Clear();

    std::size_t Count() const;                               // 캐시된 에셋 총 개수

private:
    template <class T>
    struct Store final : detail::IAssetStore {
        using Entry = detail::AssetEntry<T>;
        std::unordered_map<std::string, std::shared_ptr<Entry>> map;
        Loader<T> loader;

        void Clear() override {
            for (auto& kv : map) kv.second->value.reset();   // 핸들이 남아있어도 데이터는 여기서 파괴
            map.clear();
        }
        std::size_t CollectUnused() override {
            std::size_t n = 0;
            for (auto it = map.begin(); it != map.end();) {
                if (it->second.use_count() == 1) { it->second->value.reset(); it = map.erase(it); ++n; }
                else ++it;
            }
            return n;
        }
        std::size_t ReloadChanged() override {
            std::size_t n = 0;
            for (auto& kv : map) {
                Entry& e = *kv.second;
                if (!e.reload || e.fullPath.empty()) continue;
                std::error_code ec;
                const auto stamp = std::filesystem::last_write_time(e.fullPath, ec);
                if (ec || stamp == e.stamp) continue;
                e.stamp = stamp;                              // 실패해도 같은 수정본을 매 프레임 재시도하지 않음
                std::unique_ptr<T> fresh = e.reload();
                if (!fresh) { ENGINE_LOG_WARN("Asset reload failed, keeping old data: %s", e.key.c_str()); continue; }
                if constexpr (std::is_move_assignable_v<T>) {
                    if (e.value) *e.value = std::move(*fresh);   // 같은 주소 유지
                    else e.value = std::move(fresh);
                } else {
                    e.value = std::move(fresh);                  // 주소가 바뀜 (원시 포인터를 캐시했다면 갱신 필요)
                }
                ++e.version;
                ++n;
                ENGINE_LOG_INFO("Asset reloaded: %s", e.key.c_str());
            }
            return n;
        }
        std::size_t Count() const override { return map.size(); }
    };

    template <class T> Store<T>& Typed() {
        const std::size_t id = detail::AssetTypeId<T>();
        if (id >= stores_.size()) stores_.resize(id + 1);
        if (!stores_[id]) stores_[id] = std::make_unique<Store<T>>();
        return static_cast<Store<T>&>(*stores_[id]);
    }
    template <class T> const Store<T>* FindTyped() const {
        const std::size_t id = detail::AssetTypeId<T>();
        if (id >= stores_.size() || !stores_[id]) return nullptr;
        return static_cast<const Store<T>*>(stores_[id].get());
    }
    template <class T>
    Asset<T> Insert(const std::string& key, std::unique_ptr<T> value, const std::string& fullPath,
                    std::function<std::unique_ptr<T>()> reload);

    std::string root_;
    std::vector<std::unique_ptr<detail::IAssetStore>> stores_;
};

// ---------------------------------------------------------------- 템플릿 구현
template <class T>
Asset<T> AssetManager::Insert(const std::string& key, std::unique_ptr<T> value, const std::string& fullPath,
                              std::function<std::unique_ptr<T>()> reload) {
    Store<T>& store = Typed<T>();
    auto entry = std::make_shared<detail::AssetEntry<T>>();
    entry->key = key;
    entry->fullPath = fullPath;
    entry->value = std::move(value);
    entry->reload = std::move(reload);
    if (!fullPath.empty()) {
        std::error_code ec;
        entry->stamp = std::filesystem::last_write_time(fullPath, ec);
    }
    store.map[key] = entry;
    return Asset<T>(std::move(entry));
}

template <class T>
Asset<T> AssetManager::Get(const std::string& key) const {
    const Store<T>* store = FindTyped<T>();
    if (!store) return {};
    auto it = store->map.find(key);
    return it == store->map.end() ? Asset<T>{} : Asset<T>(it->second);
}

template <class T>
Asset<T> AssetManager::Add(const std::string& key, std::unique_ptr<T> value) {
    if (Asset<T> existing = Get<T>(key)) {
        ENGINE_LOG_WARN("Asset '%s' already exists; keeping the existing one", key.c_str());
        return existing;
    }
    if (!value) return {};
    return Insert<T>(key, std::move(value), std::string{}, nullptr);
}

template <class T>
Asset<T> AssetManager::Load(const std::string& path) {
    if (Asset<T> cached = Get<T>(path)) return cached;
    Store<T>& store = Typed<T>();
    if (!store.loader) {
        ENGINE_LOG_ERROR("No loader registered for asset type (loading '%s')", path.c_str());
        return {};
    }
    const std::string full = Resolve(path);
    Loader<T> loader = store.loader;                        // 리로드 클로저가 복사본을 쥔다 (RegisterLoader 가 나중에 바뀌어도 안전)
    std::unique_ptr<T> value = loader(full);
    if (!value) { ENGINE_LOG_ERROR("Failed to load asset '%s'", full.c_str()); return {}; }
    return Insert<T>(path, std::move(value), full, [loader, full]() { return loader(full); });
}

} // namespace engine
