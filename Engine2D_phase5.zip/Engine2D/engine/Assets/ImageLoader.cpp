#include "Assets/ImageLoader.hpp"

#include <algorithm>
#include <cstdio>
#include <cstring>

#include "Core/Log.hpp"

#ifdef ENGINE_HAS_STB
  #define STB_IMAGE_IMPLEMENTATION
  #define STBI_NO_STDIO
  #include <stb_image.h>
#endif

namespace engine {
namespace {

std::uint16_t U16(const std::uint8_t* p) { return static_cast<std::uint16_t>(p[0] | (p[1] << 8)); }
std::uint32_t U32(const std::uint8_t* p) {
    return static_cast<std::uint32_t>(p[0]) | (static_cast<std::uint32_t>(p[1]) << 8) |
           (static_cast<std::uint32_t>(p[2]) << 16) | (static_cast<std::uint32_t>(p[3]) << 24);
}
std::int32_t I32(const std::uint8_t* p) { return static_cast<std::int32_t>(U32(p)); }

bool SizeOk(std::int64_t w, std::int64_t h) { return w > 0 && h > 0 && w <= kMaxImageSize && h <= kMaxImageSize; }

void Alloc(ImageData& img, int w, int h) {
    img.width = w; img.height = h;
    img.rgba.assign(static_cast<std::size_t>(w) * static_cast<std::size_t>(h) * 4u, 0);
}

// ---------------------------------------------------------------- BMP
bool DecodeBMP(const std::uint8_t* d, std::size_t n, ImageData& out) {
    if (n < 54) return false;
    const std::uint32_t dataOffset = U32(d + 10);
    const std::uint32_t headerSize = U32(d + 14);
    if (headerSize < 40 || 14u + headerSize > n) return false;
    const std::int64_t w = I32(d + 18);
    std::int64_t h = I32(d + 22);
    const bool topDown = h < 0;
    if (topDown) h = -h;
    const unsigned planes = U16(d + 26), bpp = U16(d + 28);
    const std::uint32_t compression = U32(d + 30);
    if (planes != 1 || !SizeOk(w, h)) return false;
    if (!(compression == 0 || (compression == 3 && bpp == 32))) return false;   // BI_RGB, 또는 32bpp BI_BITFIELDS(BGRA 가정)
    if (bpp != 8 && bpp != 24 && bpp != 32) return false;

    // 팔레트 (8bpp)
    std::uint32_t palette[256] = {};
    if (bpp == 8) {
        std::uint32_t colors = U32(d + 46);
        if (colors == 0 || colors > 256) colors = 256;
        const std::size_t palPos = 14u + headerSize;
        if (palPos + static_cast<std::size_t>(colors) * 4u > n) return false;
        for (std::uint32_t i = 0; i < colors; ++i) palette[i] = U32(d + palPos + i * 4u);
    }

    const std::size_t rowBytes = ((static_cast<std::size_t>(w) * bpp + 31u) / 32u) * 4u;
    if (dataOffset > n || rowBytes * static_cast<std::size_t>(h) > n - dataOffset) return false;

    Alloc(out, static_cast<int>(w), static_cast<int>(h));
    bool anyAlpha = false;
    for (int y = 0; y < h; ++y) {
        const int dstY = topDown ? y : static_cast<int>(h) - 1 - y;
        const std::uint8_t* src = d + dataOffset + rowBytes * static_cast<std::size_t>(y);
        std::uint8_t* dst = &out.rgba[static_cast<std::size_t>(dstY) * static_cast<std::size_t>(w) * 4u];
        for (int x = 0; x < w; ++x) {
            std::uint8_t r, g, b, a = 255;
            if (bpp == 8) { const std::uint32_t c = palette[src[x]]; b = static_cast<std::uint8_t>(c); g = static_cast<std::uint8_t>(c >> 8); r = static_cast<std::uint8_t>(c >> 16); }
            else if (bpp == 24) { b = src[x * 3]; g = src[x * 3 + 1]; r = src[x * 3 + 2]; }
            else { b = src[x * 4]; g = src[x * 4 + 1]; r = src[x * 4 + 2]; a = src[x * 4 + 3]; if (a) anyAlpha = true; }
            dst[x * 4] = r; dst[x * 4 + 1] = g; dst[x * 4 + 2] = b; dst[x * 4 + 3] = a;
        }
    }
    if (bpp == 32 && !anyAlpha)                                // 알파 채널이 쓰이지 않는 32bpp BMP -> 불투명
        for (std::size_t i = 3; i < out.rgba.size(); i += 4) out.rgba[i] = 255;
    return true;
}

// ---------------------------------------------------------------- TGA
bool LooksLikeTGA(const std::uint8_t* d, std::size_t n) {
    if (n < 18) return false;
    const unsigned colorMapType = d[1], type = d[2], bpp = d[16];
    if (colorMapType != 0) return false;
    if (type != 2 && type != 3 && type != 10 && type != 11) return false;
    if (type == 3 || type == 11) { if (bpp != 8) return false; }
    else if (bpp != 24 && bpp != 32) return false;
    return U16(d + 12) > 0 && U16(d + 14) > 0;
}

bool DecodeTGA(const std::uint8_t* d, std::size_t n, ImageData& out) {
    if (!LooksLikeTGA(d, n)) return false;
    const unsigned idLen = d[0], type = d[2], bpp = d[16], desc = d[17];
    const int w = U16(d + 12), h = U16(d + 14);
    if (!SizeOk(w, h)) return false;
    const bool rle = type >= 9, gray = (type == 3 || type == 11), topOrigin = (desc & 0x20) != 0;
    const std::size_t bytesPP = bpp / 8u;
    std::size_t pos = 18u + idLen;
    if (pos > n) return false;

    const std::size_t pixels = static_cast<std::size_t>(w) * static_cast<std::size_t>(h);
    std::vector<std::uint8_t> raw(pixels * bytesPP);
    if (!rle) {
        if (raw.size() > n - pos) return false;
        std::memcpy(raw.data(), d + pos, raw.size());
    } else {
        std::size_t outPos = 0;
        while (outPos < raw.size()) {
            if (pos >= n) return false;
            const unsigned hdr = d[pos++];
            const std::size_t count = (hdr & 0x7Fu) + 1u;
            const std::size_t bytes = std::min(count * bytesPP, raw.size() - outPos);
            if (hdr & 0x80u) {                                   // 반복 패킷
                if (pos + bytesPP > n) return false;
                for (std::size_t i = 0; i < bytes; i += bytesPP) std::memcpy(&raw[outPos + i], d + pos, std::min(bytesPP, bytes - i));
                pos += bytesPP;
            } else {                                             // 리터럴 패킷
                if (count * bytesPP > n - pos) return false;
                std::memcpy(&raw[outPos], d + pos, bytes);
                pos += count * bytesPP;
            }
            outPos += bytes;
        }
    }

    Alloc(out, w, h);
    for (int y = 0; y < h; ++y) {
        const int dstY = topOrigin ? y : h - 1 - y;
        const std::uint8_t* src = &raw[static_cast<std::size_t>(y) * static_cast<std::size_t>(w) * bytesPP];
        std::uint8_t* dst = &out.rgba[static_cast<std::size_t>(dstY) * static_cast<std::size_t>(w) * 4u];
        for (int x = 0; x < w; ++x) {
            const std::uint8_t* s = src + static_cast<std::size_t>(x) * bytesPP;
            if (gray) { dst[x * 4] = dst[x * 4 + 1] = dst[x * 4 + 2] = s[0]; dst[x * 4 + 3] = 255; }
            else { dst[x * 4] = s[2]; dst[x * 4 + 1] = s[1]; dst[x * 4 + 2] = s[0]; dst[x * 4 + 3] = bytesPP == 4 ? s[3] : 255; }
        }
    }
    return true;
}

} // namespace

bool ImageLoaderHasStb() {
#ifdef ENGINE_HAS_STB
    return true;
#else
    return false;
#endif
}

bool DecodeImageBuiltin(const std::uint8_t* data, std::size_t size, ImageData& out) {
    out = ImageData{};
    if (!data || size < 4) return false;
    const bool ok = (data[0] == 'B' && data[1] == 'M') ? DecodeBMP(data, size, out) : DecodeTGA(data, size, out);
    if (!ok || !out.Valid()) { out = ImageData{}; return false; }
    return true;
}

bool DecodeImage(const std::uint8_t* data, std::size_t size, ImageData& out) {
    out = ImageData{};
    if (!data || size < 4) return false;
#ifdef ENGINE_HAS_STB
    if (!(data[0] == 'B' && data[1] == 'M')) {                    // BMP 는 내장 디코더(행 패딩/알파 처리 규약을 통일), 나머지는 stb
        int w = 0, h = 0, comp = 0;
        stbi_uc* px = stbi_load_from_memory(data, static_cast<int>(std::min<std::size_t>(size, 0x7FFFFFFFu)), &w, &h, &comp, 4);
        if (px) {
            bool ok = false;
            if (SizeOk(w, h)) {
                Alloc(out, w, h);
                std::memcpy(out.rgba.data(), px, out.rgba.size());
                ok = true;
            }
            stbi_image_free(px);
            if (ok) return true;
            out = ImageData{};
            return false;
        }
    }
#endif
    return DecodeImageBuiltin(data, size, out);                   // BMP, 또는 stb 가 거부/없는 경우의 TGA
}

bool LoadImageFile(const std::string& path, ImageData& out) {
    out = ImageData{};
    std::FILE* f = std::fopen(path.c_str(), "rb");
    if (!f) { ENGINE_LOG_ERROR("Image: cannot open '%s'", path.c_str()); return false; }
    std::vector<std::uint8_t> bytes;
    std::uint8_t buf[64 * 1024];
    std::size_t got;
    while ((got = std::fread(buf, 1, sizeof(buf), f)) > 0) {
        bytes.insert(bytes.end(), buf, buf + got);
        if (bytes.size() > 512u * 1024u * 1024u) { std::fclose(f); ENGINE_LOG_ERROR("Image: '%s' is too large", path.c_str()); return false; }
    }
    std::fclose(f);
    if (!DecodeImage(bytes.data(), bytes.size(), out)) {
        ENGINE_LOG_ERROR("Image: unsupported or corrupt file '%s'%s", path.c_str(),
                         ImageLoaderHasStb() ? "" : " (PNG/JPG need stb: see README)");
        return false;
    }
    return true;
}

std::vector<std::uint8_t> EncodeBMP(int width, int height, const std::uint8_t* rgba) {
    std::vector<std::uint8_t> out;
    if (width <= 0 || height <= 0 || !rgba) return out;
    const std::uint32_t pixelBytes = static_cast<std::uint32_t>(width) * static_cast<std::uint32_t>(height) * 4u;
    const std::uint32_t total = 54u + pixelBytes;
    out.resize(total, 0);
    auto put32 = [&](std::size_t at, std::uint32_t v) { for (int i = 0; i < 4; ++i) out[at + static_cast<std::size_t>(i)] = static_cast<std::uint8_t>(v >> (8 * i)); };
    auto put16 = [&](std::size_t at, std::uint16_t v) { out[at] = static_cast<std::uint8_t>(v); out[at + 1] = static_cast<std::uint8_t>(v >> 8); };
    out[0] = 'B'; out[1] = 'M';
    put32(2, total); put32(10, 54);
    put32(14, 40); put32(18, static_cast<std::uint32_t>(width)); put32(22, static_cast<std::uint32_t>(-height));   // 음수 높이 = 위->아래
    put16(26, 1); put16(28, 32); put32(30, 0); put32(34, pixelBytes);
    for (std::size_t i = 0; i < static_cast<std::size_t>(width) * static_cast<std::size_t>(height); ++i) {
        out[54 + i * 4]     = rgba[i * 4 + 2];
        out[54 + i * 4 + 1] = rgba[i * 4 + 1];
        out[54 + i * 4 + 2] = rgba[i * 4];
        out[54 + i * 4 + 3] = rgba[i * 4 + 3];
    }
    return out;
}

bool SaveBMP(const std::string& path, int width, int height, const std::uint8_t* rgba) {
    const std::vector<std::uint8_t> bytes = EncodeBMP(width, height, rgba);
    if (bytes.empty()) return false;
    std::FILE* f = std::fopen(path.c_str(), "wb");
    if (!f) return false;
    const bool ok = std::fwrite(bytes.data(), 1, bytes.size(), f) == bytes.size();
    std::fclose(f);
    return ok;
}

} // namespace engine
