#include "Assets/AssetManager.hpp"

#include <cstdio>

namespace engine {
namespace {

bool ReadWholeFile(const std::string& path, std::vector<std::uint8_t>& out) {
    std::FILE* f = std::fopen(path.c_str(), "rb");
    if (!f) return false;
    std::uint8_t buf[64 * 1024];
    std::size_t got;
    out.clear();
    while ((got = std::fread(buf, 1, sizeof(buf), f)) > 0) out.insert(out.end(), buf, buf + got);
    std::fclose(f);
    return true;
}

std::unique_ptr<Texture> MakeTexture(const std::string& fullPath, TextureFilter filter, TextureWrap wrap) {
    ImageData img;
    if (!LoadImageFile(fullPath, img)) return nullptr;
    auto tex = std::make_unique<Texture>();
    if (!tex->Create(img.width, img.height, img.rgba.data(), filter, wrap)) return nullptr;
    return tex;
}

} // namespace

AssetManager::AssetManager() {
    RegisterLoader<Texture>([](const std::string& p) { return MakeTexture(p, TextureFilter::Nearest, TextureWrap::Clamp); });
    RegisterLoader<ImageData>([](const std::string& p) -> std::unique_ptr<ImageData> {
        auto img = std::make_unique<ImageData>();
        if (!LoadImageFile(p, *img)) return nullptr;
        return img;
    });
    RegisterLoader<Blob>([](const std::string& p) -> std::unique_ptr<Blob> {
        auto b = std::make_unique<Blob>();
        if (!ReadWholeFile(p, b->bytes)) return nullptr;
        return b;
    });
    RegisterLoader<TextAsset>([](const std::string& p) -> std::unique_ptr<TextAsset> {
        std::vector<std::uint8_t> bytes;
        if (!ReadWholeFile(p, bytes)) return nullptr;
        auto t = std::make_unique<TextAsset>();
        std::size_t skip = (bytes.size() >= 3 && bytes[0] == 0xEF && bytes[1] == 0xBB && bytes[2] == 0xBF) ? 3 : 0;   // UTF-8 BOM 제거
        t->text.assign(reinterpret_cast<const char*>(bytes.data()) + skip, bytes.size() - skip);
        return t;
    });
}

std::string AssetManager::Resolve(const std::string& path) const {
    if (root_.empty()) return path;
    const std::filesystem::path p(path);
    if (p.is_absolute()) return path;
    return (std::filesystem::path(root_) / p).string();
}

Asset<Texture> AssetManager::LoadTexture(const std::string& path, TextureFilter filter, TextureWrap wrap) {
    if (Asset<Texture> cached = Get<Texture>(path)) return cached;
    const std::string full = Resolve(path);
    std::unique_ptr<Texture> tex = MakeTexture(full, filter, wrap);
    if (!tex) { ENGINE_LOG_ERROR("Failed to load texture '%s'", full.c_str()); return {}; }
    return Insert<Texture>(path, std::move(tex), full, [full, filter, wrap]() { return MakeTexture(full, filter, wrap); });
}

std::size_t AssetManager::CollectUnused() {
    std::size_t n = 0;
    for (auto& s : stores_) if (s) n += s->CollectUnused();
    return n;
}
std::size_t AssetManager::ReloadChanged() {
    std::size_t n = 0;
    for (auto& s : stores_) if (s) n += s->ReloadChanged();
    return n;
}
void AssetManager::Clear() {
    for (auto& s : stores_) if (s) s->Clear();
}
std::size_t AssetManager::Count() const {
    std::size_t n = 0;
    for (const auto& s : stores_) if (s) n += s->Count();
    return n;
}

} // namespace engine
