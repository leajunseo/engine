#pragma once
// ---------------------------------------------------------------------------
// 이미지 디코더 (CPU 전용, GL 불필요).
//   기본 내장 : BMP (8/24/32bpp 비압축), TGA (8/24/32bpp, 비압축 + RLE)  -> 외부 의존성 없음
//   stb_image : CMake 가 stb 헤더를 찾으면 ENGINE_HAS_STB 가 정의되어 PNG/JPG/GIF/... 도 지원
// 출력은 항상 RGBA8, 첫 행 = 이미지 맨 위 (Texture::Create 와 같은 규약).
// 손상/악의적인 파일에 대비해 모든 읽기를 경계 검사하고 크기 상한(kMaxImageSize)을 둔다.
// ---------------------------------------------------------------------------
#include <cstddef>
#include <cstdint>
#include <string>
#include <vector>

namespace engine {

struct ImageData {
    int width = 0, height = 0;
    std::vector<std::uint8_t> rgba;           // width * height * 4
    bool Valid() const { return width > 0 && height > 0 && rgba.size() == static_cast<std::size_t>(width) * static_cast<std::size_t>(height) * 4u; }
};

constexpr int kMaxImageSize = 16384;

/// 메모리의 파일 내용을 디코딩. 형식은 내용(매직 넘버/헤더)으로 판별. 실패하면 false (out 은 비워짐).
bool DecodeImage(const std::uint8_t* data, std::size_t size, ImageData& out);
/// stb 없이 내장 디코더(BMP/TGA)만 사용. stb 가 연결된 빌드에서도 내장 경로를 직접 검증/사용할 때.
bool DecodeImageBuiltin(const std::uint8_t* data, std::size_t size, ImageData& out);
bool LoadImageFile(const std::string& path, ImageData& out);

/// 32bpp BMP (BGRA, 위->아래 저장) 로 인코딩. 스크린샷 저장/디버그/테스트용.
std::vector<std::uint8_t> EncodeBMP(int width, int height, const std::uint8_t* rgba);
bool SaveBMP(const std::string& path, int width, int height, const std::uint8_t* rgba);

/// 이 빌드에서 PNG/JPG 를 읽을 수 있는가 (stb 연결 여부)
bool ImageLoaderHasStb();

} // namespace engine
