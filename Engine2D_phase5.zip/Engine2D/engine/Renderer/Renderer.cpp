#include "Renderer/Renderer.hpp"

#include <GL/glew.h>

#include "Core/Assert.hpp"
#include "Core/Log.hpp"
#include "Core/Window.hpp"
#include "Renderer/Camera2D.hpp"

namespace engine {
namespace {

#if defined(ENGINE_DEBUG)
void GLAPIENTRY GLDebugCallback(GLenum /*source*/, GLenum type, GLuint id, GLenum severity,
                              GLsizei /*length*/, const GLchar* message, const void* /*user*/) {
    if (severity == GL_DEBUG_SEVERITY_NOTIFICATION) return;
    const bool isError = (type == GL_DEBUG_TYPE_ERROR) || (severity == GL_DEBUG_SEVERITY_HIGH);
    if (isError) ENGINE_LOG_ERROR("[GL %u] %s", id, message);
    else         ENGINE_LOG_WARN("[GL %u] %s", id, message);
}
#endif

const char* GLString(GLenum name) {
    const GLubyte* s = glGetString(name);
    return s ? reinterpret_cast<const char*>(s) : "(null)";
}

} // namespace

bool Renderer::Init(Window& window) {
    if (initialized_) return true;

    // Core profile 에서는 glewExperimental 이 필요하다 (확장 함수 포인터 로딩 보장).
    glewExperimental = GL_TRUE;
    const GLenum err = glewInit();
    if (err != GLEW_OK) {
        ENGINE_LOG_FATAL("glewInit failed: %s", reinterpret_cast<const char*>(glewGetErrorString(err)));
        return false;
    }
    glGetError();   // glewInit 이 core profile 에서 남기는 알려진 GL_INVALID_ENUM 제거

    if (!GLEW_VERSION_3_3) {
        ENGINE_LOG_FATAL("OpenGL 3.3 is required (driver reports %s)", GLString(GL_VERSION));
        return false;
    }
    ENGINE_LOG_INFO("GL %s | %s | %s", GLString(GL_VERSION), GLString(GL_RENDERER), GLString(GL_VENDOR));

#if defined(ENGINE_DEBUG)
    if (GLEW_KHR_debug) {
        glEnable(GL_DEBUG_OUTPUT);
        glEnable(GL_DEBUG_OUTPUT_SYNCHRONOUS);   // 에러 발생 지점의 콜스택을 디버거에서 볼 수 있음 (느림: Debug 전용)
        glDebugMessageCallback(GLDebugCallback, nullptr);
    } else {
        ENGINE_LOG_WARN("KHR_debug unavailable: GL errors will not be reported automatically");
    }
#endif

    // 2D 기본 상태: 깊이 테스트 끔(CPU Z-정렬 + painter's algorithm), 알파 블렌딩 켬.
    glDisable(GL_DEPTH_TEST);
    glDisable(GL_CULL_FACE);
    glEnable(GL_BLEND);
    glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);

    int w = 0, h = 0;
    window.GetDrawableSize(w, h);
    OnResize(w, h);

    const std::uint8_t whitePixel[4] = {255, 255, 255, 255};
    if (!white_.Create(1, 1, whitePixel) || !batch_.Init(&white_)) {
        ENGINE_LOG_FATAL("Renderer: failed to create SpriteBatch resources");
        white_.Destroy();
        return false;
    }

    initialized_ = true;
    return true;
}

void Renderer::Shutdown() {
    if (!initialized_) return;
    batch_.Shutdown();     // GL 객체는 컨텍스트가 파괴되기 '전'에 해제해야 한다
    white_.Destroy();
    initialized_ = false;
}

void Renderer::OnResize(int w, int h) {
    width_ = w; height_ = h;
    glViewport(0, 0, w, h);
}

void Renderer::BeginFrame() {
    ENGINE_ASSERT(initialized_, "Renderer used before Init");
    batch_.ResetStats();
}

void Renderer::EndFrame() {
    if (sceneOpen_) EndScene();    // 게임이 EndScene 을 빼먹어도 그려지도록
    stats_ = batch_.Stats();
}

void Renderer::BeginScene(const Camera2D& camera) {
    ENGINE_ASSERT(!sceneOpen_, "BeginScene called twice");
    batch_.Begin(camera);
    sceneOpen_ = true;
}

void Renderer::EndScene() {
    if (!sceneOpen_) return;
    batch_.End();
    sceneOpen_ = false;
}

void Renderer::Clear(float r, float g, float b, float a) {
    glClearColor(r, g, b, a);
    glClear(GL_COLOR_BUFFER_BIT);
}

} // namespace engine
