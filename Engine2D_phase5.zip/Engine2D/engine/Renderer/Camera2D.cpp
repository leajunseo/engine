#include "Renderer/Camera2D.hpp"

#include <cmath>

namespace engine {

Mat4 Camera2D::ViewProjection() const {
    // clip = S * R(-theta) * T(-position),  S = (2z/w, 2z/h)
    const float c  = std::cos(rotation_), s = std::sin(rotation_);
    const float sx = 2.0f * zoom_ / static_cast<float>(viewW_);
    const float sy = 2.0f * zoom_ / static_cast<float>(viewH_);
    const float px = position_.x, py = position_.y;

    Mat4 r;   // column-major: m[col * 4 + row]
    r.m[0]  =  sx * c;  r.m[1]  = -sy * s;
    r.m[4]  =  sx * s;  r.m[5]  =  sy * c;
    r.m[10] =  1.0f;
    r.m[12] = -sx * ( c * px + s * py);
    r.m[13] = -sy * (-s * px + c * py);
    r.m[15] =  1.0f;
    return r;
}

Vec2 Camera2D::ScreenToWorld(float sx, float sy) const {
    const float w = static_cast<float>(viewW_), h = static_cast<float>(viewH_);
    const float vx = (sx - w * 0.5f) / zoom_;      // 카메라 로컬(회전 전) 좌표
    const float vy = (h * 0.5f - sy) / zoom_;
    const float c = std::cos(rotation_), s = std::sin(rotation_);
    return {position_.x + c * vx - s * vy, position_.y + s * vx + c * vy};
}

Vec2 Camera2D::WorldToScreen(Vec2 world) const {
    const float c = std::cos(rotation_), s = std::sin(rotation_);
    const float dx = world.x - position_.x, dy = world.y - position_.y;
    const float vx =  c * dx + s * dy;
    const float vy = -s * dx + c * dy;
    return {static_cast<float>(viewW_) * 0.5f + vx * zoom_, static_cast<float>(viewH_) * 0.5f - vy * zoom_};
}

Camera2D::Bounds Camera2D::VisibleBounds() const {
    const float hx = static_cast<float>(viewW_) * 0.5f / zoom_;
    const float hy = static_cast<float>(viewH_) * 0.5f / zoom_;
    const float c = std::fabs(std::cos(rotation_)), s = std::fabs(std::sin(rotation_));
    const float ex = c * hx + s * hy;
    const float ey = s * hx + c * hy;
    return {position_.x - ex, position_.y - ey, position_.x + ex, position_.y + ey};
}

} // namespace engine
