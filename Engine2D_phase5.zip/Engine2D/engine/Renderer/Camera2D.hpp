#pragma once
#include "Math/Math.hpp"

namespace engine {

/// 2D 카메라. zoom = 1 이면 월드 1 단위 = 화면 1 픽셀. 월드는 Y-up, 카메라 위치가 화면 중앙에 온다.
/// rotation(라디안, 반시계) 은 카메라가 도는 방향이다 (화면 속 월드는 반대로 돈다).
class Camera2D {
public:
    void  SetPosition(Vec2 p)        { position_ = p; }
    Vec2  Position() const           { return position_; }
    void  SetZoom(float z)           { zoom_ = z > 0.0001f ? z : 0.0001f; }
    float Zoom() const               { return zoom_; }
    void  SetRotation(float radians) { rotation_ = radians; }
    float Rotation() const           { return rotation_; }
    void  SetViewport(int pixelW, int pixelH) { viewW_ = pixelW > 1 ? pixelW : 1; viewH_ = pixelH > 1 ? pixelH : 1; }
    int   ViewportWidth() const      { return viewW_; }
    int   ViewportHeight() const     { return viewH_; }

    Mat4 ViewProjection() const;                       // 월드 -> 클립
    Vec2 ScreenToWorld(float sx, float sy) const;      // 화면 픽셀(좌상단 원점) -> 월드
    Vec2 WorldToScreen(Vec2 world) const;

    struct Bounds { float minX, minY, maxX, maxY; };
    Bounds VisibleBounds() const;                      // 회전을 포함하는 월드 축정렬 박스 (컬링용, 보수적)

private:
    Vec2  position_{0.0f, 0.0f};
    float zoom_     = 1.0f;
    float rotation_ = 0.0f;
    int   viewW_    = 1280;
    int   viewH_    = 720;
};

} // namespace engine
