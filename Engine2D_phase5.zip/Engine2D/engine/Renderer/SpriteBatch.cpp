#include "Renderer/SpriteBatch.hpp"

#include <GL/glew.h>

#include <algorithm>
#include <cmath>

#include "Core/Assert.hpp"
#include "Core/Log.hpp"
#include "Renderer/Camera2D.hpp"

namespace engine {
namespace {

const char* kVertexSrc = R"GLSL(#version 330 core
layout(location = 0) in vec2 aPos;
layout(location = 1) in vec2 aUV;
layout(location = 2) in vec4 aColor;
uniform mat4 uViewProj;
out vec2 vUV;
out vec4 vColor;
void main() {
    vUV = aUV;
    vColor = aColor;
    gl_Position = uViewProj * vec4(aPos, 0.0, 1.0);
}
)GLSL";

const char* kFragmentSrc = R"GLSL(#version 330 core
in vec2 vUV;
in vec4 vColor;
uniform sampler2D uTex;
out vec4 FragColor;
void main() {
    FragColor = texture(uTex, vUV) * vColor;
}
)GLSL";

} // namespace

bool SpriteBatch::Init(const Texture* whiteTexture) {
    white_ = whiteTexture;
    if (!shader_.Compile(kVertexSrc, kFragmentSrc, "SpriteBatch")) return false;

    vertices_.resize(kMaxQuadsPerDraw * 4);

    // 인덱스 버퍼는 한 번만 만들고 재사용한다: 사각형 i -> (0,1,2, 0,2,3) + 4i
    std::vector<std::uint16_t> indices(kMaxQuadsPerDraw * 6);
    for (std::size_t i = 0; i < kMaxQuadsPerDraw; ++i) {
        const auto b = static_cast<std::uint16_t>(i * 4);
        std::uint16_t* p = &indices[i * 6];
        p[0] = b; p[1] = static_cast<std::uint16_t>(b + 1); p[2] = static_cast<std::uint16_t>(b + 2);
        p[3] = b; p[4] = static_cast<std::uint16_t>(b + 2); p[5] = static_cast<std::uint16_t>(b + 3);
    }

    glGenVertexArrays(1, &vao_);
    glGenBuffers(1, &vbo_);
    glGenBuffers(1, &ebo_);
    glBindVertexArray(vao_);

    glBindBuffer(GL_ARRAY_BUFFER, vbo_);
    glBufferData(GL_ARRAY_BUFFER, static_cast<GLsizeiptr>(vertices_.size() * sizeof(Vertex)), nullptr, GL_STREAM_DRAW);
    glEnableVertexAttribArray(0);
    glVertexAttribPointer(0, 2, GL_FLOAT, GL_FALSE, sizeof(Vertex), reinterpret_cast<const void*>(offsetof(Vertex, x)));
    glEnableVertexAttribArray(1);
    glVertexAttribPointer(1, 2, GL_FLOAT, GL_FALSE, sizeof(Vertex), reinterpret_cast<const void*>(offsetof(Vertex, u)));
    glEnableVertexAttribArray(2);
    glVertexAttribPointer(2, 4, GL_UNSIGNED_BYTE, GL_TRUE, sizeof(Vertex), reinterpret_cast<const void*>(offsetof(Vertex, rgba)));

    glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, ebo_);       // EBO 바인딩은 VAO 에 저장된다
    glBufferData(GL_ELEMENT_ARRAY_BUFFER, static_cast<GLsizeiptr>(indices.size() * sizeof(std::uint16_t)),
                 indices.data(), GL_STATIC_DRAW);
    glBindVertexArray(0);

    queue_.reserve(4096);
    return true;
}

void SpriteBatch::Shutdown() {
    if (vao_) { glDeleteVertexArrays(1, &vao_); vao_ = 0; }
    if (vbo_) { glDeleteBuffers(1, &vbo_);      vbo_ = 0; }
    if (ebo_) { glDeleteBuffers(1, &ebo_);      ebo_ = 0; }
    shader_.Destroy();
}

void SpriteBatch::Begin(const Camera2D& camera) {
    ENGINE_ASSERT(!inScene_, "SpriteBatch::Begin called twice without End");
    viewProj_ = camera.ViewProjection();
    const Camera2D::Bounds b = camera.VisibleBounds();
    minX_ = b.minX; minY_ = b.minY; maxX_ = b.maxX; maxY_ = b.maxY;
    queue_.clear();
    arena_.Reset();
    inScene_ = true;
}

void SpriteBatch::Draw(const Sprite& s) {
    ENGINE_ASSERT(inScene_, "SpriteBatch::Draw outside Begin/End");
    // 카메라 밖 컬링: 피벗에서 가장 먼 모서리까지의 거리를 반지름으로 하는 원 vs 가시 영역 박스
    const float dx = std::max(s.origin.x, 1.0f - s.origin.x) * s.size.x;
    const float dy = std::max(s.origin.y, 1.0f - s.origin.y) * s.size.y;
    const float r  = std::sqrt(dx * dx + dy * dy);
    if (s.position.x + r < minX_ || s.position.x - r > maxX_ ||
        s.position.y + r < minY_ || s.position.y - r > maxY_) {
        ++stats_.culled;
        return;
    }
    queue_.push_back(s);
}

void SpriteBatch::DrawRect(Vec2 center, Vec2 size, Color color, float rotation, int layer) {
    Sprite s;
    s.position = center; s.size = size; s.color = color; s.rotation = rotation; s.layer = layer;
    Draw(s);
}

void SpriteBatch::End() {
    ENGINE_ASSERT(inScene_, "SpriteBatch::End without Begin");
    inScene_ = false;
    const std::size_t n = queue_.size();
    if (n == 0) return;

    // --- 정렬: (layer, textureId) 오름차순, 동률은 제출 순서 유지 -------------------------
    // [Bottleneck] n 이 크면 정렬이 CPU 비용의 상당 부분. 이미 정렬돼 있으면(같은 레이어/텍스처만 쓰는
    //   흔한 경우) O(n) 검사로 건너뛴다. Debug(MSVC) 에서는 std::sort 가 느리니 수만 개 이상은 Release 로.
    SortKey* keys = arena_.AllocateArray<SortKey>(n);
    for (std::size_t i = 0; i < n; ++i) {
        const Sprite& s = queue_[i];
        const unsigned tex = (s.texture ? s.texture : white_)->Id();
        const auto layerBits = static_cast<std::uint32_t>(static_cast<std::int64_t>(s.layer) + 0x80000000LL);
        keys[i] = { (static_cast<std::uint64_t>(layerBits) << 32) | tex, static_cast<std::uint32_t>(i) };
    }
    auto less = [](const SortKey& a, const SortKey& b) { return a.key != b.key ? a.key < b.key : a.index < b.index; };
    if (!std::is_sorted(keys, keys + n, less)) std::sort(keys, keys + n, less);

    // --- 정점 생성 + 텍스처 경계마다 Flush --------------------------------------------------
    shader_.Use();
    shader_.SetMat4("uViewProj", viewProj_.m);
    shader_.SetInt("uTex", 0);
    glBindVertexArray(vao_);

    Vertex*        out    = vertices_.data();
    std::size_t    quads  = 0;
    const Texture* curTex = nullptr;

    for (std::size_t k = 0; k < n; ++k) {
        const Sprite&  s   = queue_[keys[k].index];
        const Texture* tex = s.texture ? s.texture : white_;
        if (tex != curTex || quads == kMaxQuadsPerDraw) {
            Flush(curTex ? curTex->Id() : 0, curTex, quads);
            out = vertices_.data(); quads = 0; curTex = tex;
        }

        // 피벗 기준 로컬 코너 (Y-up): TL, TR, BR, BL
        const float x0 = -s.origin.x * s.size.x,          x1 = (1.0f - s.origin.x) * s.size.x;
        const float y0 = -s.origin.y * s.size.y,          y1 = (1.0f - s.origin.y) * s.size.y;
        const float c = std::cos(s.rotation), sn = std::sin(s.rotation);
        const float lx[4] = {x0, x1, x1, x0};
        const float ly[4] = {y1, y1, y0, y0};

        float u0 = s.region.u0, u1 = s.region.u1, v0 = s.region.v0, v1 = s.region.v1;
        if (s.flipX) std::swap(u0, u1);
        if (s.flipY) std::swap(v0, v1);
        const float us[4] = {u0, u1, u1, u0};
        const float vs[4] = {v0, v0, v1, v1};   // v0 = 이미지 위쪽 행 -> 화면 위쪽(TL/TR)

        const std::uint32_t col = s.color.Pack();
        for (int i = 0; i < 4; ++i) {
            out[i].x = s.position.x + c * lx[i] - sn * ly[i];
            out[i].y = s.position.y + sn * lx[i] + c * ly[i];
            out[i].u = us[i]; out[i].v = vs[i];
            out[i].rgba = col;
        }
        out += 4; ++quads;
    }
    Flush(curTex ? curTex->Id() : 0, curTex, quads);
    glBindVertexArray(0);
}

void SpriteBatch::Flush(unsigned, const Texture* tex, std::size_t quads) {
    if (quads == 0 || !tex) return;
    tex->Bind(0);
    glBindBuffer(GL_ARRAY_BUFFER, vbo_);
    // 버퍼 orphaning: 이전 프레임 드로우가 아직 읽고 있어도 GPU 동기화 대기 없이 새 저장소를 받는다.
    glBufferData(GL_ARRAY_BUFFER, static_cast<GLsizeiptr>(vertices_.size() * sizeof(Vertex)), nullptr, GL_STREAM_DRAW);
    glBufferSubData(GL_ARRAY_BUFFER, 0, static_cast<GLsizeiptr>(quads * 4 * sizeof(Vertex)), vertices_.data());
    glDrawElements(GL_TRIANGLES, static_cast<GLsizei>(quads * 6), GL_UNSIGNED_SHORT, nullptr);
    ++stats_.drawCalls;
    stats_.quads += static_cast<std::uint32_t>(quads);
}

} // namespace engine
