#include "Renderer/TextureAtlas.hpp"

namespace engine {

bool TextureAtlas::CreateFromPixels(int w, int h, const std::uint8_t* rgba, TextureFilter filter) {
    regions_.clear();
    names_.clear();
    return texture_.Create(w, h, rgba, filter);
}

// 영역 가장자리를 0.1 텍셀 안쪽으로 줄여, 회전/확대 시 이웃 타일이 스며드는(bleeding) 현상을 막는다.
int TextureAtlas::Push(int px, int py, int pw, int ph) {
    constexpr float kInset = 0.1f;
    const float W = static_cast<float>(texture_.Width()), H = static_cast<float>(texture_.Height());
    TextureRegion r;
    r.u0 = (static_cast<float>(px) + kInset) / W;
    r.v0 = (static_cast<float>(py) + kInset) / H;
    r.u1 = (static_cast<float>(px + pw) - kInset) / W;
    r.v1 = (static_cast<float>(py + ph) - kInset) / H;
    regions_.push_back(r);
    return static_cast<int>(regions_.size()) - 1;
}

int TextureAtlas::AddGrid(int cols, int rows) {
    const int first = static_cast<int>(regions_.size());
    if (cols <= 0 || rows <= 0 || !texture_.IsValid()) return first;
    const int cw = texture_.Width() / cols, ch = texture_.Height() / rows;
    for (int y = 0; y < rows; ++y)
        for (int x = 0; x < cols; ++x) Push(x * cw, y * ch, cw, ch);
    return first;
}

int TextureAtlas::AddRegion(const std::string& name, int px, int py, int pw, int ph) {
    const int idx = Push(px, py, pw, ph);
    names_[name] = idx;
    return idx;
}

int TextureAtlas::Find(const std::string& name) const {
    const auto it = names_.find(name);
    return it == names_.end() ? -1 : it->second;
}

} // namespace engine
