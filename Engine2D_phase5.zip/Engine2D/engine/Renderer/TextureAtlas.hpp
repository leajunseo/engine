#pragma once
#include <cstdint>
#include <string>
#include <unordered_map>
#include <vector>

#include "Renderer/Texture.hpp"

namespace engine {

/// 텍스처 1장 + 그 안의 영역(Region) 목록. 같은 아틀라스의 스프라이트는 한 번의 드로우콜로 묶인다.
class TextureAtlas {
public:
    [[nodiscard]] bool CreateFromPixels(int w, int h, const std::uint8_t* rgba,
                                        TextureFilter filter = TextureFilter::Nearest);
    void Destroy() { texture_.Destroy(); regions_.clear(); names_.clear(); }

    /// 균일 격자(cols x rows)를 행 우선(왼쪽 위 -> 오른쪽 아래)으로 등록. 첫 영역의 인덱스를 반환.
    int AddGrid(int cols, int rows);
    /// 픽셀 사각형(이미지 좌표, 좌상단 원점)을 이름과 함께 등록. 인덱스 반환.
    int AddRegion(const std::string& name, int px, int py, int pw, int ph);

    int  Find(const std::string& name) const;          // 없으면 -1
    int  RegionCount() const { return static_cast<int>(regions_.size()); }
    const TextureRegion& Region(int index) const { return regions_[static_cast<std::size_t>(index)]; }
    const Texture&       GetTexture() const      { return texture_; }

private:
    int Push(int px, int py, int pw, int ph);

    Texture                              texture_;
    std::vector<TextureRegion>           regions_;
    std::unordered_map<std::string, int> names_;
};

} // namespace engine
