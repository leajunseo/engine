#pragma once
#include <cstdint>

#include "Renderer/SpriteBatch.hpp"
#include "Renderer/Texture.hpp"

namespace engine {

class Window;
class Camera2D;

using RenderStats = BatchStats;

/// GL 로더/상태/뷰포트/프레임 경계 + SpriteBatch 소유.
///   OnRender 안에서:  Clear() -> BeginScene(camera) -> Batch().Draw(...)* -> EndScene()
class Renderer {
public:
    Renderer() = default;
    ~Renderer() { Shutdown(); }
    Renderer(const Renderer&)            = delete;
    Renderer& operator=(const Renderer&) = delete;

    [[nodiscard]] bool Init(Window& window);   // 창의 GL 컨텍스트가 current 인 상태에서 호출
    void Shutdown();                           // GL 컨텍스트가 파괴되기 '전'에 호출 (멱등)

    void OnResize(int pixelWidth, int pixelHeight);
    void BeginFrame();
    void EndFrame();
    void Clear(float r, float g, float b, float a = 1.0f);

    void BeginScene(const Camera2D& camera);   // 카메라 행렬/컬링 영역으로 배치 시작
    void EndScene();                           // 정렬 + 드로우콜 제출 (EndFrame 이 열린 씬을 자동으로 닫음)

    SpriteBatch&       Batch()        { return batch_; }
    const Texture&     WhiteTexture() const { return white_; }
    const RenderStats& Stats() const  { return stats_; }   // 직전에 끝난 프레임의 통계

    int ViewportWidth()  const { return width_; }
    int ViewportHeight() const { return height_; }

private:
    bool        initialized_ = false;
    bool        sceneOpen_   = false;
    int         width_  = 0;
    int         height_ = 0;
    Texture     white_;
    SpriteBatch batch_;
    RenderStats stats_;
};

} // namespace engine
