#pragma once
#include <string>
#include <unordered_map>
#include <utility>

namespace engine {

/// GLSL 프로그램 (RAII, 이동 전용). 유니폼 위치는 이름별로 캐시한다 (glGetUniformLocation 은 느림).
class Shader {
public:
    Shader() = default;
    ~Shader() { Destroy(); }
    Shader(const Shader&)            = delete;
    Shader& operator=(const Shader&) = delete;
    Shader(Shader&& o) noexcept { *this = static_cast<Shader&&>(o); }
    Shader& operator=(Shader&& o) noexcept {
        if (this != &o) { Destroy(); program_ = o.program_; cache_ = std::move(o.cache_); o.program_ = 0; }
        return *this;
    }

    /// 컴파일/링크 실패 시 셰이더 info log 를 Error 로 남기고 false.
    [[nodiscard]] bool Compile(const char* vertexSrc, const char* fragmentSrc, const char* debugName);
    void Destroy();
    void Use() const;

    void SetInt(const char* name, int v);
    void SetFloat(const char* name, float v);
    void SetVec2(const char* name, float x, float y);
    void SetVec4(const char* name, float x, float y, float z, float w);
    void SetMat4(const char* name, const float* columnMajor16);

private:
    int Location(const char* name);

    unsigned program_ = 0;   // GLuint
    std::unordered_map<std::string, int> cache_;
};

} // namespace engine
