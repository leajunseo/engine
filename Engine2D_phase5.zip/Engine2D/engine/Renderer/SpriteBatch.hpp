#pragma once
#include <cstdint>
#include <vector>

#include "Core/Memory/FrameArena.hpp"
#include "Math/Math.hpp"
#include "Renderer/Shader.hpp"
#include "Renderer/Texture.hpp"

namespace engine {

class Camera2D;

struct Sprite {
    const Texture* texture  = nullptr;           // nullptr = 흰색 1x1 (단색 사각형)
    TextureRegion  region{};                     // 텍스처 안의 사용 영역
    Vec2           position{0.0f, 0.0f};         // 피벗(origin)이 놓이는 월드 위치
    Vec2           size{32.0f, 32.0f};           // 월드 단위
    float          rotation = 0.0f;              // 라디안, 반시계, 피벗 기준
    Vec2           origin{0.5f, 0.5f};           // 피벗 (0..1, (0,0)=좌하단 (1,1)=우상단)
    Color          color{};                      // 텍스처 색에 곱해짐 (틴트/알파)
    int            layer = 0;                    // RenderLayer
    bool           flipX = false, flipY = false;
};

struct BatchStats {
    std::uint32_t drawCalls = 0;   // glDrawElements 호출 수
    std::uint32_t quads     = 0;   // 실제로 그려진 스프라이트 수
    std::uint32_t culled    = 0;   // 카메라 밖이라 버려진 수
};

/// 동적 VBO 기반 스프라이트 배처.
///   Begin(camera) -> Draw()* -> End()
/// Draw 는 CPU 큐에 넣기만 한다. End 에서 (레이어, 텍스처) 로 정렬 -> 정점 생성 -> 텍스처가 바뀌거나 버퍼가 차면 1 드로우콜.
class SpriteBatch {
public:
    SpriteBatch() = default;
    ~SpriteBatch() { Shutdown(); }
    SpriteBatch(const SpriteBatch&)            = delete;
    SpriteBatch& operator=(const SpriteBatch&) = delete;

    [[nodiscard]] bool Init(const Texture* whiteTexture);
    void Shutdown();

    void Begin(const Camera2D& camera);
    void Draw(const Sprite& sprite);
    /// 단색 사각형 (피벗 = 중심).
    void DrawRect(Vec2 center, Vec2 size, Color color, float rotation = 0.0f, int layer = 0);
    void End();

    const BatchStats& Stats() const { return stats_; }
    void ResetStats() { stats_ = {}; }

    static constexpr std::size_t kMaxQuadsPerDraw = 8192;   // 8192*4 = 32768 정점 < 65536 -> uint16 인덱스

private:
    struct Vertex { float x, y, u, v; std::uint32_t rgba; };
    struct SortKey { std::uint64_t key; std::uint32_t index; };

    void Flush(unsigned textureId, const Texture* tex, std::size_t quads);

    Shader                 shader_;
    unsigned               vao_ = 0, vbo_ = 0, ebo_ = 0;
    const Texture*         white_ = nullptr;
    std::vector<Sprite>    queue_;
    std::vector<Vertex>    vertices_;
    FrameArena             arena_{256u * 1024u};   // 프레임 임시 정렬 키
    Mat4                   viewProj_;
    float                  minX_ = 0, minY_ = 0, maxX_ = 0, maxY_ = 0;
    bool                   inScene_ = false;
    BatchStats             stats_;
};

} // namespace engine
