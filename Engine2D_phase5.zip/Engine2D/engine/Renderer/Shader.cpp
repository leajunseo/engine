#include "Renderer/Shader.hpp"

#include <GL/glew.h>

#include <vector>

#include "Core/Log.hpp"

namespace engine {
namespace {

GLuint CompileStage(GLenum type, const char* src, const char* name) {
    const GLuint sh = glCreateShader(type);
    glShaderSource(sh, 1, &src, nullptr);
    glCompileShader(sh);
    GLint ok = 0;
    glGetShaderiv(sh, GL_COMPILE_STATUS, &ok);
    if (!ok) {
        GLint len = 0;
        glGetShaderiv(sh, GL_INFO_LOG_LENGTH, &len);
        std::vector<char> log(static_cast<std::size_t>(len > 1 ? len : 1));
        glGetShaderInfoLog(sh, len, nullptr, log.data());
        ENGINE_LOG_ERROR("Shader '%s' %s stage compile failed:\n%s", name,
                         type == GL_VERTEX_SHADER ? "vertex" : "fragment", log.data());
        glDeleteShader(sh);
        return 0;
    }
    return sh;
}

} // namespace

bool Shader::Compile(const char* vertexSrc, const char* fragmentSrc, const char* debugName) {
    Destroy();
    const GLuint vs = CompileStage(GL_VERTEX_SHADER, vertexSrc, debugName);
    const GLuint fs = vs ? CompileStage(GL_FRAGMENT_SHADER, fragmentSrc, debugName) : 0;
    if (!vs || !fs) { if (vs) glDeleteShader(vs); return false; }

    const GLuint prog = glCreateProgram();
    glAttachShader(prog, vs);
    glAttachShader(prog, fs);
    glLinkProgram(prog);
    glDeleteShader(vs);          // 링크 후에는 스테이지 객체가 필요 없다
    glDeleteShader(fs);

    GLint ok = 0;
    glGetProgramiv(prog, GL_LINK_STATUS, &ok);
    if (!ok) {
        GLint len = 0;
        glGetProgramiv(prog, GL_INFO_LOG_LENGTH, &len);
        std::vector<char> log(static_cast<std::size_t>(len > 1 ? len : 1));
        glGetProgramInfoLog(prog, len, nullptr, log.data());
        ENGINE_LOG_ERROR("Shader '%s' link failed:\n%s", debugName, log.data());
        glDeleteProgram(prog);
        return false;
    }
    program_ = prog;
    return true;
}

void Shader::Destroy() {
    if (program_) { glDeleteProgram(program_); program_ = 0; }
    cache_.clear();
}

void Shader::Use() const { glUseProgram(program_); }

int Shader::Location(const char* name) {
    const auto it = cache_.find(name);
    if (it != cache_.end()) return it->second;
    const int loc = glGetUniformLocation(program_, name);
    if (loc < 0) ENGINE_LOG_WARN("Uniform '%s' not found (optimized out?)", name);
    cache_.emplace(name, loc);
    return loc;
}

// 유니폼 설정은 이 셰이더가 Use() 중이라고 가정한다 (GL 3.3 에는 glProgramUniform 이 없음).
void Shader::SetInt(const char* n, int v)                          { glUniform1i(Location(n), v); }
void Shader::SetFloat(const char* n, float v)                      { glUniform1f(Location(n), v); }
void Shader::SetVec2(const char* n, float x, float y)              { glUniform2f(Location(n), x, y); }
void Shader::SetVec4(const char* n, float x, float y, float z, float w) { glUniform4f(Location(n), x, y, z, w); }
void Shader::SetMat4(const char* n, const float* m)                { glUniformMatrix4fv(Location(n), 1, GL_FALSE, m); }

} // namespace engine
