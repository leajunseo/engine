#include "Renderer/Texture.hpp"

#include <GL/glew.h>

#include "Core/Log.hpp"

namespace engine {

bool Texture::Create(int w, int h, const std::uint8_t* rgba, TextureFilter filter, TextureWrap wrap) {
    Destroy();
    if (w <= 0 || h <= 0 || !rgba) { ENGINE_LOG_ERROR("Texture::Create: invalid arguments (%dx%d)", w, h); return false; }

    GLuint id = 0;
    glGenTextures(1, &id);
    glBindTexture(GL_TEXTURE_2D, id);
    glPixelStorei(GL_UNPACK_ALIGNMENT, 1);     // 행 패딩 없음(RGBA8 은 어차피 4 의 배수지만 명시)
    glTexImage2D(GL_TEXTURE_2D, 0, GL_RGBA8, w, h, 0, GL_RGBA, GL_UNSIGNED_BYTE, rgba);

    const GLint f = filter == TextureFilter::Nearest ? GL_NEAREST : GL_LINEAR;
    const GLint p = wrap == TextureWrap::Repeat ? GL_REPEAT : GL_CLAMP_TO_EDGE;
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, f);   // 밉맵 없음 (Phase 2)
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, f);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, p);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, p);

    id_ = id; w_ = w; h_ = h;
    return true;
}

void Texture::Destroy() {
    if (id_) { GLuint id = id_; glDeleteTextures(1, &id); id_ = 0; }
    w_ = h_ = 0;
}

void Texture::Bind(unsigned slot) const {
    glActiveTexture(GL_TEXTURE0 + slot);
    glBindTexture(GL_TEXTURE_2D, id_);
}

} // namespace engine
