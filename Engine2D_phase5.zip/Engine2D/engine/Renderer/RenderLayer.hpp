#pragma once
// 렌더 레이어: 값이 작을수록 먼저(뒤에) 그려진다. 같은 레이어 안에서는 텍스처별로 묶어 드로우콜을 줄이고,
// 같은 (레이어, 텍스처) 안에서는 Draw 호출 순서가 유지된다. 임의의 int 를 써도 된다 (예: Default + 1).
namespace engine::RenderLayer {
constexpr int Background = -100;
constexpr int Default    = 0;
constexpr int Foreground = 100;
constexpr int Overlay    = 1000;   // 디버그 표시, 커서 등 (UI 전용 스크린 카메라는 후속 단계)
}
