#pragma once
#include <cstdint>

namespace engine {

enum class TextureFilter { Nearest, Linear };   // 픽셀아트 = Nearest
enum class TextureWrap   { Clamp, Repeat };

/// 텍스처 안의 사각 영역 (UV, 이미지 좌표계: v = 0 이 이미지 맨 위 행).
struct TextureRegion { float u0 = 0.0f, v0 = 0.0f, u1 = 1.0f, v1 = 1.0f; };

/// GL 2D 텍스처 (RAII, 이동 전용). GL 컨텍스트가 살아있는 동안 Destroy() 되어야 한다.
/// (게임 코드: IGame::OnShutdown 에서 Destroy 하거나 Application 보다 먼저 소멸시킬 것)
class Texture {
public:
    Texture() = default;
    ~Texture() { Destroy(); }
    Texture(const Texture&)            = delete;
    Texture& operator=(const Texture&) = delete;
    Texture(Texture&& o) noexcept { *this = static_cast<Texture&&>(o); }
    Texture& operator=(Texture&& o) noexcept {
        if (this != &o) { Destroy(); id_ = o.id_; w_ = o.w_; h_ = o.h_; o.id_ = 0; o.w_ = o.h_ = 0; }
        return *this;
    }

    /// rgba: 가로 w, 세로 h, 4바이트/픽셀, 첫 행 = 이미지 맨 위.
    [[nodiscard]] bool Create(int w, int h, const std::uint8_t* rgba,
                              TextureFilter filter = TextureFilter::Nearest,
                              TextureWrap wrap = TextureWrap::Clamp);
    void Destroy();
    void Bind(unsigned slot = 0) const;

    unsigned Id() const     { return id_; }
    int      Width() const  { return w_; }
    int      Height() const { return h_; }
    bool     IsValid() const { return id_ != 0; }

private:
    unsigned id_ = 0;   // GLuint
    int      w_ = 0, h_ = 0;
};

} // namespace engine
