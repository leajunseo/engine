#pragma once
// ---------------------------------------------------------------------------
// 플랫폼 독립 키/마우스 버튼 코드. SDL 헤더에 의존하지 않는다 (SDL scancode <-> KeyCode 변환은 KeyCode.cpp 안에만 있다).
//   값은 '물리적 키 위치' (scancode) 기준 -> 자판 배열(QWERTY/AZERTY/한글)이 달라도 WASD 는 같은 위치.
//   Name()/KeyCodeFromName() 은 바인딩 파일 저장/불러오기에 쓰는 안정적인 문자열 이름 (대소문자 무시).
// ---------------------------------------------------------------------------
#include <cstdint>
#include <string>

namespace engine {

enum class KeyCode : std::uint16_t {
    Unknown = 0,
    A, B, C, D, E, F, G, H, I, J, K, L, M, N, O, P, Q, R, S, T, U, V, W, X, Y, Z,
    Num0, Num1, Num2, Num3, Num4, Num5, Num6, Num7, Num8, Num9,
    F1, F2, F3, F4, F5, F6, F7, F8, F9, F10, F11, F12,
    Up, Down, Left, Right,
    Space, Enter, Escape, Tab, Backspace, Delete, Insert, Home, End, PageUp, PageDown,
    LShift, RShift, LCtrl, RCtrl, LAlt, RAlt,
    Comma, Period, Slash, Semicolon, Apostrophe, LeftBracket, RightBracket, Backslash, Minus, Equals, Grave,
    Keypad0, Keypad1, Keypad2, Keypad3, Keypad4, Keypad5, Keypad6, Keypad7, Keypad8, Keypad9,
    KeypadPlus, KeypadMinus, KeypadEnter,
    Count
};

enum class MouseButton : std::uint8_t { Left = 0, Middle, Right, X1, X2, Count };

constexpr int kKeyCount         = static_cast<int>(KeyCode::Count);
constexpr int kMouseButtonCount = static_cast<int>(MouseButton::Count);

/// SDL scancode 값 -> KeyCode (모르는 키는 Unknown). Window 가 사용.
KeyCode KeyCodeFromScancode(int sdlScancode);
/// SDL_BUTTON_* (1=좌 2=가운데 3=우 4=X1 5=X2) -> MouseButton. 범위 밖이면 Count 를 반환.
MouseButton MouseButtonFromSdl(int sdlButton);

const char* KeyName(KeyCode key);                       // "Space", "A", "Left" ... (Unknown -> "Unknown")
KeyCode     KeyCodeFromName(const std::string& name);   // 대소문자 무시. 모르면 Unknown
const char* MouseButtonName(MouseButton b);             // "Left" "Middle" "Right" "X1" "X2"
bool        MouseButtonFromName(const std::string& name, MouseButton& out);

} // namespace engine
