#include "Input/InputManager.hpp"

#include <algorithm>
#include <cstdio>
#include <cstdlib>
#include <fstream>
#include <sstream>
#include <unordered_set>

#include "Core/Log.hpp"

namespace engine {

InputManager::InputManager(EventBus& bus) {
    subKey_    = bus.Subscribe<KeyEvent>([this](const KeyEvent& e) { OnKey(e); });
    subButton_ = bus.Subscribe<MouseButtonEvent>([this](const MouseButtonEvent& e) { OnMouseButton(e); });
    subMove_   = bus.Subscribe<MouseMoveEvent>([this](const MouseMoveEvent& e) { OnMouseMove(e); });
    subWheel_  = bus.Subscribe<MouseWheelEvent>([this](const MouseWheelEvent& e) { wheel_ += e.dy; });
    subFocus_  = bus.Subscribe<WindowFocusEvent>([this](const WindowFocusEvent& e) {
        if (e.focused) return;
        for (auto& b : keys_)  if (b.down) SetDown(b, false);     // 포커스 상실: 모두 뗌 처리
        for (auto& b : mouse_) if (b.down) SetDown(b, false);
        RefreshActions();
    });
}

void InputManager::SetDown(Button& b, bool down) {
    if (b.down == down) return;
    b.down = down;
    if (down) { b.pressedFrame = true;  b.pressedTick = true; }
    else      { b.releasedFrame = true; b.releasedTick = true; }
}

void InputManager::OnKey(const KeyEvent& e) {
    if (e.repeat || !Valid(e.key)) return;
    SetDown(keys_[Idx(e.key)], e.pressed);
    if (e.pressed) lastPressed_ = e.key;
    RefreshActions();
}

void InputManager::OnMouseButton(const MouseButtonEvent& e) {
    mousePos_ = {e.x, e.y};
    haveMousePos_ = true;
    const MouseButton b = MouseButtonFromSdl(e.button);
    if (!Valid(b)) return;
    SetDown(mouse_[Idx(b)], e.pressed);
    RefreshActions();
}

void InputManager::OnMouseMove(const MouseMoveEvent& e) {
    if (haveMousePos_) { mouseDelta_.x += e.x - mousePos_.x; mouseDelta_.y += e.y - mousePos_.y; }
    mousePos_ = {e.x, e.y};
    haveMousePos_ = true;
}

bool InputManager::AnyKeyDown() const {
    return std::any_of(keys_.begin(), keys_.end(), [](const Button& b) { return b.down; });
}

bool InputManager::ComputeActionDown(const Action& a) const {
    for (KeyCode k : a.keys)     if (keys_[Idx(k)].down)  return true;
    for (MouseButton b : a.mouse) if (mouse_[Idx(b)].down) return true;
    return false;
}

void InputManager::RefreshActions() {
    for (Action& a : actions_) {
        const bool now = ComputeActionDown(a);
        if (now == a.down) continue;
        a.down = now;
        if (now) { a.pressedFrame = true;  a.pressedTick = true; }
        else     { a.releasedFrame = true; a.releasedTick = true; }
    }
}

void InputManager::EndTick() {
    for (auto& b : keys_)  { b.pressedTick = false; b.releasedTick = false; }
    for (auto& b : mouse_) { b.pressedTick = false; b.releasedTick = false; }
    for (auto& a : actions_) { a.pressedTick = false; a.releasedTick = false; }
}

void InputManager::EndFrame() {
    for (auto& b : keys_)  { b.pressedFrame = false; b.releasedFrame = false; }
    for (auto& b : mouse_) { b.pressedFrame = false; b.releasedFrame = false; }
    for (auto& a : actions_) { a.pressedFrame = false; a.releasedFrame = false; }
    mouseDelta_ = {0.0f, 0.0f};
    wheel_ = 0.0f;
    lastPressed_ = KeyCode::Unknown;
}

// ---------------------------------------------------------------- 액션
ActionId InputManager::DefineAction(const std::string& name) {
    if (ActionId e = FindAction(name); e.Valid()) return e;
    Action a; a.name = name;
    actions_.push_back(std::move(a));
    return ActionId{static_cast<int>(actions_.size()) - 1};
}

ActionId InputManager::FindAction(const std::string& name) const {
    for (std::size_t i = 0; i < actions_.size(); ++i) if (actions_[i].name == name) return ActionId{static_cast<int>(i)};
    return {};
}

void InputManager::BindKey(ActionId a, KeyCode k) {
    if (!Valid(a) || !Valid(k)) return;
    auto& v = actions_[Idx(a)].keys;
    if (std::find(v.begin(), v.end(), k) == v.end()) v.push_back(k);
    RefreshActions();
}

void InputManager::BindMouse(ActionId a, MouseButton b) {
    if (!Valid(a) || !Valid(b)) return;
    auto& v = actions_[Idx(a)].mouse;
    if (std::find(v.begin(), v.end(), b) == v.end()) v.push_back(b);
    RefreshActions();
}

void InputManager::ClearBindings(ActionId a) {
    if (!Valid(a)) return;
    actions_[Idx(a)].keys.clear();
    actions_[Idx(a)].mouse.clear();
    RefreshActions();    // 바인딩이 사라지면 눌림 상태도 풀린다 (뗌 엣지 발생)
}

std::string InputManager::FindActionUsing(KeyCode k) const {
    for (const Action& a : actions_) if (std::find(a.keys.begin(), a.keys.end(), k) != a.keys.end()) return a.name;
    return {};
}

// ---------------------------------------------------------------- 축
AxisId InputManager::DefineAxis(const std::string& name) {
    if (AxisId e = FindAxis(name); e.Valid()) return e;
    Axis a; a.name = name;
    axes_.push_back(std::move(a));
    return AxisId{static_cast<int>(axes_.size()) - 1};
}

AxisId InputManager::FindAxis(const std::string& name) const {
    for (std::size_t i = 0; i < axes_.size(); ++i) if (axes_[i].name == name) return AxisId{static_cast<int>(i)};
    return {};
}

void InputManager::BindAxisKeys(AxisId a, KeyCode neg, KeyCode pos, float scale) {
    if (!Valid(a) || !Valid(neg) || !Valid(pos)) return;
    axes_[static_cast<std::size_t>(a.index)].keys.push_back({neg, pos, scale});
}
void InputManager::BindAxisMouseX(AxisId a, float s) { if (Valid(a)) axes_[static_cast<std::size_t>(a.index)].mouseX = s; }
void InputManager::BindAxisMouseY(AxisId a, float s) { if (Valid(a)) axes_[static_cast<std::size_t>(a.index)].mouseY = s; }
void InputManager::BindAxisWheel(AxisId a, float s)  { if (Valid(a)) axes_[static_cast<std::size_t>(a.index)].wheel  = s; }
void InputManager::ClearBindings(AxisId a) {
    if (!Valid(a)) return;
    Axis& ax = axes_[static_cast<std::size_t>(a.index)];
    ax.keys.clear(); ax.mouseX = ax.mouseY = ax.wheel = 0.0f;
}

float InputManager::Value(AxisId a) const {
    if (!Valid(a)) return 0.0f;
    const Axis& ax = axes_[static_cast<std::size_t>(a.index)];
    float k = 0.0f;
    for (const AxisKeys& b : ax.keys) {
        if (keys_[Idx(b.pos)].down) k += b.scale;
        if (keys_[Idx(b.neg)].down) k -= b.scale;
    }
    k = std::max(-1.0f, std::min(1.0f, k));
    return k + ax.mouseX * mouseDelta_.x + ax.mouseY * mouseDelta_.y + ax.wheel * wheel_;
}

// ---------------------------------------------------------------- 저장/복원
std::string InputManager::SerializeBindings() const {
    std::string out = "# Engine2D input bindings\n";
    char num[64];
    for (const Action& a : actions_) {
        out += "action " + a.name + "\n";                                  // 바인딩이 없어도 정의는 남긴다
        for (KeyCode k : a.keys)      out += "action " + a.name + " key " + KeyName(k) + "\n";
        for (MouseButton b : a.mouse) out += "action " + a.name + " mouse " + MouseButtonName(b) + "\n";
    }
    for (const Axis& ax : axes_) {
        out += "axis " + ax.name + "\n";
        for (const AxisKeys& b : ax.keys) {
            std::snprintf(num, sizeof(num), "%g", static_cast<double>(b.scale));
            out += "axis " + ax.name + " keys " + KeyName(b.neg) + " " + KeyName(b.pos) + " " + num + "\n";
        }
        const struct { const char* tag; float v; } src[] = {{"mousex", ax.mouseX}, {"mousey", ax.mouseY}, {"wheel", ax.wheel}};
        for (const auto& s : src) {
            if (s.v == 0.0f) continue;
            std::snprintf(num, sizeof(num), "%g", static_cast<double>(s.v));
            out += "axis " + ax.name + " " + s.tag + " " + num + "\n";
        }
    }
    return out;
}

bool InputManager::ParseBindings(const std::string& text, std::vector<std::string>* errors) {
    bool ok = true;
    int lineNo = 0;
    auto fail = [&](const std::string& why) {
        ok = false;
        if (errors) errors->push_back("line " + std::to_string(lineNo) + ": " + why);
    };
    auto parseFloat = [](const std::string& s, float& v) {
        char* end = nullptr;
        v = std::strtof(s.c_str(), &end);
        return end && end != s.c_str() && *end == '\0';
    };

    std::unordered_set<std::string> touchedActions, touchedAxes;
    std::istringstream in(text);
    std::string line;
    while (std::getline(in, line)) {
        ++lineNo;
        std::istringstream ls(line);
        std::vector<std::string> t;
        for (std::string w; ls >> w;) t.push_back(w);
        if (t.empty() || t[0][0] == '#') continue;

        if (t[0] == "action" && t.size() >= 2) {
            const ActionId id = DefineAction(t[1]);
            if (touchedActions.insert(t[1]).second) ClearBindings(id);     // 이 파일이 다루는 액션은 기존 바인딩 교체
            if (t.size() == 2) continue;
            if (t.size() != 4) { fail("expected: action <name> key|mouse <input>"); continue; }
            if (t[2] == "key") {
                const KeyCode k = KeyCodeFromName(t[3]);
                if (k == KeyCode::Unknown) fail("unknown key '" + t[3] + "'"); else BindKey(id, k);
            } else if (t[2] == "mouse") {
                MouseButton b;
                if (!MouseButtonFromName(t[3], b)) fail("unknown mouse button '" + t[3] + "'"); else BindMouse(id, b);
            } else fail("expected 'key' or 'mouse', got '" + t[2] + "'");
        } else if (t[0] == "axis" && t.size() >= 2) {
            const AxisId id = DefineAxis(t[1]);
            if (touchedAxes.insert(t[1]).second) ClearBindings(id);
            if (t.size() == 2) continue;
            float v = 1.0f;
            if (t[2] == "keys") {
                if (t.size() != 5 && t.size() != 6) { fail("expected: axis <name> keys <neg> <pos> [scale]"); continue; }
                const KeyCode n = KeyCodeFromName(t[3]), p = KeyCodeFromName(t[4]);
                if (n == KeyCode::Unknown || p == KeyCode::Unknown) { fail("unknown key in '" + t[3] + " " + t[4] + "'"); continue; }
                if (t.size() == 6 && !parseFloat(t[5], v)) { fail("bad number '" + t[5] + "'"); continue; }
                BindAxisKeys(id, n, p, v);
            } else if (t[2] == "mousex" || t[2] == "mousey" || t[2] == "wheel") {
                if (t.size() != 4 || !parseFloat(t[3], v)) { fail("expected: axis <name> " + t[2] + " <scale>"); continue; }
                if (t[2] == "mousex") BindAxisMouseX(id, v); else if (t[2] == "mousey") BindAxisMouseY(id, v); else BindAxisWheel(id, v);
            } else fail("unknown axis source '" + t[2] + "'");
        } else {
            fail("unknown directive '" + t[0] + "'");
        }
    }
    return ok;
}

bool InputManager::SaveBindings(const std::string& path) const {
    std::ofstream f(path, std::ios::binary | std::ios::trunc);
    if (!f) { ENGINE_LOG_ERROR("Cannot write bindings: %s", path.c_str()); return false; }
    f << SerializeBindings();
    return static_cast<bool>(f);
}

bool InputManager::LoadBindings(const std::string& path, std::vector<std::string>* errors) {
    std::ifstream f(path, std::ios::binary);
    if (!f) return false;                                   // 파일 없음: 기본 바인딩 유지
    std::stringstream ss; ss << f.rdbuf();
    return ParseBindings(ss.str(), errors);
}

} // namespace engine
