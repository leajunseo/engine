#pragma once
// ---------------------------------------------------------------------------
// 입력 관리자: EventBus 의 Key/Mouse 이벤트를 모아 '상태 조회' + '액션/축 매핑' 을 제공한다. (SDL 비의존)
//
//   InputManager input(bus);                              // Application 이 소유 -> app.Input()
//   ActionId jump = input.DefineAction("Jump");
//   input.BindKey(jump, KeyCode::Space);  input.BindMouse(jump, MouseButton::Left);
//   AxisId moveX = input.DefineAxis("MoveX");
//   input.BindAxisKeys(moveX, KeyCode::A, KeyCode::D);    // 음수키, 양수키
//   input.BindAxisKeys(moveX, KeyCode::Left, KeyCode::Right);
//
// '엣지'(눌림/뗌) 조회는 두 종류 -> 호출하는 곳에 맞는 쪽을 쓸 것
//   Pressed/Released      : '렌더 프레임' 단위. OnVariableUpdate / OnRender 에서. (프레임 끝 EndFrame 에서 지워짐)
//   PressedTick/ReleasedTick : '고정 틱' 단위. OnFixedUpdate 에서. 틱이 한 번도 안 돈 프레임의 입력은 다음 틱까지
//                              유지되고(누락 없음), 한 프레임에 틱이 여러 번 돌아도 첫 틱에서만 true (중복 없음).
//   Down(상태)은 어디서나 같다.
//
// 포커스를 잃으면 눌려 있던 모든 키/버튼을 '뗌' 으로 처리 (키가 눌린 채 고정되는 문제 방지).
// 키 반복(repeat) 이벤트는 무시한다. 같은 액션에 여러 입력이 묶여 있으면 '하나라도 눌림' = 액션 눌림,
//   액션의 Pressed/Released 는 액션 상태가 바뀔 때 한 번만 (Space 와 클릭을 동시에 눌러도 Pressed 는 1번).
//
// 바인딩은 텍스트로 저장/복원 가능 (SerializeBindings / ParseBindings):
//     action Jump key Space
//     action Fire mouse Left
//     axis MoveX keys A D
//     axis LookX mousex 0.1
//   (# 로 시작하는 줄과 빈 줄은 무시. 잘못된 줄은 건너뛰고 false 를 반환하되 나머지는 적용)
//
// 스레드: 메인 스레드 전용 (EventBus 와 동일).
// ---------------------------------------------------------------------------
#include <array>
#include <cstddef>
#include <string>
#include <vector>

#include "Core/EventBus.hpp"
#include "Core/Events.hpp"
#include "Input/KeyCode.hpp"
#include "Math/Math.hpp"

namespace engine {

struct ActionId { int index = -1; bool Valid() const { return index >= 0; } bool operator==(ActionId o) const { return index == o.index; } };
struct AxisId   { int index = -1; bool Valid() const { return index >= 0; } bool operator==(AxisId o) const { return index == o.index; } };

class InputManager {
public:
    explicit InputManager(EventBus& bus);
    ~InputManager() = default;
    InputManager(const InputManager&)            = delete;
    InputManager& operator=(const InputManager&) = delete;

    // ---- 프레임/틱 경계 (Application 이 호출) ----
    void EndTick();     // 고정 틱 하나가 끝난 뒤: 틱 엣지 지움
    void EndFrame();    // 렌더 프레임이 끝난 뒤: 프레임 엣지, 마우스 이동량, 휠 지움

    // ---- 원시 상태 ----
    bool Down(KeyCode k) const         { return Valid(k) && keys_[Idx(k)].down; }
    bool Pressed(KeyCode k) const      { return Valid(k) && keys_[Idx(k)].pressedFrame; }
    bool Released(KeyCode k) const     { return Valid(k) && keys_[Idx(k)].releasedFrame; }
    bool PressedTick(KeyCode k) const  { return Valid(k) && keys_[Idx(k)].pressedTick; }
    bool ReleasedTick(KeyCode k) const { return Valid(k) && keys_[Idx(k)].releasedTick; }

    bool Down(MouseButton b) const         { return Valid(b) && mouse_[Idx(b)].down; }
    bool Pressed(MouseButton b) const      { return Valid(b) && mouse_[Idx(b)].pressedFrame; }
    bool Released(MouseButton b) const     { return Valid(b) && mouse_[Idx(b)].releasedFrame; }
    bool PressedTick(MouseButton b) const  { return Valid(b) && mouse_[Idx(b)].pressedTick; }
    bool ReleasedTick(MouseButton b) const { return Valid(b) && mouse_[Idx(b)].releasedTick; }

    Vec2  MousePosition() const { return mousePos_; }      // 드로어블 픽셀, 좌상단 원점
    Vec2  MouseDelta() const    { return mouseDelta_; }    // 이번 프레임에 움직인 양
    float Wheel() const         { return wheel_; }         // 이번 프레임의 휠 누적 (위 +)
    /// 이번 프레임에 눌린 마지막 키 (없으면 Unknown). 'Press any key to rebind' UI 용.
    KeyCode LastPressedKey() const { return lastPressed_; }
    bool AnyKeyDown() const;

    // ---- 액션 ----
    ActionId DefineAction(const std::string& name);        // 같은 이름이면 기존 id
    ActionId FindAction(const std::string& name) const;    // 없으면 Valid()==false
    void BindKey(ActionId a, KeyCode k);
    void BindMouse(ActionId a, MouseButton b);
    void ClearBindings(ActionId a);                        // 이 액션의 바인딩만 지움 (정의는 유지)
    /// 같은 입력이 이미 다른 액션에 묶여 있으면 그 액션의 이름을, 아니면 빈 문자열 (리바인드 충돌 안내용)
    std::string FindActionUsing(KeyCode k) const;

    bool Down(ActionId a) const         { return Valid(a) && actions_[Idx(a)].down; }
    bool Pressed(ActionId a) const      { return Valid(a) && actions_[Idx(a)].pressedFrame; }
    bool Released(ActionId a) const     { return Valid(a) && actions_[Idx(a)].releasedFrame; }
    bool PressedTick(ActionId a) const  { return Valid(a) && actions_[Idx(a)].pressedTick; }
    bool ReleasedTick(ActionId a) const { return Valid(a) && actions_[Idx(a)].releasedTick; }

    // ---- 축 ----
    AxisId DefineAxis(const std::string& name);
    AxisId FindAxis(const std::string& name) const;
    void BindAxisKeys(AxisId a, KeyCode negative, KeyCode positive, float scale = 1.0f);
    void BindAxisMouseX(AxisId a, float scale);            // 이번 프레임 마우스 X 이동량 * scale
    void BindAxisMouseY(AxisId a, float scale);
    void BindAxisWheel(AxisId a, float scale);
    void ClearBindings(AxisId a);
    /// 키 입력 합은 [-1,1] 로 제한(대각선 키 겹침/반대 키 동시 입력 처리), 마우스/휠 입력은 제한 없이 더한다.
    float Value(AxisId a) const;

    // ---- 바인딩 저장/복원 ----
    std::string SerializeBindings() const;
    /// 파싱 중 오류가 있었는지 반환. 정의되지 않은 액션/축 이름이 나오면 새로 정의한다. 기존 바인딩은 줄이 나온 항목만 교체.
    bool ParseBindings(const std::string& text, std::vector<std::string>* errors = nullptr);
    bool SaveBindings(const std::string& path) const;
    bool LoadBindings(const std::string& path, std::vector<std::string>* errors = nullptr);

private:
    struct Button {
        bool down = false;
        bool pressedFrame = false, releasedFrame = false, pressedTick = false, releasedTick = false;
    };
    struct Action {
        std::string name;
        std::vector<KeyCode>     keys;
        std::vector<MouseButton> mouse;
        bool down = false;
        bool pressedFrame = false, releasedFrame = false, pressedTick = false, releasedTick = false;
    };
    struct AxisKeys { KeyCode neg, pos; float scale; };
    struct Axis {
        std::string name;
        std::vector<AxisKeys> keys;
        float mouseX = 0.0f, mouseY = 0.0f, wheel = 0.0f;   // 0 = 미사용 (같은 종류를 다시 바인딩하면 덮어씀)
    };

    static bool Valid(KeyCode k)     { return static_cast<int>(k) > 0 && static_cast<int>(k) < kKeyCount; }
    static bool Valid(MouseButton b) { return static_cast<int>(b) < kMouseButtonCount; }
    bool Valid(ActionId a) const     { return a.index >= 0 && static_cast<std::size_t>(a.index) < actions_.size(); }
    bool Valid(AxisId a) const       { return a.index >= 0 && static_cast<std::size_t>(a.index) < axes_.size(); }
    static std::size_t Idx(KeyCode k)     { return static_cast<std::size_t>(k); }
    static std::size_t Idx(MouseButton b) { return static_cast<std::size_t>(b); }
    static std::size_t Idx(ActionId a)    { return static_cast<std::size_t>(a.index); }

    void OnKey(const KeyEvent& e);
    void OnMouseButton(const MouseButtonEvent& e);
    void OnMouseMove(const MouseMoveEvent& e);
    void SetDown(Button& b, bool down);
    void RefreshActions();
    bool ComputeActionDown(const Action& a) const;

    std::array<Button, static_cast<std::size_t>(kKeyCount)>         keys_{};
    std::array<Button, static_cast<std::size_t>(kMouseButtonCount)> mouse_{};
    std::vector<Action> actions_;
    std::vector<Axis>   axes_;

    Vec2  mousePos_{0.0f, 0.0f}, mouseDelta_{0.0f, 0.0f};
    bool  haveMousePos_ = false;
    float wheel_ = 0.0f;
    KeyCode lastPressed_ = KeyCode::Unknown;

    Subscription subKey_, subButton_, subMove_, subWheel_, subFocus_;
};

} // namespace engine
