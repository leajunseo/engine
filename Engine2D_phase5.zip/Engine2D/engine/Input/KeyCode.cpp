#include "Input/KeyCode.hpp"

#include <algorithm>
#include <cctype>
#include <unordered_map>

#include <SDL.h>

namespace engine {
namespace {

const char* const kKeyNames[kKeyCount] = {
    "Unknown",
    "A","B","C","D","E","F","G","H","I","J","K","L","M","N","O","P","Q","R","S","T","U","V","W","X","Y","Z",
    "0","1","2","3","4","5","6","7","8","9",
    "F1","F2","F3","F4","F5","F6","F7","F8","F9","F10","F11","F12",
    "Up","Down","Left","Right",
    "Space","Enter","Escape","Tab","Backspace","Delete","Insert","Home","End","PageUp","PageDown",
    "LShift","RShift","LCtrl","RCtrl","LAlt","RAlt",
    "Comma","Period","Slash","Semicolon","Apostrophe","LeftBracket","RightBracket","Backslash","Minus","Equals","Grave",
    "Keypad0","Keypad1","Keypad2","Keypad3","Keypad4","Keypad5","Keypad6","Keypad7","Keypad8","Keypad9",
    "KeypadPlus","KeypadMinus","KeypadEnter",
};
static_assert(sizeof(kKeyNames) / sizeof(kKeyNames[0]) == static_cast<std::size_t>(kKeyCount),
              "kKeyNames must have one entry per KeyCode");

std::string Lower(const std::string& s) {
    std::string r = s;
    std::transform(r.begin(), r.end(), r.begin(), [](unsigned char c) { return static_cast<char>(std::tolower(c)); });
    return r;
}

struct ScancodeTable {
    KeyCode map[SDL_NUM_SCANCODES];
    ScancodeTable() {
        for (auto& k : map) k = KeyCode::Unknown;
        for (int i = 0; i < 26; ++i) map[SDL_SCANCODE_A + i] = static_cast<KeyCode>(static_cast<int>(KeyCode::A) + i);
        for (int i = 0; i < 9;  ++i) map[SDL_SCANCODE_1 + i] = static_cast<KeyCode>(static_cast<int>(KeyCode::Num1) + i);
        map[SDL_SCANCODE_0] = KeyCode::Num0;
        for (int i = 0; i < 12; ++i) map[SDL_SCANCODE_F1 + i] = static_cast<KeyCode>(static_cast<int>(KeyCode::F1) + i);
        map[SDL_SCANCODE_UP] = KeyCode::Up;       map[SDL_SCANCODE_DOWN] = KeyCode::Down;
        map[SDL_SCANCODE_LEFT] = KeyCode::Left;   map[SDL_SCANCODE_RIGHT] = KeyCode::Right;
        map[SDL_SCANCODE_SPACE] = KeyCode::Space; map[SDL_SCANCODE_RETURN] = KeyCode::Enter;
        map[SDL_SCANCODE_ESCAPE] = KeyCode::Escape; map[SDL_SCANCODE_TAB] = KeyCode::Tab;
        map[SDL_SCANCODE_BACKSPACE] = KeyCode::Backspace; map[SDL_SCANCODE_DELETE] = KeyCode::Delete;
        map[SDL_SCANCODE_INSERT] = KeyCode::Insert; map[SDL_SCANCODE_HOME] = KeyCode::Home; map[SDL_SCANCODE_END] = KeyCode::End;
        map[SDL_SCANCODE_PAGEUP] = KeyCode::PageUp; map[SDL_SCANCODE_PAGEDOWN] = KeyCode::PageDown;
        map[SDL_SCANCODE_LSHIFT] = KeyCode::LShift; map[SDL_SCANCODE_RSHIFT] = KeyCode::RShift;
        map[SDL_SCANCODE_LCTRL] = KeyCode::LCtrl;   map[SDL_SCANCODE_RCTRL] = KeyCode::RCtrl;
        map[SDL_SCANCODE_LALT] = KeyCode::LAlt;     map[SDL_SCANCODE_RALT] = KeyCode::RAlt;
        map[SDL_SCANCODE_COMMA] = KeyCode::Comma;   map[SDL_SCANCODE_PERIOD] = KeyCode::Period;
        map[SDL_SCANCODE_SLASH] = KeyCode::Slash;   map[SDL_SCANCODE_SEMICOLON] = KeyCode::Semicolon;
        map[SDL_SCANCODE_APOSTROPHE] = KeyCode::Apostrophe;
        map[SDL_SCANCODE_LEFTBRACKET] = KeyCode::LeftBracket; map[SDL_SCANCODE_RIGHTBRACKET] = KeyCode::RightBracket;
        map[SDL_SCANCODE_BACKSLASH] = KeyCode::Backslash;     map[SDL_SCANCODE_MINUS] = KeyCode::Minus;
        map[SDL_SCANCODE_EQUALS] = KeyCode::Equals;           map[SDL_SCANCODE_GRAVE] = KeyCode::Grave;
        map[SDL_SCANCODE_KP_0] = KeyCode::Keypad0;
        for (int i = 0; i < 9; ++i) map[SDL_SCANCODE_KP_1 + i] = static_cast<KeyCode>(static_cast<int>(KeyCode::Keypad1) + i);
        map[SDL_SCANCODE_KP_PLUS] = KeyCode::KeypadPlus; map[SDL_SCANCODE_KP_MINUS] = KeyCode::KeypadMinus;
        map[SDL_SCANCODE_KP_ENTER] = KeyCode::KeypadEnter;
    }
};

} // namespace

KeyCode KeyCodeFromScancode(int sc) {
    static const ScancodeTable table;
    if (sc <= 0 || sc >= SDL_NUM_SCANCODES) return KeyCode::Unknown;
    return table.map[sc];
}

MouseButton MouseButtonFromSdl(int b) {
    switch (b) {
        case SDL_BUTTON_LEFT:   return MouseButton::Left;
        case SDL_BUTTON_MIDDLE: return MouseButton::Middle;
        case SDL_BUTTON_RIGHT:  return MouseButton::Right;
        case SDL_BUTTON_X1:     return MouseButton::X1;
        case SDL_BUTTON_X2:     return MouseButton::X2;
        default:                return MouseButton::Count;
    }
}

const char* KeyName(KeyCode key) {
    const int i = static_cast<int>(key);
    return (i >= 0 && i < kKeyCount) ? kKeyNames[i] : "Unknown";
}

KeyCode KeyCodeFromName(const std::string& name) {
    static const std::unordered_map<std::string, KeyCode> table = [] {
        std::unordered_map<std::string, KeyCode> t;
        for (int i = 1; i < kKeyCount; ++i) t[Lower(kKeyNames[i])] = static_cast<KeyCode>(i);
        return t;
    }();
    auto it = table.find(Lower(name));
    return it == table.end() ? KeyCode::Unknown : it->second;
}

const char* MouseButtonName(MouseButton b) {
    switch (b) {
        case MouseButton::Left: return "Left";   case MouseButton::Middle: return "Middle";
        case MouseButton::Right: return "Right"; case MouseButton::X1: return "X1";
        case MouseButton::X2: return "X2";       default: return "Unknown";
    }
}

bool MouseButtonFromName(const std::string& name, MouseButton& out) {
    const std::string n = Lower(name);
    for (int i = 0; i < kMouseButtonCount; ++i) {
        if (Lower(MouseButtonName(static_cast<MouseButton>(i))) == n) { out = static_cast<MouseButton>(i); return true; }
    }
    return false;
}

} // namespace engine
