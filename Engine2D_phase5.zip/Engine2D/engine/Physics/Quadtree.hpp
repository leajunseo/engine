#pragma once
// ---------------------------------------------------------------------------
// 쿼드트리 브로드페이즈 (매 스텝 재구성).
//   - 아이템 = (id, AABB). 자식 사분면에 '완전히' 들어가는 것만 내려 보내고, 경계에 걸친 것은 부모에 남긴다.
//   - QueryPairs : 같은 노드끼리 + 조상 노드의 아이템과 겹치는 후보 쌍을 중복 없이 출력.
//   - 전부 정적 배열(vector) 기반 + 재사용 -> 안정 상태에서 힙 할당 거의 없음.
// [Bottleneck] 노드를 넘나드는 큰 물체(예: 바닥)는 루트에 남아 모든 아이템과 검사된다 (O(n), 보통 1~몇 개).
//   움직이는 물체가 매우 많고 일부만 움직이면 증분 갱신(loose quadtree)으로 개선할 수 있다.
// ---------------------------------------------------------------------------
#include <cstdint>
#include <functional>
#include <utility>
#include <vector>

#include "Physics/Collision.hpp"

namespace engine {

class Quadtree {
public:
    static constexpr int kMaxDepth = 8;
    static constexpr int kSplitThreshold = 8;

    void Reset(const AABB& bounds);                       // 이전 내용을 비우고 새 루트 영역으로 시작
    void Insert(std::uint32_t id, const AABB& box);       // 루트 영역 밖이라도 루트에 보관되므로 안전
    void QueryPairs(std::vector<std::pair<std::uint32_t, std::uint32_t>>& out) const;   // (작은 id, 큰 id) 정렬되지 않음
    void Query(const AABB& box, std::vector<std::uint32_t>& out) const;                 // box 와 AABB 가 겹치는 아이템

    /// 디버그 표시용: 모든 노드의 (영역, 깊이, 보관 중인 아이템 수)
    void ForEachNode(const std::function<void(const AABB&, int depth, int items)>& fn) const;

    std::size_t NodeCount() const { return nodes_.size(); }
    std::size_t ItemCount() const { return items_.size(); }

private:
    struct Item { std::uint32_t id; AABB box; int next; };
    struct Node { AABB bounds; int child[4]; int head; int count; };

    int  NewNode(const AABB& b);
    int  FitChild(const Node& n, const AABB& box) const;   // 0..3 또는 -1
    AABB ChildBounds(const AABB& b, int q) const;
    void InsertAt(int node, int item, int depth);
    void Split(int node, int depth);
    void PairsRec(int node, std::vector<int>& stack, std::vector<std::pair<std::uint32_t, std::uint32_t>>& out) const;
    void QueryRec(int node, const AABB& box, std::vector<std::uint32_t>& out) const;
    void NodesRec(int node, int depth, const std::function<void(const AABB&, int, int)>& fn) const;

    std::vector<Node> nodes_;
    std::vector<Item> items_;
};

} // namespace engine
