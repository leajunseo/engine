#pragma once
// ---------------------------------------------------------------------------
// 충돌 도형 + 내로페이즈(narrow phase).
//   도형 : Circle / Box(회전 가능한 직사각형) / Polygon(볼록, 최대 8 꼭짓점)
//   판정 : 원-원, 다각형-원, 다각형-다각형(SAT + 참조면/입사면 클리핑), 회전 0 인 박스끼리는 AABB 고속 경로
//   결과 : Manifold = 법선(A -> B) + 접촉점 최대 2개(위치, 침투 깊이, 피처 ID)
// 좌표계는 엔진 공통(Y-up). 모든 도형의 로컬 원점 = 무게중심.
// ---------------------------------------------------------------------------
#include <cstdint>

#include "Math/Math.hpp"

namespace engine {

struct AABB {
    Vec2 min{0.0f, 0.0f}, max{0.0f, 0.0f};

    bool Overlaps(const AABB& o) const {
        return min.x <= o.max.x && max.x >= o.min.x && min.y <= o.max.y && max.y >= o.min.y;
    }
    bool Contains(const AABB& o) const {            // o 가 완전히 내부에 있는가
        return o.min.x >= min.x && o.max.x <= max.x && o.min.y >= min.y && o.max.y <= max.y;
    }
    bool ContainsPoint(Vec2 p) const { return p.x >= min.x && p.x <= max.x && p.y >= min.y && p.y <= max.y; }
    Vec2 Center() const { return {(min.x + max.x) * 0.5f, (min.y + max.y) * 0.5f}; }
    Vec2 Extents() const { return {(max.x - min.x) * 0.5f, (max.y - min.y) * 0.5f}; }
    void Merge(const AABB& o) {
        if (o.min.x < min.x) min.x = o.min.x;
        if (o.min.y < min.y) min.y = o.min.y;
        if (o.max.x > max.x) max.x = o.max.x;
        if (o.max.y > max.y) max.y = o.max.y;
    }
};

/// 위치 + 회전(cos/sin 캐시). 월드 = R * local + p.
struct Transform2D {
    Vec2  p{0.0f, 0.0f};
    float c = 1.0f, s = 0.0f;

    static Transform2D Make(Vec2 pos, float angle) { return {pos, std::cos(angle), std::sin(angle)}; }
    Vec2 Rotate(Vec2 v) const { return {c * v.x - s * v.y, s * v.x + c * v.y}; }
    Vec2 Apply(Vec2 v) const  { return Rotate(v) + p; }
    Vec2 ApplyInverse(Vec2 w) const {
        const Vec2 d = w - p;
        return {c * d.x + s * d.y, -s * d.x + c * d.y};
    }
};

enum class ShapeType : std::uint8_t { Circle, Box, Polygon };

struct Shape {
    static constexpr int kMaxVertices = 8;

    ShapeType type   = ShapeType::Circle;
    float     radius = 16.0f;                 // Circle
    Vec2      halfExtents{16.0f, 16.0f};      // Box (로컬 축 기준 절반 크기)
    int       count  = 0;                     // Box/Polygon 꼭짓점 수 (CCW)
    Vec2      verts[kMaxVertices];            // 로컬 꼭짓점 (무게중심이 원점)
    Vec2      normals[kMaxVertices];          // 모서리 i (verts[i] -> verts[i+1]) 의 바깥 법선

    static Shape MakeCircle(float radius);
    static Shape MakeBox(float halfWidth, float halfHeight);
    /// 볼록 다각형. 3~8개 점, 시계/반시계 무관, 무게중심이 원점이 되도록 자동 이동.
    /// 볼록하지 않거나 면적이 0 이면 false (out 은 건드리지 않음).
    static bool TryMakePolygon(const Vec2* points, int n, Shape& out);
    /// 중심 원점, 외접 반지름 circumRadius 인 정n각형 (꼭짓점 0 이 위쪽(+Y)). 3 <= n <= 8.
    static Shape MakeRegularPolygon(int n, float circumRadius);

    float Area() const;
    float InertiaPerDensity() const;          // 무게중심 기준 관성 모멘트 / 밀도
    AABB  ComputeAABB(const Transform2D& xf) const;
    bool  ContainsPoint(const Transform2D& xf, Vec2 worldPoint) const;
};

struct ContactPoint {
    Vec2          position;                   // 두 표면의 중간 지점 (월드)
    float         separation = 0.0f;          // 음수 = 침투 깊이
    std::uint32_t id = 0;                     // 프레임 간 접촉점 매칭용 피처 ID (warm starting)
    float         normalImpulse  = 0.0f;      // 솔버가 누적하는 값 (warm starting 으로 이월)
    float         tangentImpulse = 0.0f;
};

struct Manifold {
    Vec2         normal{0.0f, 0.0f};          // A -> B 방향 단위 벡터
    int          count = 0;                   // 0, 1, 2
    ContactPoint points[2];
};

/// 도형 쌍 판정 (법선은 항상 A -> B). 겹치면 true 와 함께 manifold 를 채운다.
bool Collide(const Shape& a, const Transform2D& xa, const Shape& b, const Transform2D& xb, Manifold& m);

// 개별 알고리즘 (테스트/직접 사용용)
bool CollideCircles(const Shape& a, const Transform2D& xa, const Shape& b, const Transform2D& xb, Manifold& m);
bool CollidePolygonCircle(const Shape& poly, const Transform2D& xp, const Shape& circle, const Transform2D& xc, Manifold& m);
bool CollidePolygons(const Shape& a, const Transform2D& xa, const Shape& b, const Transform2D& xb, Manifold& m);   // SAT + 클리핑
bool CollideAABBs(const Shape& a, const Transform2D& xa, const Shape& b, const Transform2D& xb, Manifold& m);      // 둘 다 회전 0 인 Box

} // namespace engine
