#pragma once
// ---------------------------------------------------------------------------
// 2D 강체 물리 월드.
//   파이프라인 (Step 1회) :
//     1) 힘/중력 적분(속도)  2) 쿼드트리 브로드페이즈  3) 내로페이즈(Manifold)  4) 순차 임펄스 솔버(warm starting,
//     마찰, 반발)  5) 위치 적분  6) 침투 보정  7) AABB/트리 갱신  8) 이벤트 발행
//   - 고정 타임스텝(Application::OnFixedUpdate)에서 호출하는 것을 전제로 한다. 같은 입력이면 항상 같은 결과(결정론).
//   - 렌더는 prevPosition/prevRotation 과 현재 값을 alpha 로 보간한다 (InterpolatedPosition/Rotation).
//   - 이벤트는 Step 이 끝난 뒤(월드가 일관된 상태일 때) 발행되므로 핸들러 안에서 Create/DestroyBody 해도 안전하다.
//     (단, 핸들러가 받은 BodyId 는 IsValid 로 확인할 것)
//   - 단위는 임의(기본값은 '픽셀' 스케일: 중력 980 단위/s²). 다른 스케일을 쓰면 PhysicsSettings 를 맞출 것.
// ---------------------------------------------------------------------------
#include <cstdint>
#include <unordered_map>
#include <utility>
#include <vector>

#include "Core/EventBus.hpp"
#include "Math/Math.hpp"
#include "Physics/Collision.hpp"
#include "Physics/Quadtree.hpp"

namespace engine {

struct BodyId {
    std::uint32_t index = 0xFFFFFFFFu;
    std::uint32_t generation = 0;
    bool Valid() const { return index != 0xFFFFFFFFu; }
    bool operator==(const BodyId& o) const { return index == o.index && generation == o.generation; }
    bool operator!=(const BodyId& o) const { return !(*this == o); }
};

enum class BodyType : std::uint8_t {
    Static,      // 움직이지 않음 (바닥, 벽)
    Kinematic,   // 속도로만 움직임, 충돌에 밀리지 않음 (움직이는 발판)
    Dynamic      // 힘/충돌에 반응
};

struct BodyDef {
    BodyType type = BodyType::Dynamic;
    Shape    shape = Shape::MakeCircle(16.0f);
    Vec2     position{0.0f, 0.0f};
    float    rotation = 0.0f;                 // 라디안, 반시계
    Vec2     velocity{0.0f, 0.0f};
    float    angularVelocity = 0.0f;
    float    density = 1.0f;                  // 질량 = 밀도 x 면적
    float    restitution = 0.3f;              // 반발 계수 0..1 (두 물체 중 큰 값 사용)
    float    friction = 0.5f;                 // 마찰 계수 (sqrt(a*b))
    float    linearDamping = 0.0f;
    float    angularDamping = 0.05f;
    float    gravityScale = 1.0f;
    std::uint32_t layer = 1u;                 // 나는 어떤 레이어인가 (비트)
    std::uint32_t mask  = 0xFFFFFFFFu;        // 어떤 레이어와 충돌하는가 (비트)
    bool     isSensor = false;                // true: 겹침만 감지(트리거), 충돌 반응 없음
    bool     fixedRotation = false;           // true: 회전하지 않음 (캐릭터용)
    void*    userData = nullptr;
};

struct Body {
    BodyType type = BodyType::Dynamic;
    Shape    shape;
    Vec2     position{0.0f, 0.0f};
    float    rotation = 0.0f;
    Vec2     velocity{0.0f, 0.0f};
    float    angularVelocity = 0.0f;
    Vec2     prevPosition{0.0f, 0.0f};        // 직전 고정 스텝의 상태 (렌더 보간용)
    float    prevRotation = 0.0f;
    float    mass = 0.0f, invMass = 0.0f, inertia = 0.0f, invInertia = 0.0f;
    float    restitution = 0.3f, friction = 0.5f, linearDamping = 0.0f, angularDamping = 0.0f, gravityScale = 1.0f;
    std::uint32_t layer = 1u, mask = 0xFFFFFFFFu;
    bool     isSensor = false, fixedRotation = false;
    void*    userData = nullptr;

    Vec2     force{0.0f, 0.0f};               // 다음 Step 에 적용되고 비워짐
    float    torque = 0.0f;
    Transform2D xf;                           // position/rotation 의 캐시 (SetTransform 으로만 갱신할 것)
    AABB     aabb;
    std::uint32_t generation = 0;
    bool     alive = false;
};

struct PhysicsSettings {
    Vec2  gravity{0.0f, -980.0f};
    int   velocityIterations = 10;
    float linearSlop = 0.5f;                  // 허용 침투 (떨림 방지). 월드 단위
    float positionCorrection = 0.4f;          // 침투 보정 비율 0..1
    float restitutionThreshold = 200.0f;      // 이 속도(단위/s)보다 느린 충돌은 반발 없음
    float maxLinearSpeed = 0.0f;              // 0 = 제한 없음. 터널링이 심하면 설정
};

struct PhysicsStats {
    int    bodies = 0, broadPairs = 0, contacts = 0, triggers = 0;
    std::size_t treeNodes = 0;
    double stepMs = 0.0;
};

// ---- EventBus 로 발행되는 이벤트 (PhysicsWorld::SetEventBus 로 연결했을 때) ----
struct CollisionBeginEvent {
    BodyId a, b;                 // a.index < b.index
    Vec2   normal;               // a -> b
    Vec2   point;
    float  depth;                // 첫 접촉점의 침투 깊이
    float  impactSpeed;          // 충돌 직전 법선 방향 상대 속도 (효과음 세기 등에 사용)
};
struct CollisionEndEvent { BodyId a, b; };
struct TriggerEnterEvent { BodyId sensor, other; };
struct TriggerExitEvent  { BodyId sensor, other; };

class PhysicsWorld {
public:
    PhysicsWorld() = default;
    PhysicsWorld(const PhysicsWorld&)            = delete;
    PhysicsWorld& operator=(const PhysicsWorld&) = delete;

    void SetEventBus(EventBus* bus) { bus_ = bus; }
    PhysicsSettings&       Settings()       { return settings_; }
    const PhysicsSettings& Settings() const { return settings_; }

    // ---- 바디 수명 ----
    BodyId CreateBody(const BodyDef& def);
    void   DestroyBody(BodyId id);
    bool   IsValid(BodyId id) const;
    Body*       Get(BodyId id);               // 무효 id 면 nullptr. CreateBody 후에는 이전 포인터가 무효가 될 수 있음
    const Body* Get(BodyId id) const;
    void   Clear();                           // 전부 삭제

    // ---- 상태 변경 ----
    void SetTransform(BodyId id, Vec2 position, float rotation);   // 순간이동 (보간 없음)
    void ApplyForce(BodyId id, Vec2 force);                        // 무게중심에 (다음 스텝 1회)
    void ApplyForceAtPoint(BodyId id, Vec2 force, Vec2 worldPoint);
    void ApplyImpulse(BodyId id, Vec2 impulse, Vec2 worldPoint);   // 즉시 속도 변화

    // ---- 시뮬레이션 ----
    void Step(float dt);

    // ---- 질의 ----
    void   QueryAABB(const AABB& box, std::vector<BodyId>& out) const;     // AABB 가 겹치는 바디
    void   QueryPoint(Vec2 worldPoint, std::vector<BodyId>& out) const;    // 도형이 점을 포함하는 바디
    BodyId PickBody(Vec2 worldPoint) const;                                // 점 아래의 Dynamic 바디 (없으면 무효 id)

    // ---- 렌더/디버그 지원 ----
    template <class F> void ForEachBody(F&& f) const {                      // f(BodyId, const Body&)
        for (std::uint32_t i = 0; i < bodies_.size(); ++i)
            if (bodies_[i].alive) f(BodyId{i, bodies_[i].generation}, bodies_[i]);
    }
    struct ContactInfo { BodyId a, b; Manifold manifold; };
    const std::vector<ContactInfo>& Contacts() const { return debugContacts_; }   // 직전 Step 의 (비센서) 접촉
    const Quadtree& Tree() const { EnsureTree(); return tree_; }
    const PhysicsStats& Stats() const { return stats_; }
    static Vec2  InterpolatedPosition(const Body& b, float alpha) { return Lerp(b.prevPosition, b.position, alpha); }
    static float InterpolatedRotation(const Body& b, float alpha) { return Lerp(b.prevRotation, b.rotation, alpha); }

private:
    struct PointSolver { Vec2 rA, rB; float normalMass = 0, tangentMass = 0, bounce = 0; };
    struct Contact {
        std::uint32_t a = 0, b = 0;           // bodies_ 인덱스 (a < b)
        Manifold m;
        float friction = 0, restitution = 0;
        PointSolver ps[2];
        std::uint64_t key = 0;
    };
    struct PairState {
        BodyId   a, b;
        bool     sensor = false;
        Manifold manifold;                    // 직전 스텝 결과 (warm starting 용 임펄스 포함)
        std::uint64_t stamp = 0;
    };
    struct PendingEvent {
        enum Kind { Begin, End, TriggerIn, TriggerOut } kind;
        BodyId a, b;
        Vec2 normal, point;
        float depth = 0, impact = 0;
    };

    void EnsureTree() const;
    void RebuildTree() const;
    void RefreshBody(Body& b);
    void PrepareContact(Contact& c);
    void SolveVelocity(Contact& c);
    void WarmStart(Contact& c);
    void Publish();

    PhysicsSettings settings_;
    EventBus*       bus_ = nullptr;

    std::vector<Body>          bodies_;
    std::vector<std::uint32_t> freeList_;

    mutable Quadtree tree_;
    mutable bool     treeDirty_ = true;

    std::vector<std::pair<std::uint32_t, std::uint32_t>> broadPairs_;
    std::vector<Contact>                                 contacts_;
    std::vector<ContactInfo>                             debugContacts_;
    std::unordered_map<std::uint64_t, PairState>         pairState_;
    std::vector<PendingEvent>                            events_;
    std::uint64_t                                        stamp_ = 0;
    PhysicsStats                                         stats_;
};

} // namespace engine
