#include "Physics/Quadtree.hpp"

namespace engine {

void Quadtree::Reset(const AABB& bounds) {
    nodes_.clear();
    items_.clear();
    NewNode(bounds);
}

int Quadtree::NewNode(const AABB& b) {
    Node n;
    n.bounds = b;
    n.child[0] = n.child[1] = n.child[2] = n.child[3] = -1;
    n.head = -1;
    n.count = 0;
    nodes_.push_back(n);
    return static_cast<int>(nodes_.size()) - 1;
}

AABB Quadtree::ChildBounds(const AABB& b, int q) const {
    const Vec2 c = b.Center();
    // q: 0=좌하 1=우하 2=좌상 3=우상
    AABB r;
    r.min = {(q & 1) ? c.x : b.min.x, (q & 2) ? c.y : b.min.y};
    r.max = {(q & 1) ? b.max.x : c.x, (q & 2) ? b.max.y : c.y};
    return r;
}

int Quadtree::FitChild(const Node& n, const AABB& box) const {
    if (!n.bounds.Contains(box)) return -1;                   // 영역 밖으로 나간 아이템은 현재 노드에 보관 (Query 가지치기 안전성)
    const Vec2 c = n.bounds.Center();
    const bool left  = box.max.x <= c.x, right = box.min.x >= c.x;
    const bool below = box.max.y <= c.y, above = box.min.y >= c.y;
    if (!(left || right) || !(below || above)) return -1;     // 중심선에 걸침
    return (right ? 1 : 0) | (above ? 2 : 0);
}

void Quadtree::Insert(std::uint32_t id, const AABB& box) {
    items_.push_back({id, box, -1});
    InsertAt(0, static_cast<int>(items_.size()) - 1, 0);
}

void Quadtree::InsertAt(int node, int item, int depth) {
    for (;;) {
        if (nodes_[static_cast<std::size_t>(node)].child[0] >= 0) {          // 내부 노드
            const int q = FitChild(nodes_[static_cast<std::size_t>(node)], items_[static_cast<std::size_t>(item)].box);
            if (q < 0) break;                                                  // 걸쳐 있음 -> 이 노드가 보관
            node = nodes_[static_cast<std::size_t>(node)].child[q];
            ++depth;
            continue;
        }
        break;
    }
    Node& n = nodes_[static_cast<std::size_t>(node)];
    items_[static_cast<std::size_t>(item)].next = n.head;
    n.head = item;
    ++n.count;
    if (n.child[0] < 0 && n.count > kSplitThreshold && depth < kMaxDepth) Split(node, depth);
}

void Quadtree::Split(int node, int depth) {
    const AABB b = nodes_[static_cast<std::size_t>(node)].bounds;
    int kids[4];
    for (int q = 0; q < 4; ++q) kids[q] = NewNode(ChildBounds(b, q));          // push_back: 참조 무효화 주의
    for (int q = 0; q < 4; ++q) nodes_[static_cast<std::size_t>(node)].child[q] = kids[q];

    int it = nodes_[static_cast<std::size_t>(node)].head;
    nodes_[static_cast<std::size_t>(node)].head = -1;
    nodes_[static_cast<std::size_t>(node)].count = 0;
    while (it >= 0) {
        const int next = items_[static_cast<std::size_t>(it)].next;
        const int q = FitChild(nodes_[static_cast<std::size_t>(node)], items_[static_cast<std::size_t>(it)].box);
        if (q < 0) {                                                           // 계속 이 노드에 남김
            Node& n = nodes_[static_cast<std::size_t>(node)];
            items_[static_cast<std::size_t>(it)].next = n.head;
            n.head = it;
            ++n.count;
        } else {
            InsertAt(kids[q], it, depth + 1);
        }
        it = next;
    }
}

void Quadtree::PairsRec(int node, std::vector<int>& stack, std::vector<std::pair<std::uint32_t, std::uint32_t>>& out) const {
    const Node& n = nodes_[static_cast<std::size_t>(node)];
    // 1) 같은 노드 안의 쌍
    for (int i = n.head; i >= 0; i = items_[static_cast<std::size_t>(i)].next) {
        const Item& a = items_[static_cast<std::size_t>(i)];
        for (int j = items_[static_cast<std::size_t>(i)].next; j >= 0; j = items_[static_cast<std::size_t>(j)].next) {
            const Item& b = items_[static_cast<std::size_t>(j)];
            if (a.box.Overlaps(b.box)) out.emplace_back(a.id, b.id);
        }
        // 2) 조상 노드 아이템과의 쌍
        for (int anc : stack) {
            const Item& b = items_[static_cast<std::size_t>(anc)];
            if (a.box.Overlaps(b.box)) out.emplace_back(a.id, b.id);
        }
    }
    if (n.child[0] < 0) return;
    const std::size_t mark = stack.size();
    for (int i = n.head; i >= 0; i = items_[static_cast<std::size_t>(i)].next) stack.push_back(i);
    for (int q = 0; q < 4; ++q) PairsRec(n.child[q], stack, out);
    stack.resize(mark);
}

void Quadtree::QueryPairs(std::vector<std::pair<std::uint32_t, std::uint32_t>>& out) const {
    out.clear();
    if (nodes_.empty()) return;
    std::vector<int> stack;
    stack.reserve(64);
    PairsRec(0, stack, out);
}

void Quadtree::QueryRec(int node, const AABB& box, std::vector<std::uint32_t>& out) const {
    const Node& n = nodes_[static_cast<std::size_t>(node)];
    for (int i = n.head; i >= 0; i = items_[static_cast<std::size_t>(i)].next) {
        const Item& it = items_[static_cast<std::size_t>(i)];
        if (it.box.Overlaps(box)) out.push_back(it.id);
    }
    if (n.child[0] < 0) return;
    for (int q = 0; q < 4; ++q) {
        const Node& c = nodes_[static_cast<std::size_t>(n.child[q])];
        // 자식 영역 밖으로 삐져나온 아이템은 부모에 있으므로, 자식 영역과 box 가 겹칠 때만 내려간다
        if (c.bounds.Overlaps(box)) QueryRec(n.child[q], box, out);
    }
}

void Quadtree::Query(const AABB& box, std::vector<std::uint32_t>& out) const {
    out.clear();
    if (!nodes_.empty()) QueryRec(0, box, out);
}

void Quadtree::NodesRec(int node, int depth, const std::function<void(const AABB&, int, int)>& fn) const {
    const Node& n = nodes_[static_cast<std::size_t>(node)];
    fn(n.bounds, depth, n.count);
    if (n.child[0] < 0) return;
    for (int q = 0; q < 4; ++q) NodesRec(n.child[q], depth + 1, fn);
}

void Quadtree::ForEachNode(const std::function<void(const AABB&, int, int)>& fn) const {
    if (!nodes_.empty()) NodesRec(0, 0, fn);
}

} // namespace engine
