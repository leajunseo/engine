#include "Physics/Collision.hpp"

#include <algorithm>
#include <cfloat>
#include <cmath>

namespace engine {

namespace {

constexpr float kEps = 1e-6f;
constexpr float kRelTol = 0.05f;       // 참조면 선택 편향 (플리커 방지)

bool IsAxisAligned(const Transform2D& x) { return std::fabs(x.s) < 1e-6f && x.c > 0.0f; }

struct WorldPoly {
    Vec2 v[Shape::kMaxVertices];
    Vec2 n[Shape::kMaxVertices];
    int  count = 0;
};

WorldPoly ToWorld(const Shape& s, const Transform2D& x) {
    WorldPoly w;
    w.count = s.count;
    for (int i = 0; i < s.count; ++i) {
        w.v[i] = x.Apply(s.verts[i]);
        w.n[i] = x.Rotate(s.normals[i]);
    }
    return w;
}

/// A 의 각 면 법선 방향으로 B 의 꼭짓점들이 얼마나 떨어져 있는지 -> 가장 큰(= 가장 덜 침투한) 면.
float FindMaxSeparation(const WorldPoly& A, const WorldPoly& B, int& edge) {
    float best = -FLT_MAX;
    edge = 0;
    for (int i = 0; i < A.count; ++i) {
        float minDot = FLT_MAX;
        for (int j = 0; j < B.count; ++j) minDot = std::min(minDot, Dot(A.n[i], B.v[j] - A.v[i]));
        if (minDot > best) { best = minDot; edge = i; }
    }
    return best;
}

int ClipSegment(Vec2 out[2], const Vec2 in[2], Vec2 normal, float offset) {
    int n = 0;
    const float d0 = Dot(normal, in[0]) - offset;
    const float d1 = Dot(normal, in[1]) - offset;
    if (d0 <= 0.0f) out[n++] = in[0];
    if (d1 <= 0.0f) out[n++] = in[1];
    if (d0 * d1 < 0.0f) {
        const float t = d0 / (d0 - d1);
        out[n++] = in[0] + (in[1] - in[0]) * t;
    }
    return n;
}

} // namespace

// ---------------------------------------------------------------- Shape
Shape Shape::MakeCircle(float r) {
    Shape s;
    s.type = ShapeType::Circle;
    s.radius = r;
    return s;
}

Shape Shape::MakeBox(float hw, float hh) {
    Shape s;
    s.type = ShapeType::Box;
    s.halfExtents = {hw, hh};
    s.count = 4;
    s.verts[0] = {-hw, -hh}; s.verts[1] = { hw, -hh}; s.verts[2] = { hw,  hh}; s.verts[3] = {-hw,  hh};   // CCW
    s.normals[0] = {0, -1};  s.normals[1] = {1, 0};   s.normals[2] = {0, 1};   s.normals[3] = {-1, 0};
    return s;
}

bool Shape::TryMakePolygon(const Vec2* pts, int n, Shape& out) {
    if (!pts || n < 3 || n > kMaxVertices) return false;
    Vec2 v[kMaxVertices];
    for (int i = 0; i < n; ++i) v[i] = pts[i];

    float area2 = 0.0f;
    for (int i = 0; i < n; ++i) area2 += Cross(v[i], v[(i + 1) % n]);
    if (std::fabs(area2) < 1e-6f) return false;
    if (area2 < 0.0f) std::reverse(v, v + n);                      // CCW 로 통일

    for (int i = 0; i < n; ++i) {                                  // 볼록성 검사
        const Vec2 e0 = v[(i + 1) % n] - v[i], e1 = v[(i + 2) % n] - v[(i + 1) % n];
        if (Cross(e0, e1) < -1e-4f * std::max(1.0f, e0.Length() * e1.Length())) return false;
    }

    Vec2 centroid{0.0f, 0.0f};                                     // 삼각형 부채 면적 가중 무게중심
    float a2 = 0.0f;
    for (int i = 0; i < n; ++i) {
        const Vec2 p0 = v[i], p1 = v[(i + 1) % n];
        const float w = Cross(p0, p1);
        centroid += (p0 + p1) * w;
        a2 += w;
    }
    centroid = centroid / (3.0f * a2);

    Shape s;
    s.type = ShapeType::Polygon;
    s.count = n;
    for (int i = 0; i < n; ++i) s.verts[i] = v[i] - centroid;
    for (int i = 0; i < n; ++i) {
        const Vec2 e = s.verts[(i + 1) % n] - s.verts[i];
        s.normals[i] = Normalized(Vec2{e.y, -e.x});
    }
    out = s;
    return true;
}

Shape Shape::MakeRegularPolygon(int n, float R) {
    n = std::max(3, std::min(n, kMaxVertices));
    Vec2 pts[kMaxVertices];
    for (int i = 0; i < n; ++i) {
        const float a = kPi * 0.5f + 2.0f * kPi * static_cast<float>(i) / static_cast<float>(n);
        pts[i] = {R * std::cos(a), R * std::sin(a)};
    }
    Shape s;
    TryMakePolygon(pts, n, s);
    return s;
}

float Shape::Area() const {
    if (type == ShapeType::Circle) return kPi * radius * radius;
    float a2 = 0.0f;
    for (int i = 0; i < count; ++i) a2 += Cross(verts[i], verts[(i + 1) % count]);
    return 0.5f * a2;
}

float Shape::InertiaPerDensity() const {
    if (type == ShapeType::Circle) return 0.5f * Area() * radius * radius;
    float num = 0.0f, a2 = 0.0f;
    for (int i = 0; i < count; ++i) {
        const Vec2 p0 = verts[i], p1 = verts[(i + 1) % count];
        const float w = Cross(p0, p1);
        num += w * (Dot(p0, p0) + Dot(p0, p1) + Dot(p1, p1));
        a2 += w;
    }
    (void)a2;
    return num / 12.0f;
}

AABB Shape::ComputeAABB(const Transform2D& xf) const {
    AABB b;
    if (type == ShapeType::Circle) {
        b.min = {xf.p.x - radius, xf.p.y - radius};
        b.max = {xf.p.x + radius, xf.p.y + radius};
        return b;
    }
    b.min = b.max = xf.Apply(verts[0]);
    for (int i = 1; i < count; ++i) {
        const Vec2 w = xf.Apply(verts[i]);
        b.min = {std::min(b.min.x, w.x), std::min(b.min.y, w.y)};
        b.max = {std::max(b.max.x, w.x), std::max(b.max.y, w.y)};
    }
    return b;
}

bool Shape::ContainsPoint(const Transform2D& xf, Vec2 wp) const {
    const Vec2 l = xf.ApplyInverse(wp);
    if (type == ShapeType::Circle) return l.LengthSq() <= radius * radius;
    for (int i = 0; i < count; ++i)
        if (Dot(normals[i], l - verts[i]) > 0.0f) return false;
    return true;
}

// ---------------------------------------------------------------- 원 - 원
bool CollideCircles(const Shape& a, const Transform2D& xa, const Shape& b, const Transform2D& xb, Manifold& m) {
    const Vec2  d = xb.p - xa.p;
    const float rs = a.radius + b.radius;
    const float d2 = d.LengthSq();
    if (d2 > rs * rs) return false;
    const float dist = std::sqrt(d2);
    const Vec2  n = dist > kEps ? d / dist : Vec2{1.0f, 0.0f};
    m.normal = n;
    m.count = 1;
    m.points[0].separation = dist - rs;
    m.points[0].position = xa.p + n * (a.radius + (dist - rs) * 0.5f);   // 표면 중간 지점
    m.points[0].id = 0;
    return true;
}

// ---------------------------------------------------------------- 다각형 - 원 (법선: 다각형 -> 원)
bool CollidePolygonCircle(const Shape& poly, const Transform2D& xp, const Shape& circle, const Transform2D& xc, Manifold& m) {
    const float r = circle.radius;
    const Vec2  c = xp.ApplyInverse(xc.p);               // 원 중심 (다각형 로컬)

    float best = -FLT_MAX;
    int   idx = 0;
    for (int i = 0; i < poly.count; ++i) {
        const float s = Dot(poly.normals[i], c - poly.verts[i]);
        if (s > r) return false;                         // 분리축 발견
        if (s > best) { best = s; idx = i; }
    }

    const Vec2 v1 = poly.verts[idx], v2 = poly.verts[(idx + 1) % poly.count];
    Vec2  nLocal;
    Vec2  midLocal;
    float sep;

    const float u1 = Dot(c - v1, v2 - v1);
    const float u2 = Dot(c - v2, v1 - v2);
    if (best >= kEps && u1 <= 0.0f) {                    // v1 꼭짓점 영역
        const Vec2 d = c - v1;
        const float dist = d.Length();
        if (dist > r) return false;
        nLocal = dist > kEps ? d / dist : poly.normals[idx];
        sep = dist - r;
        midLocal = (v1 + (c - nLocal * r)) * 0.5f;
    } else if (best >= kEps && u2 <= 0.0f) {             // v2 꼭짓점 영역
        const Vec2 d = c - v2;
        const float dist = d.Length();
        if (dist > r) return false;
        nLocal = dist > kEps ? d / dist : poly.normals[idx];
        sep = dist - r;
        midLocal = (v2 + (c - nLocal * r)) * 0.5f;
    } else {                                             // 면 영역 (중심이 내부여도 여기)
        nLocal = poly.normals[idx];
        sep = best - r;
        midLocal = c - nLocal * ((best + r) * 0.5f);
    }

    m.normal = xp.Rotate(nLocal);
    m.count = 1;
    m.points[0].separation = sep;
    m.points[0].position = xp.Apply(midLocal);
    m.points[0].id = 0;
    return true;
}

// ---------------------------------------------------------------- 다각형 - 다각형 (SAT + 클리핑)
bool CollidePolygons(const Shape& a, const Transform2D& xa, const Shape& b, const Transform2D& xb, Manifold& m) {
    const WorldPoly A = ToWorld(a, xa), B = ToWorld(b, xb);

    int edgeA = 0, edgeB = 0;
    const float sepA = FindMaxSeparation(A, B, edgeA);
    if (sepA > 0.0f) return false;
    const float sepB = FindMaxSeparation(B, A, edgeB);
    if (sepB > 0.0f) return false;

    const WorldPoly *ref, *inc;
    int  refEdge;
    bool flip;
    if (sepB > sepA + kRelTol) { ref = &B; inc = &A; refEdge = edgeB; flip = true; }
    else                       { ref = &A; inc = &B; refEdge = edgeA; flip = false; }

    const Vec2 nRef = ref->n[refEdge];
    int incEdge = 0;
    float minDot = FLT_MAX;
    for (int i = 0; i < inc->count; ++i) {               // 참조 법선과 가장 반대를 보는 면 = 입사면
        const float d = Dot(nRef, inc->n[i]);
        if (d < minDot) { minDot = d; incEdge = i; }
    }

    const Vec2 seg[2] = {inc->v[incEdge], inc->v[(incEdge + 1) % inc->count]};
    const Vec2 v1 = ref->v[refEdge], v2 = ref->v[(refEdge + 1) % ref->count];
    const Vec2 t = Normalized(v2 - v1);

    Vec2 c1[2], c2[2];
    if (ClipSegment(c1, seg, -t, -Dot(t, v1)) < 2) return false;
    if (ClipSegment(c2, c1, t, Dot(t, v2)) < 2) return false;

    m.normal = flip ? -nRef : nRef;
    m.count = 0;
    for (int k = 0; k < 2; ++k) {
        const float sep = Dot(nRef, c2[k] - v1);
        if (sep > 0.0f) continue;
        ContactPoint& cp = m.points[m.count++];
        cp.separation = sep;
        cp.position = c2[k] - nRef * (sep * 0.5f);
        cp.id = (flip ? 0x80000000u : 0u) | (static_cast<std::uint32_t>(refEdge) << 16) |
                (static_cast<std::uint32_t>(incEdge) << 8) | static_cast<std::uint32_t>(k);
    }
    return m.count > 0;
}

// ---------------------------------------------------------------- AABB - AABB (회전 0 인 Box 전용 고속 경로)
bool CollideAABBs(const Shape& a, const Transform2D& xa, const Shape& b, const Transform2D& xb, Manifold& m) {
    const Vec2 d = xb.p - xa.p;
    const float ox = a.halfExtents.x + b.halfExtents.x - std::fabs(d.x);
    if (ox < 0.0f) return false;
    const float oy = a.halfExtents.y + b.halfExtents.y - std::fabs(d.y);
    if (oy < 0.0f) return false;

    m.count = 2;
    if (ox < oy) {                                       // X 축이 최소 침투축 -> 세로 면끼리 접촉
        const float sgn = d.x < 0.0f ? -1.0f : 1.0f;
        m.normal = {sgn, 0.0f};
        const float x = (xa.p.x + sgn * a.halfExtents.x + xb.p.x - sgn * b.halfExtents.x) * 0.5f;
        const float y0 = std::max(xa.p.y - a.halfExtents.y, xb.p.y - b.halfExtents.y);
        const float y1 = std::min(xa.p.y + a.halfExtents.y, xb.p.y + b.halfExtents.y);
        m.points[0].position = {x, y0};
        m.points[1].position = {x, y1};
        m.points[0].id = 0x100u; m.points[1].id = 0x101u;
        m.points[0].separation = m.points[1].separation = -ox;
    } else {                                             // Y 축 -> 가로 면끼리 접촉
        const float sgn = d.y < 0.0f ? -1.0f : 1.0f;
        m.normal = {0.0f, sgn};
        const float y = (xa.p.y + sgn * a.halfExtents.y + xb.p.y - sgn * b.halfExtents.y) * 0.5f;
        const float x0 = std::max(xa.p.x - a.halfExtents.x, xb.p.x - b.halfExtents.x);
        const float x1 = std::min(xa.p.x + a.halfExtents.x, xb.p.x + b.halfExtents.x);
        m.points[0].position = {x0, y};
        m.points[1].position = {x1, y};
        m.points[0].id = 0x200u; m.points[1].id = 0x201u;
        m.points[0].separation = m.points[1].separation = -oy;
    }
    return true;
}

// ---------------------------------------------------------------- 디스패치
bool Collide(const Shape& a, const Transform2D& xa, const Shape& b, const Transform2D& xb, Manifold& m) {
    m.count = 0;
    m.points[0] = {};
    m.points[1] = {};
    const bool ca = a.type == ShapeType::Circle, cb = b.type == ShapeType::Circle;
    if (ca && cb) return CollideCircles(a, xa, b, xb, m);
    if (cb)       return CollidePolygonCircle(a, xa, b, xb, m);
    if (ca) {
        if (!CollidePolygonCircle(b, xb, a, xa, m)) return false;
        m.normal = -m.normal;                            // 다각형->원 을 원->다각형(A->B) 으로 뒤집기
        return true;
    }
    if (a.type == ShapeType::Box && b.type == ShapeType::Box && IsAxisAligned(xa) && IsAxisAligned(xb))
        return CollideAABBs(a, xa, b, xb, m);
    return CollidePolygons(a, xa, b, xb, m);
}

} // namespace engine
