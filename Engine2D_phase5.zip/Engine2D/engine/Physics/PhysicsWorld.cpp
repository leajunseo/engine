#include "Physics/PhysicsWorld.hpp"

#include <algorithm>
#include <chrono>

namespace engine {

namespace {
std::uint64_t PairKey(std::uint32_t a, std::uint32_t b) { return (static_cast<std::uint64_t>(a) << 32) | b; }
} // namespace

// ---------------------------------------------------------------- 수명
BodyId PhysicsWorld::CreateBody(const BodyDef& def) {
    std::uint32_t index;
    if (!freeList_.empty()) {
        index = freeList_.back();
        freeList_.pop_back();
    } else {
        index = static_cast<std::uint32_t>(bodies_.size());
        bodies_.emplace_back();
    }
    Body& b = bodies_[index];
    const std::uint32_t gen = b.generation;       // 슬롯 재사용 시 세대 유지 (Destroy 에서 증가시킴)
    b = Body{};
    b.generation = gen;
    b.alive = true;
    b.type = def.type;
    b.shape = def.shape;
    b.position = b.prevPosition = def.position;
    b.rotation = b.prevRotation = def.rotation;
    b.velocity = def.velocity;
    b.angularVelocity = def.angularVelocity;
    b.restitution = Clamp(def.restitution, 0.0f, 1.0f);
    b.friction = std::max(0.0f, def.friction);
    b.linearDamping = std::max(0.0f, def.linearDamping);
    b.angularDamping = std::max(0.0f, def.angularDamping);
    b.gravityScale = def.gravityScale;
    b.layer = def.layer;
    b.mask = def.mask;
    b.isSensor = def.isSensor;
    b.fixedRotation = def.fixedRotation;
    b.userData = def.userData;

    if (b.type == BodyType::Dynamic) {
        const float density = def.density > 0.0f ? def.density : 1.0f;
        const float area = b.shape.Area();
        b.mass = density * area;
        b.invMass = b.mass > 0.0f ? 1.0f / b.mass : 0.0f;
        b.inertia = density * b.shape.InertiaPerDensity();
        b.invInertia = (!b.fixedRotation && b.inertia > 0.0f) ? 1.0f / b.inertia : 0.0f;
    } else {
        if (b.type == BodyType::Static) { b.velocity = {0.0f, 0.0f}; b.angularVelocity = 0.0f; }
    }
    RefreshBody(b);
    treeDirty_ = true;
    return BodyId{index, b.generation};
}

void PhysicsWorld::DestroyBody(BodyId id) {
    if (!IsValid(id)) return;
    Body& b = bodies_[id.index];
    b.alive = false;
    ++b.generation;
    freeList_.push_back(id.index);
    treeDirty_ = true;
    // pairState_ 의 해당 항목은 다음 Step 에서 stamp 불일치/세대 불일치로 정리된다 (End 이벤트는 id 무효라 생략)
}

bool PhysicsWorld::IsValid(BodyId id) const {
    return id.index < bodies_.size() && bodies_[id.index].alive && bodies_[id.index].generation == id.generation;
}

Body* PhysicsWorld::Get(BodyId id) { return IsValid(id) ? &bodies_[id.index] : nullptr; }
const Body* PhysicsWorld::Get(BodyId id) const { return IsValid(id) ? &bodies_[id.index] : nullptr; }

void PhysicsWorld::Clear() {
    for (std::uint32_t i = 0; i < bodies_.size(); ++i) {
        if (bodies_[i].alive) { bodies_[i].alive = false; ++bodies_[i].generation; freeList_.push_back(i); }
    }
    pairState_.clear();
    contacts_.clear();
    debugContacts_.clear();
    treeDirty_ = true;
}

void PhysicsWorld::RefreshBody(Body& b) {
    b.xf = Transform2D::Make(b.position, b.rotation);
    b.aabb = b.shape.ComputeAABB(b.xf);
}

void PhysicsWorld::SetTransform(BodyId id, Vec2 position, float rotation) {
    Body* b = Get(id);
    if (!b) return;
    b->position = b->prevPosition = position;
    b->rotation = b->prevRotation = rotation;
    RefreshBody(*b);
    treeDirty_ = true;
}

void PhysicsWorld::ApplyForce(BodyId id, Vec2 f) {
    if (Body* b = Get(id)) b->force += f;
}
void PhysicsWorld::ApplyForceAtPoint(BodyId id, Vec2 f, Vec2 p) {
    if (Body* b = Get(id)) { b->force += f; b->torque += Cross(p - b->position, f); }
}
void PhysicsWorld::ApplyImpulse(BodyId id, Vec2 imp, Vec2 p) {
    Body* b = Get(id);
    if (!b || b->type != BodyType::Dynamic) return;
    b->velocity += imp * b->invMass;
    b->angularVelocity += Cross(p - b->position, imp) * b->invInertia;
}

// ---------------------------------------------------------------- 트리
void PhysicsWorld::RebuildTree() const {
    AABB u{{1e30f, 1e30f}, {-1e30f, -1e30f}};
    bool any = false;
    for (const Body& b : bodies_) {
        if (!b.alive) continue;
        if (!any) { u = b.aabb; any = true; } else u.Merge(b.aabb);
    }
    if (!any) u = AABB{{-1.0f, -1.0f}, {1.0f, 1.0f}};
    u.min -= Vec2{1.0f, 1.0f};
    u.max += Vec2{1.0f, 1.0f};
    tree_.Reset(u);
    for (std::uint32_t i = 0; i < bodies_.size(); ++i)
        if (bodies_[i].alive) tree_.Insert(i, bodies_[i].aabb);
    treeDirty_ = false;
}

void PhysicsWorld::EnsureTree() const {
    if (treeDirty_) RebuildTree();
}

void PhysicsWorld::QueryAABB(const AABB& box, std::vector<BodyId>& out) const {
    out.clear();
    EnsureTree();
    std::vector<std::uint32_t> ids;
    tree_.Query(box, ids);
    std::sort(ids.begin(), ids.end());
    for (std::uint32_t i : ids) out.push_back(BodyId{i, bodies_[i].generation});
}

void PhysicsWorld::QueryPoint(Vec2 p, std::vector<BodyId>& out) const {
    out.clear();
    EnsureTree();
    std::vector<std::uint32_t> ids;
    tree_.Query(AABB{p, p}, ids);
    std::sort(ids.begin(), ids.end());
    for (std::uint32_t i : ids) {
        const Body& b = bodies_[i];
        if (b.shape.ContainsPoint(b.xf, p)) out.push_back(BodyId{i, b.generation});
    }
}

BodyId PhysicsWorld::PickBody(Vec2 p) const {
    std::vector<BodyId> hits;
    QueryPoint(p, hits);
    for (BodyId id : hits)
        if (bodies_[id.index].type == BodyType::Dynamic && !bodies_[id.index].isSensor) return id;
    return BodyId{};
}

// ---------------------------------------------------------------- 솔버
void PhysicsWorld::PrepareContact(Contact& c) {
    Body& A = bodies_[c.a];
    Body& B = bodies_[c.b];
    const Vec2 n = c.m.normal;
    const Vec2 t{n.y, -n.x};
    c.friction = std::sqrt(A.friction * B.friction);
    c.restitution = std::max(A.restitution, B.restitution);

    for (int i = 0; i < c.m.count; ++i) {
        PointSolver& s = c.ps[i];
        const Vec2 p = c.m.points[i].position;
        s.rA = p - A.position;
        s.rB = p - B.position;
        const float rnA = Cross(s.rA, n), rnB = Cross(s.rB, n);
        const float rtA = Cross(s.rA, t), rtB = Cross(s.rB, t);
        const float kn = A.invMass + B.invMass + A.invInertia * rnA * rnA + B.invInertia * rnB * rnB;
        const float kt = A.invMass + B.invMass + A.invInertia * rtA * rtA + B.invInertia * rtB * rtB;
        s.normalMass = kn > 0.0f ? 1.0f / kn : 0.0f;
        s.tangentMass = kt > 0.0f ? 1.0f / kt : 0.0f;

        const Vec2 vRel = (B.velocity + Cross(B.angularVelocity, s.rB)) - (A.velocity + Cross(A.angularVelocity, s.rA));
        const float vn = Dot(vRel, n);
        s.bounce = (vn < -settings_.restitutionThreshold) ? -c.restitution * vn : 0.0f;
    }
}

void PhysicsWorld::WarmStart(Contact& c) {
    Body& A = bodies_[c.a];
    Body& B = bodies_[c.b];
    const Vec2 n = c.m.normal;
    const Vec2 t{n.y, -n.x};
    for (int i = 0; i < c.m.count; ++i) {
        const PointSolver& s = c.ps[i];
        const Vec2 P = n * c.m.points[i].normalImpulse + t * c.m.points[i].tangentImpulse;
        A.velocity -= P * A.invMass;
        A.angularVelocity -= A.invInertia * Cross(s.rA, P);
        B.velocity += P * B.invMass;
        B.angularVelocity += B.invInertia * Cross(s.rB, P);
    }
}

void PhysicsWorld::SolveVelocity(Contact& c) {
    Body& A = bodies_[c.a];
    Body& B = bodies_[c.b];
    const Vec2 n = c.m.normal;
    const Vec2 t{n.y, -n.x};

    for (int i = 0; i < c.m.count; ++i) {                      // 마찰 먼저 (직전 법선 임펄스 기준으로 한계 설정)
        ContactPoint& cp = c.m.points[i];
        const PointSolver& s = c.ps[i];
        const Vec2 dv = (B.velocity + Cross(B.angularVelocity, s.rB)) - (A.velocity + Cross(A.angularVelocity, s.rA));
        float lambda = -s.tangentMass * Dot(dv, t);
        const float maxF = c.friction * cp.normalImpulse;
        const float newImpulse = Clamp(cp.tangentImpulse + lambda, -maxF, maxF);
        lambda = newImpulse - cp.tangentImpulse;
        cp.tangentImpulse = newImpulse;
        const Vec2 P = t * lambda;
        A.velocity -= P * A.invMass;
        A.angularVelocity -= A.invInertia * Cross(s.rA, P);
        B.velocity += P * B.invMass;
        B.angularVelocity += B.invInertia * Cross(s.rB, P);
    }
    for (int i = 0; i < c.m.count; ++i) {                      // 법선
        ContactPoint& cp = c.m.points[i];
        const PointSolver& s = c.ps[i];
        const Vec2 dv = (B.velocity + Cross(B.angularVelocity, s.rB)) - (A.velocity + Cross(A.angularVelocity, s.rA));
        float lambda = -s.normalMass * (Dot(dv, n) - s.bounce);
        const float newImpulse = std::max(cp.normalImpulse + lambda, 0.0f);
        lambda = newImpulse - cp.normalImpulse;
        cp.normalImpulse = newImpulse;
        const Vec2 P = n * lambda;
        A.velocity -= P * A.invMass;
        A.angularVelocity -= A.invInertia * Cross(s.rA, P);
        B.velocity += P * B.invMass;
        B.angularVelocity += B.invInertia * Cross(s.rB, P);
    }
}

// ---------------------------------------------------------------- Step
void PhysicsWorld::Step(float dt) {
    if (!(dt > 0.0f)) return;
    const auto t0 = std::chrono::steady_clock::now();
    events_.clear();
    ++stamp_;

    // 1) 이전 상태 보관 + 힘/중력 -> 속도
    for (Body& b : bodies_) {
        if (!b.alive) continue;
        b.prevPosition = b.position;
        b.prevRotation = b.rotation;
        if (b.type == BodyType::Dynamic) {
            b.velocity += (settings_.gravity * b.gravityScale + b.force * b.invMass) * dt;
            b.angularVelocity += b.torque * b.invInertia * dt;
            b.velocity *= 1.0f / (1.0f + dt * b.linearDamping);
            b.angularVelocity *= 1.0f / (1.0f + dt * b.angularDamping);
            if (settings_.maxLinearSpeed > 0.0f) {
                const float sp = b.velocity.Length();
                if (sp > settings_.maxLinearSpeed) b.velocity *= settings_.maxLinearSpeed / sp;
            }
        }
        b.force = {0.0f, 0.0f};
        b.torque = 0.0f;
    }

    // 2) 브로드페이즈 (후보 쌍을 (작은 인덱스, 큰 인덱스) 로 정규화 + 정렬 -> 결정론)
    EnsureTree();
    tree_.QueryPairs(broadPairs_);
    for (auto& p : broadPairs_)
        if (p.first > p.second) std::swap(p.first, p.second);
    std::sort(broadPairs_.begin(), broadPairs_.end());

    // 3) 내로페이즈
    contacts_.clear();
    int triggers = 0;
    for (const auto& pr : broadPairs_) {
        Body& A = bodies_[pr.first];
        Body& B = bodies_[pr.second];
        if ((A.layer & B.mask) == 0 || (B.layer & A.mask) == 0) continue;
        const bool sensor = A.isSensor || B.isSensor;
        if (sensor && A.isSensor && B.isSensor) continue;
        if (!sensor && A.invMass == 0.0f && B.invMass == 0.0f) continue;      // 정적/키네마틱끼리는 무시

        Manifold m;
        if (!Collide(A.shape, A.xf, B.shape, B.xf, m)) continue;

        const std::uint64_t key = PairKey(pr.first, pr.second);
        const BodyId ida{pr.first, A.generation}, idb{pr.second, B.generation};
        auto it = pairState_.find(key);
        bool isNew = false;
        if (it == pairState_.end() || it->second.a != ida || it->second.b != idb) {
            if (it != pairState_.end()) pairState_.erase(it);
            it = pairState_.emplace(key, PairState{}).first;
            it->second.a = ida;
            it->second.b = idb;
            isNew = true;
        }
        PairState& ps = it->second;
        ps.sensor = sensor;
        ps.stamp = stamp_;

        if (sensor) {
            ++triggers;
            if (isNew) {
                PendingEvent e{PendingEvent::TriggerIn, A.isSensor ? ida : idb, A.isSensor ? idb : ida, {}, {}, 0, 0};
                events_.push_back(e);
            }
            continue;
        }

        if (!isNew) {                                                   // warm starting: 같은 피처 ID 의 임펄스 이월
            for (int i = 0; i < m.count; ++i)
                for (int j = 0; j < ps.manifold.count; ++j)
                    if (m.points[i].id == ps.manifold.points[j].id) {
                        m.points[i].normalImpulse = ps.manifold.points[j].normalImpulse;
                        m.points[i].tangentImpulse = ps.manifold.points[j].tangentImpulse;
                        break;
                    }
        } else {
            const Vec2 p = m.points[0].position;
            const Vec2 vRel = (B.velocity + Cross(B.angularVelocity, p - B.position)) -
                              (A.velocity + Cross(A.angularVelocity, p - A.position));
            PendingEvent e{PendingEvent::Begin, ida, idb, m.normal, p, -m.points[0].separation,
                           std::max(0.0f, -Dot(vRel, m.normal))};
            events_.push_back(e);
        }

        Contact c;
        c.a = pr.first;
        c.b = pr.second;
        c.m = m;
        c.key = key;
        contacts_.push_back(c);
    }

    // 끝난 접촉/트리거 정리 (+ End 이벤트: 키 순으로 정렬해 결정론 유지)
    {
        std::vector<std::pair<std::uint64_t, PendingEvent>> ended;
        for (auto it = pairState_.begin(); it != pairState_.end();) {
            if (it->second.stamp != stamp_) {
                if (IsValid(it->second.a) && IsValid(it->second.b)) {
                    PendingEvent e;
                    e.kind = it->second.sensor ? PendingEvent::TriggerOut : PendingEvent::End;
                    const Body& ba = bodies_[it->second.a.index];
                    e.a = (e.kind == PendingEvent::TriggerOut && !ba.isSensor) ? it->second.b : it->second.a;
                    e.b = (e.kind == PendingEvent::TriggerOut && !ba.isSensor) ? it->second.a : it->second.b;
                    ended.emplace_back(it->first, e);
                }
                it = pairState_.erase(it);
            } else {
                ++it;
            }
        }
        std::sort(ended.begin(), ended.end(), [](const auto& l, const auto& r) { return l.first < r.first; });
        for (auto& e : ended) events_.push_back(e.second);
    }

    // 4) 속도 제약 풀기
    for (Contact& c : contacts_) PrepareContact(c);
    for (Contact& c : contacts_) WarmStart(c);
    for (int it = 0; it < settings_.velocityIterations; ++it)
        for (Contact& c : contacts_) SolveVelocity(c);

    // 5) 위치 적분
    for (Body& b : bodies_) {
        if (!b.alive || b.type == BodyType::Static) continue;
        b.position += b.velocity * dt;
        b.rotation += b.angularVelocity * dt;
    }

    // 6) 침투 보정 (가장 깊은 접촉점 기준, 선형만)
    for (const Contact& c : contacts_) {
        Body& A = bodies_[c.a];
        Body& B = bodies_[c.b];
        float depth = 0.0f;
        for (int i = 0; i < c.m.count; ++i) depth = std::max(depth, -c.m.points[i].separation);
        const float invSum = A.invMass + B.invMass;
        if (invSum <= 0.0f) continue;
        const float corr = std::max(depth - settings_.linearSlop, 0.0f) / invSum * settings_.positionCorrection;
        A.position -= c.m.normal * (corr * A.invMass);
        B.position += c.m.normal * (corr * B.invMass);
    }

    // 7) 접촉 임펄스를 pairState_ 에 저장 + 디버그 접촉 + AABB/트리 갱신
    debugContacts_.clear();
    for (const Contact& c : contacts_) {
        auto it = pairState_.find(c.key);
        if (it != pairState_.end()) it->second.manifold = c.m;
        debugContacts_.push_back({BodyId{c.a, bodies_[c.a].generation}, BodyId{c.b, bodies_[c.b].generation}, c.m});
    }
    int count = 0;
    for (Body& b : bodies_) {
        if (!b.alive) continue;
        ++count;
        if (b.type != BodyType::Static) RefreshBody(b);
    }
    RebuildTree();

    stats_.bodies = count;
    stats_.broadPairs = static_cast<int>(broadPairs_.size());
    stats_.contacts = static_cast<int>(contacts_.size());
    stats_.triggers = triggers;
    stats_.treeNodes = tree_.NodeCount();
    stats_.stepMs = std::chrono::duration<double, std::milli>(std::chrono::steady_clock::now() - t0).count();

    Publish();
}

void PhysicsWorld::Publish() {
    if (!bus_ || events_.empty()) { events_.clear(); return; }
    std::vector<PendingEvent> local;
    local.swap(events_);                       // 핸들러가 월드를 수정해도 안전하도록 복사본 순회
    for (const PendingEvent& e : local) {
        switch (e.kind) {
        case PendingEvent::Begin:      bus_->Publish(CollisionBeginEvent{e.a, e.b, e.normal, e.point, e.depth, e.impact}); break;
        case PendingEvent::End:        bus_->Publish(CollisionEndEvent{e.a, e.b}); break;
        case PendingEvent::TriggerIn:  bus_->Publish(TriggerEnterEvent{e.a, e.b}); break;
        case PendingEvent::TriggerOut: bus_->Publish(TriggerExitEvent{e.a, e.b}); break;
        }
    }
}

} // namespace engine
