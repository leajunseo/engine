#include "Audio/Wav.hpp"

#include <algorithm>
#include <cmath>
#include <cstring>
#include <functional>

#include "Core/Log.hpp"

namespace engine {
namespace {

constexpr int kFormatPcm = 1, kFormatFloat = 3, kFormatExtensible = 0xFFFE;

struct WavFormat {
    int format = 0, channels = 0, rate = 0, bits = 0;
    std::size_t blockAlign = 0;
    std::uint64_t dataOffset = 0, dataBytes = 0;
};

std::uint32_t U32(const std::uint8_t* p) { return static_cast<std::uint32_t>(p[0]) | (static_cast<std::uint32_t>(p[1]) << 8) | (static_cast<std::uint32_t>(p[2]) << 16) | (static_cast<std::uint32_t>(p[3]) << 24); }
std::uint16_t U16(const std::uint8_t* p) { return static_cast<std::uint16_t>(p[0] | (p[1] << 8)); }

using ReadAt = std::function<bool(std::uint64_t offset, void* dst, std::size_t n)>;

// RIFF 청크를 훑어 fmt / data 위치를 찾는다. 메모리/파일 공용.
bool ParseHeader(const ReadAt& readAt, std::uint64_t total, WavFormat& f, std::string* err) {
    auto fail = [&](const char* m) { if (err) *err = m; return false; };
    std::uint8_t hdr[12];
    if (total < 12 || !readAt(0, hdr, 12)) return fail("too small");
    if (std::memcmp(hdr, "RIFF", 4) != 0 || std::memcmp(hdr + 8, "WAVE", 4) != 0) return fail("not a RIFF/WAVE file");

    bool haveFmt = false, haveData = false;
    std::uint64_t pos = 12;
    while (pos + 8 <= total && !haveData) {
        std::uint8_t ch[8];
        if (!readAt(pos, ch, 8)) break;
        const std::uint64_t size = U32(ch + 4);
        const std::uint64_t body = pos + 8;
        if (std::memcmp(ch, "fmt ", 4) == 0) {
            if (size < 16 || body + 16 > total) return fail("bad fmt chunk");
            std::uint8_t b[40] = {};
            if (!readAt(body, b, static_cast<std::size_t>(std::min<std::uint64_t>(size, sizeof(b))))) return fail("bad fmt chunk");
            f.format     = U16(b);
            f.channels   = U16(b + 2);
            f.rate       = static_cast<int>(U32(b + 4));
            f.blockAlign = U16(b + 12);
            f.bits       = U16(b + 14);
            if (f.format == kFormatExtensible) {
                if (size < 26) return fail("bad extensible fmt");
                f.format = U16(b + 24);            // SubFormat GUID 의 첫 2바이트 = 실제 포맷 태그
            }
            haveFmt = true;
        } else if (std::memcmp(ch, "data", 4) == 0) {
            if (!haveFmt) return fail("data before fmt");
            f.dataOffset = body;
            f.dataBytes  = std::min<std::uint64_t>(size, total - body);   // 잘린 파일/스트리밍 헤더(0xFFFFFFFF) 대응
            haveData = true;
        }
        pos = body + size + (size & 1u);             // 청크는 짝수 정렬
    }
    if (!haveFmt)  return fail("no fmt chunk");
    if (!haveData) return fail("no data chunk");

    if (f.format != kFormatPcm && f.format != kFormatFloat) return fail("unsupported format (only PCM / float)");
    if (f.channels < 1 || f.channels > 8)                   return fail("unsupported channel count");
    if (f.rate < 1 || f.rate > 384000)                      return fail("unsupported sample rate");
    const bool okBits = (f.format == kFormatPcm && (f.bits == 8 || f.bits == 16 || f.bits == 24 || f.bits == 32)) ||
                        (f.format == kFormatFloat && f.bits == 32);
    if (!okBits) return fail("unsupported bit depth");
    f.blockAlign = static_cast<std::size_t>(f.channels) * static_cast<std::size_t>(f.bits / 8);   // 헤더의 blockAlign 은 믿지 않는다
    return true;
}

float ConvertSample(const std::uint8_t* p, int format, int bits) {
    if (format == kFormatFloat) {
        float v; std::memcpy(&v, p, 4);
        return std::isfinite(v) ? std::max(-1.0f, std::min(1.0f, v)) : 0.0f;
    }
    switch (bits) {
        case 8:  return (static_cast<int>(p[0]) - 128) / 128.0f;
        case 16: return static_cast<std::int16_t>(U16(p)) / 32768.0f;
        case 24: { std::int32_t v = static_cast<std::int32_t>((static_cast<std::uint32_t>(p[0]) << 8) | (static_cast<std::uint32_t>(p[1]) << 16) | (static_cast<std::uint32_t>(p[2]) << 24)); return static_cast<float>(v >> 8) / 8388608.0f; }
        default: return static_cast<float>(static_cast<double>(static_cast<std::int32_t>(U32(p))) / 2147483648.0);
    }
}

// block(= 프레임 하나의 모든 채널 바이트) -> 스테레오 한 프레임
void ConvertFrame(const std::uint8_t* p, const WavFormat& f, float* out2) {
    const std::size_t bytes = static_cast<std::size_t>(f.bits / 8);
    const float l = ConvertSample(p, f.format, f.bits);
    out2[0] = l;
    out2[1] = f.channels >= 2 ? ConvertSample(p + bytes, f.format, f.bits) : l;
}

} // namespace

bool DecodeWav(const std::uint8_t* data, std::size_t size, AudioClip& out) {
    out = AudioClip{};
    if (!data) return false;
    WavFormat f;
    std::string err;
    ReadAt readAt = [&](std::uint64_t off, void* dst, std::size_t n) {
        if (off + n > size) return false;
        std::memcpy(dst, data + off, n);
        return true;
    };
    if (!ParseHeader(readAt, size, f, &err)) { ENGINE_LOG_WARN("WAV decode failed: %s", err.c_str()); return false; }
    const std::uint64_t frames = f.dataBytes / f.blockAlign;
    if (frames == 0 || frames > kMaxWavFrames) { ENGINE_LOG_WARN("WAV decode failed: %s", frames == 0 ? "no samples" : "too long"); return false; }

    auto v = std::make_shared<std::vector<float>>(static_cast<std::size_t>(frames) * 2);
    const std::uint8_t* p = data + f.dataOffset;
    for (std::uint64_t i = 0; i < frames; ++i) ConvertFrame(p + i * f.blockAlign, f, &(*v)[static_cast<std::size_t>(i) * 2]);
    out.sampleRate = f.rate;
    out.samples = std::move(v);
    return true;
}

bool LoadWavFile(const std::string& path, AudioClip& out) {
    out = AudioClip{};
    std::ifstream in(path, std::ios::binary | std::ios::ate);
    if (!in) return false;
    const std::streamoff len = in.tellg();
    if (len <= 0 || static_cast<std::uint64_t>(len) > (1ull << 30)) return false;     // 1GB 초과 파일은 거부
    std::vector<std::uint8_t> bytes(static_cast<std::size_t>(len));
    in.seekg(0);
    if (!in.read(reinterpret_cast<char*>(bytes.data()), len)) return false;
    return DecodeWav(bytes.data(), bytes.size(), out);
}

std::vector<std::uint8_t> EncodeWav16(const float* s, std::size_t frames, int channels, int rate) {
    channels = channels == 1 ? 1 : 2;
    const std::uint32_t dataBytes = static_cast<std::uint32_t>(frames * static_cast<std::size_t>(channels) * 2);
    std::vector<std::uint8_t> o;
    o.reserve(44 + dataBytes);
    auto p32 = [&](std::uint32_t v) { for (int i = 0; i < 4; ++i) o.push_back(static_cast<std::uint8_t>(v >> (8 * i))); };
    auto p16 = [&](std::uint16_t v) { o.push_back(static_cast<std::uint8_t>(v)); o.push_back(static_cast<std::uint8_t>(v >> 8)); };
    auto tag = [&](const char* t) { o.insert(o.end(), t, t + 4); };
    tag("RIFF"); p32(36 + dataBytes); tag("WAVE");
    tag("fmt "); p32(16); p16(1); p16(static_cast<std::uint16_t>(channels)); p32(static_cast<std::uint32_t>(rate));
    p32(static_cast<std::uint32_t>(rate * channels * 2)); p16(static_cast<std::uint16_t>(channels * 2)); p16(16);
    tag("data"); p32(dataBytes);
    for (std::size_t i = 0; i < frames * static_cast<std::size_t>(channels); ++i) {
        const float c = std::max(-1.0f, std::min(1.0f, s[i]));
        p16(static_cast<std::uint16_t>(static_cast<std::int16_t>(std::lrintf(c * 32767.0f))));
    }
    return o;
}

bool SaveWav16(const std::string& path, const float* s, std::size_t frames, int channels, int rate) {
    const auto bytes = EncodeWav16(s, frames, channels, rate);
    std::ofstream f(path, std::ios::binary | std::ios::trunc);
    if (!f) return false;
    f.write(reinterpret_cast<const char*>(bytes.data()), static_cast<std::streamsize>(bytes.size()));
    return static_cast<bool>(f);
}

// ---------------------------------------------------------------- WavReader
bool WavReader::Open(const std::string& path, std::string* error) {
    file_.close();
    file_.clear();
    file_.open(path, std::ios::binary | std::ios::ate);
    if (!file_) { if (error) *error = "cannot open file"; return false; }
    const std::streamoff len = file_.tellg();
    if (len <= 0) { file_.close(); if (error) *error = "empty file"; return false; }

    WavFormat f;
    ReadAt readAt = [this](std::uint64_t off, void* dst, std::size_t n) {
        file_.clear();
        file_.seekg(static_cast<std::streamoff>(off));
        return static_cast<bool>(file_.read(static_cast<char*>(dst), static_cast<std::streamsize>(n)));
    };
    if (!ParseHeader(readAt, static_cast<std::uint64_t>(len), f, error)) { file_.close(); return false; }
    format_ = f.format; channels_ = f.channels; rate_ = f.rate; bits_ = f.bits;
    blockAlign_ = f.blockAlign; dataOffset_ = f.dataOffset;
    totalFrames_ = f.dataBytes / f.blockAlign;
    return Rewind();
}

bool WavReader::Rewind() {
    if (!file_.is_open()) return false;
    file_.clear();
    file_.seekg(static_cast<std::streamoff>(dataOffset_));
    framePos_ = 0;
    return static_cast<bool>(file_);
}

std::size_t WavReader::ReadStereo(float* dst, std::size_t frames) {
    if (!file_.is_open() || framePos_ >= totalFrames_) return 0;
    frames = static_cast<std::size_t>(std::min<std::uint64_t>(frames, totalFrames_ - framePos_));
    raw_.resize(frames * blockAlign_);
    file_.read(reinterpret_cast<char*>(raw_.data()), static_cast<std::streamsize>(raw_.size()));
    const std::size_t got = static_cast<std::size_t>(file_.gcount()) / blockAlign_;    // 파일이 중간에 잘렸어도 안전
    WavFormat f; f.format = format_; f.channels = channels_; f.bits = bits_;
    for (std::size_t i = 0; i < got; ++i) ConvertFrame(raw_.data() + i * blockAlign_, f, dst + i * 2);
    framePos_ += got;
    if (got < frames) framePos_ = totalFrames_;       // 예상보다 일찍 끝남 -> 더 읽지 않는다
    return got;
}

} // namespace engine
