#include "Audio/AudioManager.hpp"

#include <SDL.h>

#include "Audio/MusicStream.hpp"
#include "Core/Log.hpp"

namespace engine {
namespace {

void SDLCALL AudioCallback(void* userdata, Uint8* stream, int len) {
    auto* mixer = static_cast<Mixer*>(userdata);
    const int frames = len / static_cast<int>(sizeof(float) * 2);
    mixer->Mix(reinterpret_cast<float*>(stream), frames);
}

} // namespace

AudioManager::AudioManager(AudioConfig config)
    : config_(config), mixer_(std::make_unique<Mixer>(config.sampleRate, config.maxVoices)) {}

AudioManager::~AudioManager() { Shutdown(); }

bool AudioManager::Init() {
    if (device_ != 0) return true;
    if (!audioInited_) {
        if (SDL_InitSubSystem(SDL_INIT_AUDIO) != 0) {
            ENGINE_LOG_WARN("Audio disabled (SDL audio init failed: %s)", SDL_GetError());
            return false;
        }
        audioInited_ = true;
    }
    SDL_AudioSpec want{}, have{};
    want.freq     = mixer_->SampleRate();
    want.format   = AUDIO_F32SYS;
    want.channels = 2;
    want.samples  = static_cast<Uint16>(config_.bufferFrames);
    want.callback = AudioCallback;
    want.userdata = mixer_.get();
    const SDL_AudioDeviceID dev = SDL_OpenAudioDevice(nullptr, 0, &want, &have, 0);   // 0: 우리 형식 그대로 (SDL 이 변환)
    if (dev == 0) {
        ENGINE_LOG_WARN("Audio disabled (cannot open device: %s)", SDL_GetError());
        SDL_QuitSubSystem(SDL_INIT_AUDIO);
        audioInited_ = false;
        return false;
    }
    device_ = dev;
    SDL_PauseAudioDevice(dev, 0);
    ENGINE_LOG_INFO("Audio device opened: %d Hz, %d-sample buffer, driver '%s'",
                    have.freq, static_cast<int>(have.samples), SDL_GetCurrentAudioDriver() ? SDL_GetCurrentAudioDriver() : "?");
    return true;
}

void AudioManager::Shutdown() {
    if (device_ != 0) {
        SDL_CloseAudioDevice(static_cast<SDL_AudioDeviceID>(device_));      // 콜백이 끝날 때까지 기다린 뒤 닫음
        device_ = 0;
    }
    if (audioInited_) { SDL_QuitSubSystem(SDL_INIT_AUDIO); audioInited_ = false; }
    mixer_->StopAll(0.0f);
    mixer_->StopMusic(0.0f);
    mixer_->Update();
}

bool AudioManager::PlayMusic(const std::string& path, bool loop, float fadeInSeconds, std::string* error) {
    auto stream = StreamingMusic::Open(path, mixer_->SampleRate(), loop, error);
    if (!stream) {
        ENGINE_LOG_WARN("Cannot play music '%s'", path.c_str());
        return false;
    }
    stream->WaitUntilBuffered(50);          // 첫 블록이 무음이 되지 않도록 잠깐 기다림 (메인 스레드, 최대 50ms)
    mixer_->PlayMusic(std::move(stream), fadeInSeconds);
    return true;
}

} // namespace engine
