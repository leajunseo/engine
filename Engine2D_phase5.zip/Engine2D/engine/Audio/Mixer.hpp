#pragma once
// ---------------------------------------------------------------------------
// 소프트웨어 믹서 (SDL/장치 비의존 -> 창/소리 장치 없이 단위 테스트 가능).
//   스테레오 float 출력. 효과음 보이스 풀(기본 64) + 음악 슬롯(크로스페이드) + 버스(Sfx/Music)/마스터 볼륨.
//
//   - 효과음: Play(clip, {volume, pitch, pan, loop}) -> VoiceId. 피치는 선형 보간 리샘플링, 패닝은 등전력(constant power).
//   - 보이스가 가득 차면 '가장 오래된 비반복 보이스' (없으면 가장 오래된 보이스) 를 훔친다.
//   - Stop 은 기본 5ms 페이드아웃 (딸깍 소리 방지). 볼륨(마스터/버스) 변경은 한 블록 안에서 선형으로 이어진다.
//   - 음악: PlayMusic(stream, fadeIn) -> 이전 음악은 같은 시간 동안 페이드아웃(크로스페이드). 끝난 스트림은 자동 제거.
//   - VoiceId 는 세대(generation) 번호가 있어 끝난/훔쳐진 보이스를 가리키는 옛 핸들은 자동으로 무효다.
//
// 스레드: 모든 공개 함수는 mutex 로 보호된다. Mix() 는 오디오 스레드에서, 나머지는 메인 스레드에서 부르면 된다.
//   Mix() 는 스트림 파괴(스레드 join 등)를 하지 않고 '묘지(graveyard)' 에 옮겨두며, 실제 파괴는 메인 스레드의
//   Update()/다음 호출에서 락 밖에서 이뤄진다. -> 오디오 콜백이 오래 막히지 않는다.
//
// [Bottleneck] 보이스당 샘플 루프는 스칼라 코드(보이스 64 x 48kHz 는 현대 CPU 에서 여유). 수백 보이스가 필요하면 SIMD.
// [Limitation] 한 Mix 블록 안에서 한 번에 처리하는 프레임 수는 제한 없지만, 스크래치 버퍼를 늘리는 할당이 처음 한 번 일어날 수 있다.
// ---------------------------------------------------------------------------
#include <cstddef>
#include <cstdint>
#include <memory>
#include <mutex>
#include <vector>

#include "Audio/AudioClip.hpp"

namespace engine {

enum class AudioBus { Sfx = 0, Music = 1 };

struct PlayParams {
    float volume = 1.0f;    // 0..  (1 = 원본)
    float pitch  = 1.0f;    // 재생 속도 배율 (0.1 ~ 8 로 제한)
    float pan    = 0.0f;    // -1 (왼쪽) .. +1 (오른쪽)
    bool  loop   = false;
};

struct VoiceId {
    std::uint32_t index = 0, generation = 0;
    bool Valid() const { return generation != 0; }
    bool operator==(const VoiceId& o) const { return index == o.index && generation == o.generation; }
};

/// 음악 같은 긴 소스를 위한 인터페이스. 믹서 샘플레이트의 스테레오 float 를 돌려준다.
class IAudioStream {
public:
    virtual ~IAudioStream() = default;
    /// 최대 frames 프레임을 dst(인터리브 스테레오) 에 쓰고 쓴 프레임 수를 반환. 적게 주면 나머지는 무음.
    /// (끝났는지는 Finished() 로 구분: 끝이 아닌데 적게 주면 '버퍼 부족(underrun)')
    virtual int  Read(float* dst, int frames) = 0;
    virtual bool Finished() const = 0;
};

class Mixer {
public:
    explicit Mixer(int sampleRate = 48000, int maxVoices = 64);
    ~Mixer();
    Mixer(const Mixer&)            = delete;
    Mixer& operator=(const Mixer&) = delete;

    int SampleRate() const { return sampleRate_; }

    // ---- 효과음 ----
    VoiceId Play(const AudioClip& clip, PlayParams params = {});     // 클립이 비었으면 빈 VoiceId
    void    Stop(VoiceId id, float fadeSeconds = 0.005f);
    void    StopAll(float fadeSeconds = 0.005f);
    bool    IsPlaying(VoiceId id) const;
    bool    SetVoiceVolume(VoiceId id, float volume);
    bool    SetVoicePitch(VoiceId id, float pitch);
    bool    SetVoicePan(VoiceId id, float pan);
    int     ActiveVoices() const;

    // ---- 음악 ----
    void PlayMusic(std::unique_ptr<IAudioStream> stream, float fadeInSeconds = 0.0f);
    void StopMusic(float fadeOutSeconds = 0.0f);
    bool IsMusicPlaying() const;                  // 페이드아웃 중인 이전 곡은 제외
    void SetMusicPaused(bool paused);
    bool MusicPaused() const;

    // ---- 볼륨 ----
    void  SetMasterVolume(float v);
    float MasterVolume() const;
    void  SetBusVolume(AudioBus bus, float v);
    float BusVolume(AudioBus bus) const;

    // ---- 출력 ----
    /// 오디오 스레드에서 호출. out 은 frames*2 개의 float (덮어씀). 출력은 [-1,1] 로 클램프.
    void Mix(float* out, int frames);
    /// 직전 Mix 블록의 (클램프 전) 최대 진폭
    struct Levels { float left = 0.0f, right = 0.0f; };
    Levels PeakLevels() const;
    std::uint64_t FramesMixed() const;

    /// 메인 스레드에서 프레임마다 (또는 가끔) 호출: 끝난 스트림을 락 밖에서 파괴.
    void Update();

private:
    struct Voice {
        bool active = false;
        std::uint32_t generation = 0;
        AudioClip clip;
        double pos = 0.0;
        float volume = 1.0f, pitch = 1.0f, pan = 0.0f;
        bool loop = false;
        std::uint64_t order = 0;
        int fadeLeft = 0, fadeTotal = 0;           // 0 = 페이드 중 아님
    };
    struct MusicSlot {
        std::unique_ptr<IAudioStream> stream;
        float gain = 1.0f, target = 1.0f, step = 0.0f;   // step: 프레임당 gain 변화량 (부호 있음)
        bool dying = false;
    };

    static float ClampVolume(float v) { return v < 0.0f ? 0.0f : (v > 8.0f ? 8.0f : v); }
    void MixVoice(Voice& v, float* out, int frames, float gainPrev, float gainTarget);
    void MixMusic(float* out, int frames, float gainPrev, float gainTarget);
    void Reap();                                   // graveyard 비우기 (락 밖)

    mutable std::mutex mutex_;
    const int sampleRate_;
    std::vector<Voice> voices_;
    std::vector<MusicSlot> music_;
    std::vector<std::unique_ptr<IAudioStream>> graveyard_;
    std::vector<float> scratch_;

    float master_ = 1.0f, busVol_[2] = {1.0f, 1.0f};
    float curSfxGain_ = 1.0f, curMusicGain_ = 1.0f;       // 직전 블록 끝에서의 실제 게인 (램프 시작점)
    bool  musicPaused_ = false;
    std::uint64_t order_ = 0, framesMixed_ = 0;
    Levels peak_;
};

} // namespace engine
