#pragma once
// ---------------------------------------------------------------------------
// 메모리에 올라간 효과음 데이터: 스테레오 float 인터리브 + 샘플레이트.
//   * 복사가 싸다 (샘플은 shared_ptr<const vector> 로 공유). 믹서의 보이스는 재생 시점의 복사본을 쥐므로
//     AssetManager 핫 리로드가 클립을 교체해도 재생 중인 소리는 옛 데이터로 안전하게 끝까지 재생된다.
//   * 모노 입력은 양 채널에 복제해서 저장 (믹서는 항상 스테레오 소스만 다룸).
// ---------------------------------------------------------------------------
#include <cstddef>
#include <memory>
#include <vector>

namespace engine {

struct AudioClip {
    int sampleRate = 0;
    std::shared_ptr<const std::vector<float>> samples;     // 인터리브 L,R,L,R...

    std::size_t FrameCount() const { return samples ? samples->size() / 2 : 0; }
    double Duration() const        { return sampleRate > 0 ? static_cast<double>(FrameCount()) / sampleRate : 0.0; }
    bool   Valid() const           { return sampleRate > 0 && FrameCount() > 0; }

    static AudioClip FromMono(const float* data, std::size_t frames, int sampleRate) {
        auto v = std::make_shared<std::vector<float>>(frames * 2);
        for (std::size_t i = 0; i < frames; ++i) { (*v)[2 * i] = data[i]; (*v)[2 * i + 1] = data[i]; }
        AudioClip c; c.sampleRate = sampleRate; c.samples = std::move(v);
        return c;
    }
    static AudioClip FromStereo(const float* interleaved, std::size_t frames, int sampleRate) {
        AudioClip c; c.sampleRate = sampleRate;
        c.samples = std::make_shared<std::vector<float>>(interleaved, interleaved + frames * 2);
        return c;
    }
};

} // namespace engine
