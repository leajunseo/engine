#include "Audio/Mixer.hpp"

#include <algorithm>
#include <cmath>

namespace engine {
namespace {
constexpr int kMaxMusicSlots = 4;
constexpr float kQuarterPi = 0.78539816339744830962f;
}

Mixer::Mixer(int sampleRate, int maxVoices)
    : sampleRate_(std::max(8000, sampleRate)), voices_(static_cast<std::size_t>(std::max(1, maxVoices))) {}

Mixer::~Mixer() = default;

void Mixer::Reap() {
    std::vector<std::unique_ptr<IAudioStream>> dead;
    {
        std::lock_guard<std::mutex> lock(mutex_);
        dead.swap(graveyard_);
    }
    // dead 는 여기서(락 밖) 파괴 -> 스트림 소멸자의 스레드 join 이 오디오 콜백을 막지 않는다
}

void Mixer::Update() { Reap(); }

// ---------------------------------------------------------------- 효과음
VoiceId Mixer::Play(const AudioClip& clip, PlayParams p) {
    if (!clip.Valid()) return {};
    std::lock_guard<std::mutex> lock(mutex_);

    std::size_t slot = voices_.size();
    for (std::size_t i = 0; i < voices_.size(); ++i) if (!voices_[i].active) { slot = i; break; }
    if (slot == voices_.size()) {                      // 가득 참 -> 훔치기: 오래된 비반복 우선
        std::uint64_t bestOrder = ~0ull; bool bestLoop = true;
        for (std::size_t i = 0; i < voices_.size(); ++i) {
            const Voice& v = voices_[i];
            if ((bestLoop && !v.loop) || (v.loop == bestLoop && v.order < bestOrder)) { slot = i; bestOrder = v.order; bestLoop = v.loop; }
        }
    }
    Voice& v = voices_[slot];
    v.active = true;
    ++v.generation; if (v.generation == 0) v.generation = 1;
    v.clip = clip;
    v.pos = 0.0;
    v.volume = ClampVolume(p.volume);
    v.pitch  = std::max(0.1f, std::min(8.0f, p.pitch));
    v.pan    = std::max(-1.0f, std::min(1.0f, p.pan));
    v.loop   = p.loop;
    v.order  = ++order_;
    v.fadeLeft = v.fadeTotal = 0;
    return VoiceId{static_cast<std::uint32_t>(slot), v.generation};
}

void Mixer::Stop(VoiceId id, float fadeSeconds) {
    std::lock_guard<std::mutex> lock(mutex_);
    if (id.index >= voices_.size()) return;
    Voice& v = voices_[id.index];
    if (!v.active || v.generation != id.generation) return;
    const int frames = static_cast<int>(std::max(0.0f, fadeSeconds) * static_cast<float>(sampleRate_));
    if (frames <= 0) { v.active = false; v.clip = AudioClip{}; }
    else if (v.fadeTotal == 0) { v.fadeLeft = v.fadeTotal = frames; }
}

void Mixer::StopAll(float fadeSeconds) {
    std::lock_guard<std::mutex> lock(mutex_);
    const int frames = static_cast<int>(std::max(0.0f, fadeSeconds) * static_cast<float>(sampleRate_));
    for (Voice& v : voices_) {
        if (!v.active) continue;
        if (frames <= 0) { v.active = false; v.clip = AudioClip{}; }
        else if (v.fadeTotal == 0) { v.fadeLeft = v.fadeTotal = frames; }
    }
}

bool Mixer::IsPlaying(VoiceId id) const {
    std::lock_guard<std::mutex> lock(mutex_);
    return id.index < voices_.size() && voices_[id.index].active && voices_[id.index].generation == id.generation;
}

bool Mixer::SetVoiceVolume(VoiceId id, float volume) {
    std::lock_guard<std::mutex> lock(mutex_);
    if (id.index >= voices_.size() || !voices_[id.index].active || voices_[id.index].generation != id.generation) return false;
    voices_[id.index].volume = ClampVolume(volume);
    return true;
}
bool Mixer::SetVoicePitch(VoiceId id, float pitch) {
    std::lock_guard<std::mutex> lock(mutex_);
    if (id.index >= voices_.size() || !voices_[id.index].active || voices_[id.index].generation != id.generation) return false;
    voices_[id.index].pitch = std::max(0.1f, std::min(8.0f, pitch));
    return true;
}
bool Mixer::SetVoicePan(VoiceId id, float pan) {
    std::lock_guard<std::mutex> lock(mutex_);
    if (id.index >= voices_.size() || !voices_[id.index].active || voices_[id.index].generation != id.generation) return false;
    voices_[id.index].pan = std::max(-1.0f, std::min(1.0f, pan));
    return true;
}

int Mixer::ActiveVoices() const {
    std::lock_guard<std::mutex> lock(mutex_);
    return static_cast<int>(std::count_if(voices_.begin(), voices_.end(), [](const Voice& v) { return v.active; }));
}

// ---------------------------------------------------------------- 음악
void Mixer::PlayMusic(std::unique_ptr<IAudioStream> stream, float fadeInSeconds) {
    if (!stream) return;
    {
        std::lock_guard<std::mutex> lock(mutex_);
        const int fadeFrames = static_cast<int>(std::max(0.0f, fadeInSeconds) * static_cast<float>(sampleRate_));
        for (MusicSlot& s : music_) {                            // 이전 곡: 같은 시간 동안 페이드아웃
            if (s.dying) continue;
            if (fadeFrames <= 0) { s.gain = 0.0f; s.target = 0.0f; s.step = 0.0f; s.dying = true; }
            else { s.target = 0.0f; s.step = -s.gain / static_cast<float>(fadeFrames); s.dying = true; }
        }
        MusicSlot n;
        n.stream = std::move(stream);
        n.target = 1.0f;
        if (fadeFrames > 0) { n.gain = 0.0f; n.step = 1.0f / static_cast<float>(fadeFrames); } else { n.gain = 1.0f; n.step = 0.0f; }
        music_.push_back(std::move(n));
        // 정리: 완전히 조용해진 dying 슬롯 / 슬롯 수 상한
        for (auto it = music_.begin(); it != music_.end();) {
            if (it->dying && it->gain <= 0.0f) { graveyard_.push_back(std::move(it->stream)); it = music_.erase(it); } else ++it;
        }
        while (music_.size() > static_cast<std::size_t>(kMaxMusicSlots)) { graveyard_.push_back(std::move(music_.front().stream)); music_.erase(music_.begin()); }
    }
    Reap();
}

void Mixer::StopMusic(float fadeOutSeconds) {
    {
        std::lock_guard<std::mutex> lock(mutex_);
        const int fadeFrames = static_cast<int>(std::max(0.0f, fadeOutSeconds) * static_cast<float>(sampleRate_));
        for (auto it = music_.begin(); it != music_.end();) {
            if (fadeFrames <= 0) { graveyard_.push_back(std::move(it->stream)); it = music_.erase(it); continue; }
            it->dying = true; it->target = 0.0f;
            it->step = -std::max(it->gain, 1e-6f) / static_cast<float>(fadeFrames);
            ++it;
        }
    }
    Reap();
}

bool Mixer::IsMusicPlaying() const {
    std::lock_guard<std::mutex> lock(mutex_);
    return std::any_of(music_.begin(), music_.end(), [](const MusicSlot& s) { return !s.dying; });
}
void Mixer::SetMusicPaused(bool p) { std::lock_guard<std::mutex> lock(mutex_); musicPaused_ = p; }
bool Mixer::MusicPaused() const    { std::lock_guard<std::mutex> lock(mutex_); return musicPaused_; }

// ---------------------------------------------------------------- 볼륨
void  Mixer::SetMasterVolume(float v) { std::lock_guard<std::mutex> lock(mutex_); master_ = ClampVolume(v); }
float Mixer::MasterVolume() const     { std::lock_guard<std::mutex> lock(mutex_); return master_; }
void  Mixer::SetBusVolume(AudioBus b, float v) { std::lock_guard<std::mutex> lock(mutex_); busVol_[static_cast<int>(b)] = ClampVolume(v); }
float Mixer::BusVolume(AudioBus b) const { std::lock_guard<std::mutex> lock(mutex_); return busVol_[static_cast<int>(b)]; }

Mixer::Levels Mixer::PeakLevels() const { std::lock_guard<std::mutex> lock(mutex_); return peak_; }
std::uint64_t Mixer::FramesMixed() const { std::lock_guard<std::mutex> lock(mutex_); return framesMixed_; }

// ---------------------------------------------------------------- 믹싱
void Mixer::MixVoice(Voice& v, float* out, int frames, float gainPrev, float gainTarget) {
    const float* d = v.clip.samples->data();
    const double n = static_cast<double>(v.clip.FrameCount());
    const double step = static_cast<double>(v.pitch) * v.clip.sampleRate / sampleRate_;
    const float angle = (v.pan + 1.0f) * kQuarterPi;                  // 등전력 패닝: 가운데는 각 채널 0.707(-3dB), 한쪽 끝은 1.0
    const float gl = std::cos(angle), gr = std::sin(angle);
    const std::size_t count = v.clip.FrameCount();

    for (int f = 0; f < frames; ++f) {
        std::size_t i = static_cast<std::size_t>(v.pos);
        if (i >= count) { v.active = false; v.clip = AudioClip{}; return; }
        const float frac = static_cast<float>(v.pos - static_cast<double>(i));
        std::size_t i1 = i + 1;
        if (i1 >= count) i1 = v.loop ? 0 : i;                        // 끝 샘플은 유지 (보간 없음)
        const float l = d[2 * i]     + (d[2 * i1]     - d[2 * i])     * frac;
        const float r = d[2 * i + 1] + (d[2 * i1 + 1] - d[2 * i + 1]) * frac;

        const float busGain = gainPrev + (gainTarget - gainPrev) * (static_cast<float>(f + 1) / static_cast<float>(frames));
        float g = v.volume * busGain;
        bool finishedFade = false;
        if (v.fadeTotal > 0) {
            g *= static_cast<float>(v.fadeLeft) / static_cast<float>(v.fadeTotal);
            if (--v.fadeLeft <= 0) finishedFade = true;
        }
        out[2 * f]     += l * gl * g;
        out[2 * f + 1] += r * gr * g;

        v.pos += step;
        if (finishedFade) { v.active = false; v.clip = AudioClip{}; return; }
        if (v.pos >= n) {
            if (v.loop) v.pos = std::fmod(v.pos, n);
            else { v.active = false; v.clip = AudioClip{}; return; }
        }
    }
}

void Mixer::MixMusic(float* out, int frames, float gainPrev, float gainTarget) {
    if (musicPaused_) return;
    scratch_.resize(static_cast<std::size_t>(frames) * 2);
    for (MusicSlot& s : music_) {
        const int got = std::max(0, std::min(frames, s.stream->Read(scratch_.data(), frames)));
        std::fill(scratch_.begin() + static_cast<std::ptrdiff_t>(got) * 2, scratch_.end(), 0.0f);
        for (int f = 0; f < frames; ++f) {
            const float busGain = gainPrev + (gainTarget - gainPrev) * (static_cast<float>(f + 1) / static_cast<float>(frames));
            if (s.step != 0.0f) {                       // 먼저 한 스텝 진행 -> n 번째 프레임의 게인 = n/fadeFrames (효과음 페이드/버스 게인과 같은 규약)
                s.gain += s.step;
                if ((s.step > 0.0f && s.gain >= s.target) || (s.step < 0.0f && s.gain <= s.target)) { s.gain = s.target; s.step = 0.0f; }
            }
            out[2 * f]     += scratch_[static_cast<std::size_t>(2 * f)]     * s.gain * busGain;
            out[2 * f + 1] += scratch_[static_cast<std::size_t>(2 * f + 1)] * s.gain * busGain;
        }
    }
    for (auto it = music_.begin(); it != music_.end();) {           // 끝났거나 페이드아웃이 끝난 곡은 묘지로
        if (it->stream->Finished() || (it->dying && it->gain <= 0.0f)) { graveyard_.push_back(std::move(it->stream)); it = music_.erase(it); }
        else ++it;
    }
}

void Mixer::Mix(float* out, int frames) {
    if (frames <= 0 || !out) return;
    std::lock_guard<std::mutex> lock(mutex_);
    std::fill(out, out + static_cast<std::size_t>(frames) * 2, 0.0f);

    const float sfxTarget   = master_ * busVol_[0];
    const float musicTarget = master_ * busVol_[1];
    for (Voice& v : voices_) if (v.active) MixVoice(v, out, frames, curSfxGain_, sfxTarget);
    MixMusic(out, frames, curMusicGain_, musicTarget);
    curSfxGain_ = sfxTarget;
    curMusicGain_ = musicTarget;

    Levels pk;
    for (int f = 0; f < frames; ++f) {
        float& l = out[2 * f]; float& r = out[2 * f + 1];
        if (!std::isfinite(l)) l = 0.0f;
        if (!std::isfinite(r)) r = 0.0f;
        pk.left = std::max(pk.left, std::fabs(l));
        pk.right = std::max(pk.right, std::fabs(r));
        l = std::max(-1.0f, std::min(1.0f, l));
        r = std::max(-1.0f, std::min(1.0f, r));
    }
    peak_ = pk;
    framesMixed_ += static_cast<std::uint64_t>(frames);
}

} // namespace engine
