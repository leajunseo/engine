#pragma once
// ---------------------------------------------------------------------------
// 파일에서 스트리밍하는 음악 (WAV). 별도 디코더 스레드가 파일을 읽고 믹서 샘플레이트로 리샘플링(선형)해서
// 링 버퍼(약 1초)에 채우고, 오디오 스레드는 링 버퍼에서 복사만 한다 -> 오디오 콜백이 디스크 I/O 로 막히지 않는다.
//
//   auto music = StreamingMusic::Open("assets/bgm.wav", mixer.SampleRate(), /*loop*/ true);
//   mixer.PlayMusic(std::move(music), 1.0f);
//
// 버퍼 부족(디스크가 너무 느림)이면 그 구간은 무음이 되고 재생은 이어진다 (Finished 는 true 가 되지 않음).
// 리샘플러는 선형 보간이라 고주파가 약간 뭉개진다 (음악은 믹서와 같은 레이트로 만들어 두면 원본 그대로).
// [Limitation] WAV 만 지원. 파일이 크면(수십 MB) 디스크 용량은 크지만 메모리는 링 버퍼만 쓴다.
// ---------------------------------------------------------------------------
#include <memory>
#include <string>

#include "Audio/Mixer.hpp"

namespace engine {

class StreamingMusic final : public IAudioStream {
public:
    /// 실패하면 nullptr (error 에 이유). outRate 는 보통 Mixer::SampleRate().
    static std::unique_ptr<StreamingMusic> Open(const std::string& path, int outRate, bool loop, std::string* error = nullptr);
    ~StreamingMusic() override;
    StreamingMusic(const StreamingMusic&)            = delete;
    StreamingMusic& operator=(const StreamingMusic&) = delete;

    int  Read(float* dst, int frames) override;
    bool Finished() const override;

    /// 디코더가 링 버퍼를 (거의) 채우거나 파일 끝에 도달할 때까지 최대 timeoutMs 기다림.
    /// 재생 시작 직후 첫 블록이 무음이 되는 것을 막거나, 테스트에서 결정적인 결과를 얻을 때 사용.
    bool WaitUntilBuffered(int timeoutMs = 1000);

    double DurationSeconds() const;     // 파일 길이 (루프와 무관)

private:
    StreamingMusic();
    struct Impl;
    std::unique_ptr<Impl> impl_;
};

} // namespace engine
