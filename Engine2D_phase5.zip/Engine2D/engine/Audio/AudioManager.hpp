#pragma once
// ---------------------------------------------------------------------------
// 오디오 장치(SDL) + Mixer 소유자. SDL 헤더는 .cpp 안에만 있다.
//
//   Application 이 소유 -> app.Audio().   (ApplicationConfig::enableAudio / audio 로 설정)
//   auto clip = app.Assets().Load<AudioClip>("shoot.wav");     // 핫 리로드 지원 (Application 이 로더 등록)
//   app.Audio().PlaySfx(*clip, {.volume = 0.8f, .pitch = 1.2f});
//   app.Audio().PlayMusic(app.Assets().Resolve("bgm.wav"), true, 1.0f);
//
// 오디오 장치가 없거나 열기에 실패하면 '무음 모드' 로 계속 동작한다 (Init 은 false 를 반환하지만 게임은 계속됨).
//   무음 모드에서도 Mixer 는 살아 있어 호출이 모두 안전하다 (소리만 나지 않고, 보이스/음악은 진행되지 않음).
// [Limitation] 장치 핫플러그(헤드폰 연결/해제) 시 자동 재연결 없음 — SDL 기본 장치가 바뀌면 재시작 필요.
// ---------------------------------------------------------------------------
#include <memory>
#include <string>

#include "Audio/Mixer.hpp"

namespace engine {

struct AudioConfig {
    int sampleRate   = 48000;
    int bufferFrames = 1024;     // 장치 버퍼 (작을수록 지연이 짧고 끊김 위험이 큼, ~21ms @48k)
    int maxVoices    = 64;
};

class AudioManager {
public:
    explicit AudioManager(AudioConfig config = {});
    ~AudioManager();
    AudioManager(const AudioManager&)            = delete;
    AudioManager& operator=(const AudioManager&) = delete;

    /// 장치를 연다. 실패하면 false (무음 모드로 계속). 여러 번 불러도 안전.
    bool Init();
    void Shutdown();
    bool HasDevice() const { return device_ != 0; }
    int  SampleRate() const { return mixer_->SampleRate(); }

    /// 프레임마다 1회 (Application 이 호출): 끝난 음악 스트림 정리.
    void Update() { mixer_->Update(); }

    Mixer& GetMixer() { return *mixer_; }

    // ---- 편의 함수 ----
    VoiceId PlaySfx(const AudioClip& clip, PlayParams params = {}) { return mixer_->Play(clip, params); }
    /// WAV 를 스트리밍 재생. 실패하면 false (이전 음악은 그대로 유지).
    bool PlayMusic(const std::string& path, bool loop = true, float fadeInSeconds = 0.5f, std::string* error = nullptr);
    void StopMusic(float fadeOutSeconds = 0.5f) { mixer_->StopMusic(fadeOutSeconds); }

private:
    AudioConfig config_;
    std::unique_ptr<Mixer> mixer_;
    unsigned device_ = 0;            // SDL_AudioDeviceID
    bool audioInited_ = false;
};

} // namespace engine
