#include "Audio/MusicStream.hpp"

#include <algorithm>
#include <atomic>
#include <chrono>
#include <cmath>
#include <condition_variable>
#include <mutex>
#include <thread>
#include <vector>

#include "Audio/Wav.hpp"
#include "Core/Log.hpp"

namespace engine {
namespace {

constexpr std::size_t kChunkFrames = 4096;      // 한 번에 디코딩하는 입력 프레임 수

// 선형 보간 리샘플러 (청크 경계에서 연속). 입력/출력은 스테레오 인터리브.
//   pos 는 '현재 청크 첫 프레임 = 0' 기준의 입력 좌표. 청크 -1 번 프레임 = 직전 청크의 마지막 프레임(prev).
class LinearResampler {
public:
    LinearResampler(int inRate, int outRate) : step_(static_cast<double>(inRate) / outRate), same_(inRate == outRate) {}
    void Process(const float* in, std::size_t n, std::vector<float>& out) {
        if (n == 0) return;
        if (same_) { out.insert(out.end(), in, in + n * 2); return; }
        const long last = static_cast<long>(n) - 1;
        for (;;) {
            const long i = static_cast<long>(std::floor(pos_));
            if (i + 1 > last) break;                               // i+1 번 프레임이 아직 없음 -> 다음 청크에서
            const float frac = static_cast<float>(pos_ - static_cast<double>(i));
            const float l0 = i < 0 ? prev_[0] : in[2 * i],     r0 = i < 0 ? prev_[1] : in[2 * i + 1];
            const float l1 = in[2 * (i + 1)],                  r1 = in[2 * (i + 1) + 1];
            out.push_back(l0 + (l1 - l0) * frac);
            out.push_back(r0 + (r1 - r0) * frac);
            pos_ += step_;
        }
        prev_[0] = in[2 * last]; prev_[1] = in[2 * last + 1];
        pos_ -= static_cast<double>(n);
    }
private:
    double step_, pos_ = 0.0;
    float prev_[2] = {0.0f, 0.0f};
    bool same_;
};

} // namespace

struct StreamingMusic::Impl {
    WavReader reader;
    LinearResampler* resampler = nullptr;
    int outRate = 48000;
    bool loop = false;

    std::vector<float> ring;            // 스테레오 프레임 단위 순환 버퍼
    std::size_t capFrames = 0, head = 0, count = 0;     // head = 다음에 읽을 위치
    mutable std::mutex m;
    std::condition_variable cv;
    std::atomic<bool> stop{false};
    bool eof = false;                   // m 으로 보호
    std::thread worker;

    ~Impl() { delete resampler; }

    void Run() {
        std::vector<float> in(kChunkFrames * 2), out;
        // 입력 샘플레이트가 아주 낮으면 한 청크의 출력이 링 버퍼보다 커질 수 있다 -> 청크 출력이 버퍼 용량을 넘지 않게 청크를 줄이고,
        // 기록은 공간이 생기는 대로 조각내서 한다 (공간을 통째로 기다리면 출력 > 용량일 때 영원히 교착).
        const std::size_t chunk = std::max<std::size_t>(1, std::min<std::size_t>(kChunkFrames,
            static_cast<std::size_t>(static_cast<double>(capFrames) * reader.SampleRate() / outRate)));
        while (!stop.load()) {
            {
                std::unique_lock<std::mutex> lk(m);
                cv.wait(lk, [&] { return stop.load() || capFrames - count >= std::min<std::size_t>(capFrames / 4, 1024); });
                if (stop.load()) return;
            }
            std::size_t n = reader.ReadStereo(in.data(), chunk);
            if (n == 0 && loop && reader.TotalFrames() > 0 && reader.Rewind()) n = reader.ReadStereo(in.data(), chunk);
            if (n == 0) {
                std::lock_guard<std::mutex> lk(m);
                eof = true;
                cv.notify_all();
                return;
            }
            out.clear();
            resampler->Process(in.data(), n, out);
            const std::size_t total = out.size() / 2;
            std::size_t done = 0;
            while (done < total) {
                std::unique_lock<std::mutex> lk(m);
                cv.wait(lk, [&] { return stop.load() || count < capFrames; });
                if (stop.load()) return;
                const std::size_t frames = std::min(total - done, capFrames - count);
                std::size_t w = (head + count) % capFrames;
                for (std::size_t i = 0; i < frames; ++i) {
                    ring[2 * w] = out[2 * (done + i)]; ring[2 * w + 1] = out[2 * (done + i) + 1];
                    if (++w == capFrames) w = 0;
                }
                count += frames;
                done += frames;
                cv.notify_all();
            }
        }
    }
};

StreamingMusic::StreamingMusic() : impl_(std::make_unique<Impl>()) {}

StreamingMusic::~StreamingMusic() {
    if (!impl_) return;
    impl_->stop.store(true);
    { std::lock_guard<std::mutex> lk(impl_->m); }       // 대기 중인 워커가 stop 을 놓치지 않도록
    impl_->cv.notify_all();
    if (impl_->worker.joinable()) impl_->worker.join();
}

std::unique_ptr<StreamingMusic> StreamingMusic::Open(const std::string& path, int outRate, bool loop, std::string* error) {
    if (outRate < 8000 || outRate > 384000) { if (error) *error = "bad output rate"; return nullptr; }
    std::unique_ptr<StreamingMusic> s(new StreamingMusic());
    Impl& d = *s->impl_;
    if (!d.reader.Open(path, error)) return nullptr;
    d.outRate = outRate;
    d.loop = loop;
    d.resampler = new LinearResampler(d.reader.SampleRate(), outRate);
    d.capFrames = static_cast<std::size_t>(outRate);              // 약 1초
    d.ring.assign(d.capFrames * 2, 0.0f);
    d.worker = std::thread([impl = s->impl_.get()] { impl->Run(); });
    return s;
}

int StreamingMusic::Read(float* dst, int frames) {
    Impl& d = *impl_;
    std::lock_guard<std::mutex> lk(d.m);
    const std::size_t n = std::min<std::size_t>(d.count, static_cast<std::size_t>(std::max(0, frames)));
    for (std::size_t i = 0; i < n; ++i) {
        dst[2 * i] = d.ring[2 * d.head]; dst[2 * i + 1] = d.ring[2 * d.head + 1];
        if (++d.head == d.capFrames) d.head = 0;
    }
    d.count -= n;
    if (n > 0) d.cv.notify_all();
    return static_cast<int>(n);
}

bool StreamingMusic::Finished() const {
    std::lock_guard<std::mutex> lk(impl_->m);
    return impl_->eof && impl_->count == 0;
}

bool StreamingMusic::WaitUntilBuffered(int timeoutMs) {
    Impl& d = *impl_;
    std::unique_lock<std::mutex> lk(d.m);
    return d.cv.wait_for(lk, std::chrono::milliseconds(timeoutMs), [&] { return d.eof || d.count >= d.capFrames * 3 / 4; });
}

double StreamingMusic::DurationSeconds() const {
    return impl_->reader.SampleRate() > 0 ? static_cast<double>(impl_->reader.TotalFrames()) / impl_->reader.SampleRate() : 0.0;
}

} // namespace engine
