#pragma once
// ---------------------------------------------------------------------------
// WAV (RIFF) 디코더/인코더 + 스트리밍 리더. 외부 의존성 없음.
//   지원: PCM 8/16/24/32bit, IEEE float 32bit, WAVE_FORMAT_EXTENSIBLE, 1~8 채널(앞의 2채널만 사용, 모노는 복제).
//   방어: 모든 읽기를 경계 검사하고, 헤더의 크기 필드가 실제 파일보다 크면(잘린 파일) 실제 있는 만큼만 읽는다.
//         샘플레이트/채널/길이 상한(kMaxWavFrames)을 넘으면 거부.
//   한계: 압축 포맷(ADPCM, MP3-in-WAV 등)과 'RF64' 는 미지원 -> false.
//   (OGG/MP3 는 이 단계에서 미지원. 필요하면 stb_vorbis / dr_mp3 를 Wav 와 같은 자리에 붙이면 된다.)
// ---------------------------------------------------------------------------
#include <cstddef>
#include <cstdint>
#include <fstream>
#include <string>
#include <vector>

#include "Audio/AudioClip.hpp"

namespace engine {

constexpr std::size_t kMaxWavFrames = 16'000'000;     // 48kHz 기준 약 5.5분 (float 스테레오 128MB)

bool DecodeWav(const std::uint8_t* data, std::size_t size, AudioClip& out);
bool LoadWavFile(const std::string& path, AudioClip& out);

/// 인터리브 float (-1..1) -> 16bit PCM WAV 바이트. channels = 1 또는 2.
std::vector<std::uint8_t> EncodeWav16(const float* interleaved, std::size_t frames, int channels, int sampleRate);
bool SaveWav16(const std::string& path, const float* interleaved, std::size_t frames, int channels, int sampleRate);

/// 파일에서 조금씩 읽는 WAV 리더 (음악 스트리밍용).
class WavReader {
public:
    bool Open(const std::string& path, std::string* error = nullptr);
    /// 최대 frames 프레임을 스테레오 float 로 읽는다. 읽은 프레임 수 반환 (0 = 끝).
    std::size_t ReadStereo(float* dst, std::size_t frames);
    bool Rewind();
    int SampleRate() const { return rate_; }
    std::uint64_t TotalFrames() const { return totalFrames_; }
    bool IsOpen() const { return file_.is_open(); }

private:
    std::ifstream file_;
    int  format_ = 0, channels_ = 0, rate_ = 0, bits_ = 0;
    std::size_t blockAlign_ = 0;
    std::uint64_t dataOffset_ = 0, totalFrames_ = 0, framePos_ = 0;
    std::vector<std::uint8_t> raw_;
};

} // namespace engine
