#pragma once
// 2D 아핀 변환 (2x3). 점 변환:  x' = a*x + c*y + tx,  y' = b*x + d*y + ty   (열벡터 (a,b), (c,d) = 변환된 X/Y 축)
// 씬 그래프의 월드 행렬로 쓴다. 합성은 Compose(parent, child) = parent * child (child 를 먼저 적용).
#include <cmath>

#include "Math/Math.hpp"

namespace engine {

struct Affine2D {
    float a = 1.0f, b = 0.0f, c = 0.0f, d = 1.0f, tx = 0.0f, ty = 0.0f;

    static Affine2D Identity() { return {}; }
    /// 로컬 TRS: 먼저 스케일, 다음 회전(라디안, 반시계), 마지막 이동.
    static Affine2D FromTRS(Vec2 position, float rotation, Vec2 scale) {
        const float cs = std::cos(rotation), sn = std::sin(rotation);
        Affine2D m;
        m.a = cs * scale.x;  m.b = sn * scale.x;
        m.c = -sn * scale.y; m.d = cs * scale.y;
        m.tx = position.x;   m.ty = position.y;
        return m;
    }

    Vec2 TransformPoint(Vec2 p) const { return {a * p.x + c * p.y + tx, b * p.x + d * p.y + ty}; }
    Vec2 TransformVector(Vec2 v) const { return {a * v.x + c * v.y, b * v.x + d * v.y}; }

    float Determinant() const { return a * d - b * c; }
    bool  Invertible() const  { return std::fabs(Determinant()) > 1e-12f; }

    /// 역변환. 특이 행렬(스케일 0)이면 항등을 반환한다 (Invertible() 로 먼저 확인할 것).
    Affine2D Inverse() const {
        const float det = Determinant();
        if (std::fabs(det) <= 1e-12f) return {};
        const float id = 1.0f / det;
        Affine2D r;
        r.a = d * id;   r.b = -b * id;
        r.c = -c * id;  r.d = a * id;
        r.tx = -(r.a * tx + r.c * ty);
        r.ty = -(r.b * tx + r.d * ty);
        return r;
    }

    // 분해 (균일/비균일 스케일 + 회전 가정. 전단(shear)이 섞인 행렬에서는 근사값)
    Vec2  Position() const { return {tx, ty}; }
    float Rotation() const { return std::atan2(b, a); }
    Vec2  Scale() const    { return {std::sqrt(a * a + b * b), std::sqrt(c * c + d * d) * (Determinant() < 0.0f ? -1.0f : 1.0f)}; }
};

/// parent * child
inline Affine2D Compose(const Affine2D& p, const Affine2D& ch) {
    Affine2D r;
    r.a  = p.a * ch.a + p.c * ch.b;
    r.b  = p.b * ch.a + p.d * ch.b;
    r.c  = p.a * ch.c + p.c * ch.d;
    r.d  = p.b * ch.c + p.d * ch.d;
    r.tx = p.a * ch.tx + p.c * ch.ty + p.tx;
    r.ty = p.b * ch.tx + p.d * ch.ty + p.ty;
    return r;
}

} // namespace engine

namespace engine {
/// 각도(라디안) 보간: 항상 가까운 방향으로 돈다 (±π 경계에서 한 바퀴 도는 것 방지).
inline float LerpAngle(float a, float b, float t) {
    const float d = std::remainder(b - a, 2.0f * kPi);
    return a + d * t;
}
} // namespace engine
