#pragma once
// 최소 수학 타입. Phase 2 에서 필요한 것만 둔다 (Vec2, Color, Mat4).
// 좌표계: 월드는 Y-up (오른손), 원점 = 월드 원점. 화면 픽셀 좌표는 좌상단 원점 / Y-down.
#include <cmath>
#include <cstdint>

namespace engine {

constexpr float kPi = 3.14159265358979323846f;

struct Vec2 {
    float x = 0.0f, y = 0.0f;
    constexpr Vec2() = default;
    constexpr Vec2(float x_, float y_) : x(x_), y(y_) {}
    constexpr Vec2 operator+(Vec2 o) const { return {x + o.x, y + o.y}; }
    constexpr Vec2 operator-(Vec2 o) const { return {x - o.x, y - o.y}; }
    constexpr Vec2 operator*(float s) const { return {x * s, y * s}; }
    constexpr Vec2 operator/(float s) const { return {x / s, y / s}; }
    constexpr Vec2 operator-() const { return {-x, -y}; }
    Vec2& operator+=(Vec2 o) { x += o.x; y += o.y; return *this; }
    Vec2& operator-=(Vec2 o) { x -= o.x; y -= o.y; return *this; }
    Vec2& operator*=(float s) { x *= s; y *= s; return *this; }
    constexpr float LengthSq() const { return x * x + y * y; }
    float Length() const { return std::sqrt(x * x + y * y); }
};

inline constexpr Vec2  operator*(float s, Vec2 v) { return {v.x * s, v.y * s}; }
inline constexpr float Dot(Vec2 a, Vec2 b)   { return a.x * b.x + a.y * b.y; }
inline constexpr float Cross(Vec2 a, Vec2 b) { return a.x * b.y - a.y * b.x; }          // 스칼라(z) 외적
inline constexpr Vec2  Cross(Vec2 v, float s) { return {s * v.y, -s * v.x}; }            // v x (s * z)
inline constexpr Vec2  Cross(float s, Vec2 v) { return {-s * v.y, s * v.x}; }            // (s * z) x v
inline constexpr Vec2  Perp(Vec2 v) { return {-v.y, v.x}; }                              // 반시계 90도
inline Vec2 Normalized(Vec2 v) { const float l = v.Length(); return l > 1e-12f ? v / l : Vec2{0.0f, 0.0f}; }

inline float Lerp(float a, float b, float t) { return a + (b - a) * t; }
inline Vec2  Lerp(Vec2 a, Vec2 b, float t)    { return {Lerp(a.x, b.x, t), Lerp(a.y, b.y, t)}; }
inline float Clamp(float v, float lo, float hi) { return v < lo ? lo : (v > hi ? hi : v); }

struct Color {
    float r = 1.0f, g = 1.0f, b = 1.0f, a = 1.0f;
    constexpr Color() = default;
    constexpr Color(float r_, float g_, float b_, float a_ = 1.0f) : r(r_), g(g_), b(b_), a(a_) {}

    /// 0xAABBGGRR (리틀 엔디안 메모리상 R,G,B,A 바이트 순) - GL_UNSIGNED_BYTE 정점 속성용
    std::uint32_t Pack() const {
        auto u8 = [](float v) { return static_cast<std::uint32_t>(Clamp(v, 0.0f, 1.0f) * 255.0f + 0.5f); };
        return u8(r) | (u8(g) << 8) | (u8(b) << 16) | (u8(a) << 24);
    }
};

/// 열 우선(column-major) 4x4 행렬 - OpenGL 업로드 형식 그대로.
struct Mat4 { float m[16] = {1,0,0,0, 0,1,0,0, 0,0,1,0, 0,0,0,1}; };

} // namespace engine
