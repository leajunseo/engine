#pragma once
// ---------------------------------------------------------------------------
// Type-safe 이벤트 디스패처.
//   Subscribe<E>(fn)  -> RAII Subscription (소멸 시 자동 해제)      [메인 스레드 전용]
//   Publish<E>(e)     -> 즉시(동기) 전달                              [메인 스레드 전용]
//   Enqueue<E>(e)     -> 큐잉 후 DispatchQueued() 때 전달             [어느 스레드나 가능]
//
// 설계 포인트
//  * RTTI(type_index) 없이 템플릿 static 로 타입별 정수 ID 를 부여 -> 핸들러 목록 O(1) 조회.
//  * 핸들러 컨테이너는 std::deque: Publish 도중 Subscribe 가 일어나도 실행 중인
//    std::function 참조가 무효화되지 않는다.
//  * 핸들러 실행 중 Unsubscribe 는 '표시(tombstone)'만 하고, 최외곽 Publish 종료 시 정리한다.
//  * EventBus 가 먼저 파괴돼도 Subscription 소멸이 안전하도록 weak_ptr 생존 토큰을 사용한다.
//
// [Bottleneck] Enqueue 는 std::function 으로 이벤트를 지우므로 호출당 힙 할당이 가능하다.
//   고빈도 큐 이벤트(예: 초당 수만 건의 충돌 이벤트)가 필요해지면 타입별 SPSC 링 버퍼로 교체.
//   Publish(즉시 전달)는 할당이 없다.
// ---------------------------------------------------------------------------
#include <algorithm>
#include <atomic>
#include <cstddef>
#include <cstdint>
#include <deque>
#include <functional>
#include <memory>
#include <mutex>
#include <utility>
#include <vector>

namespace engine {

class EventBus;

namespace detail {

inline std::size_t NextEventTypeId() {
    static std::atomic<std::size_t> counter{0};
    return counter.fetch_add(1);
}
template <class E>
std::size_t EventTypeId() {
    static const std::size_t id = NextEventTypeId();
    return id;
}

struct IHandlerList {
    virtual ~IHandlerList() = default;
    virtual void Remove(std::uint64_t id) = 0;
};

template <class E>
struct HandlerList final : IHandlerList {
    struct Entry { std::uint64_t id; std::function<void(const E&)> fn; };  // id==0 : 삭제 표시
    std::deque<Entry> entries;
    int               depth = 0;       // 현재 Publish 중첩 깊이
    bool              dirty = false;

    void Remove(std::uint64_t id) override {
        for (auto& e : entries) {
            if (e.id == id) { e.id = 0; dirty = true; break; }
        }
        if (depth == 0) Compact();
    }
    void Compact() {
        entries.erase(std::remove_if(entries.begin(), entries.end(),
                                     [](const Entry& e) { return e.id == 0; }),
                      entries.end());
        dirty = false;
    }
};

} // namespace detail

/// 이동 전용 구독 핸들. 소멸/Unsubscribe() 시 핸들러가 해제된다.
class Subscription {
public:
    Subscription() = default;
    Subscription(const Subscription&)            = delete;
    Subscription& operator=(const Subscription&) = delete;
    Subscription(Subscription&& o) noexcept { *this = std::move(o); }
    Subscription& operator=(Subscription&& o) noexcept {
        if (this != &o) {
            Unsubscribe();
            bus_ = o.bus_;  alive_ = std::move(o.alive_);
            typeId_ = o.typeId_;  id_ = o.id_;
            o.bus_ = nullptr;  o.id_ = 0;
        }
        return *this;
    }
    ~Subscription() { Unsubscribe(); }

    inline void Unsubscribe();                       // EventBus 정의 뒤에 구현
    bool Active() const { return bus_ != nullptr && id_ != 0; }

private:
    friend class EventBus;
    Subscription(EventBus* bus, std::weak_ptr<void> alive, std::size_t typeId, std::uint64_t id)
        : bus_(bus), alive_(std::move(alive)), typeId_(typeId), id_(id) {}

    EventBus*           bus_    = nullptr;
    std::weak_ptr<void> alive_;
    std::size_t         typeId_ = 0;
    std::uint64_t       id_     = 0;
};

class EventBus {
public:
    EventBus() : alive_(std::make_shared<int>(0)) {}
    EventBus(const EventBus&)            = delete;
    EventBus& operator=(const EventBus&) = delete;

    template <class E>
    [[nodiscard]] Subscription Subscribe(std::function<void(const E&)> handler) {
        auto& list = GetOrCreateList<E>();
        const std::uint64_t id = ++nextId_;
        list.entries.push_back({id, std::move(handler)});
        return Subscription(this, alive_, detail::EventTypeId<E>(), id);
    }

    /// 동기 전달. 핸들러 안에서 Subscribe/Unsubscribe/Publish 모두 허용.
    template <class E>
    void Publish(const E& event) {
        auto* list = FindList<E>();
        if (!list) return;
        ++list->depth;
        // 인덱스 순회: 핸들러가 push_back 해도 안전(deque 는 참조 유지). 이번 Publish 중
        // 새로 추가된 핸들러도 같은 루프에서 호출될 수 있다는 점에 유의.
        for (std::size_t i = 0; i < list->entries.size(); ++i) {
            auto& entry = list->entries[i];
            if (entry.id != 0) entry.fn(event);
        }
        if (--list->depth == 0 && list->dirty) list->Compact();
    }

    /// 스레드 세이프. 워커 스레드에서 메인 스레드로 이벤트를 넘길 때 사용.
    template <class E>
    void Enqueue(E event) {
        std::lock_guard<std::mutex> lock(queueMutex_);
        queue_.emplace_back([this, ev = std::move(event)]() { Publish(ev); });
    }

    /// 메인 스레드에서 프레임당 1회 호출. 디스패치 중 Enqueue 된 이벤트는 다음 호출에서 전달.
    void DispatchQueued() {
        scratch_.clear();
        {
            std::lock_guard<std::mutex> lock(queueMutex_);
            scratch_.swap(queue_);         // 두 벡터가 capacity 를 재사용 -> 평상시 추가 할당 없음
        }
        for (auto& fn : scratch_) fn();
    }

private:
    friend class Subscription;

    template <class E>
    detail::HandlerList<E>& GetOrCreateList() {
        const std::size_t id = detail::EventTypeId<E>();
        if (id >= lists_.size()) lists_.resize(id + 1);
        if (!lists_[id]) lists_[id] = std::make_unique<detail::HandlerList<E>>();
        return static_cast<detail::HandlerList<E>&>(*lists_[id]);
    }
    template <class E>
    detail::HandlerList<E>* FindList() {
        const std::size_t id = detail::EventTypeId<E>();
        if (id >= lists_.size() || !lists_[id]) return nullptr;
        return static_cast<detail::HandlerList<E>*>(lists_[id].get());
    }
    void UnsubscribeInternal(std::size_t typeId, std::uint64_t id) {
        if (typeId < lists_.size() && lists_[typeId]) lists_[typeId]->Remove(id);
    }

    std::shared_ptr<int>                               alive_;   // 생존 토큰
    std::vector<std::unique_ptr<detail::IHandlerList>> lists_;
    std::uint64_t                                      nextId_ = 0;

    std::mutex                          queueMutex_;
    std::vector<std::function<void()>>  queue_;
    std::vector<std::function<void()>>  scratch_;
};

inline void Subscription::Unsubscribe() {
    if (bus_ && id_ != 0 && alive_.lock()) bus_->UnsubscribeInternal(typeId_, id_);
    bus_ = nullptr;
    id_  = 0;
    alive_.reset();
}

} // namespace engine
