#pragma once
#include <string>

#include "Core/EventBus.hpp"

struct SDL_Window;   // SDL 헤더가 엔진 공개 헤더로 새지 않도록 전방 선언

namespace engine {

struct WindowConfig {
    std::string title      = "Engine2D";
    int         width      = 1280;
    int         height     = 720;
    bool        fullscreen = false;     // 데스크톱 풀스크린(보더리스) 모드
    bool        resizable  = true;
    bool        vsync      = true;
    int         glMajor    = 3;
    int         glMinor    = 3;
    int         msaa       = 0;         // 0 = 끔. 2D 픽셀아트는 보통 0 권장
};

/// SDL2 창 + OpenGL 컨텍스트를 RAII 로 소유. 플랫폼 이벤트는 EventBus 로 변환해 발행한다.
class Window {
public:
    explicit Window(EventBus& bus);
    ~Window();
    Window(const Window&)            = delete;
    Window& operator=(const Window&) = delete;

    [[nodiscard]] bool Create(const WindowConfig& config);
    void Destroy();

    void PollEvents();                  // 프레임당 1회, 메인 스레드
    void SwapBuffers();
    void SetTitle(const char* title);
    void SetVSync(bool enabled);

    void GetSize(int& w, int& h) const;          // 논리 크기(점)
    void GetDrawableSize(int& w, int& h) const;  // 실제 픽셀 크기 (HiDPI 에서 GetSize 와 다름)
    bool IsOpen() const { return window_ != nullptr; }

private:
    EventBus&   bus_;
    SDL_Window* window_      = nullptr;
    void*       glContext_   = nullptr;   // SDL_GLContext (= void*)
    bool        videoInited_ = false;
};

} // namespace engine
