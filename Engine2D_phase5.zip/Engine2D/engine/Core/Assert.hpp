#pragma once
// ENGINE_ASSERT: Debug 빌드에서만 검사. 실패 시 Fatal 로그 + 디버거 브레이크.
// Release 에서는 조건식이 평가되지 않으므로 부작용(side effect)이 있는 식을 넣지 말 것.
#include "Core/Log.hpp"

#if defined(_MSC_VER)
  #define ENGINE_DEBUGBREAK() __debugbreak()
#else
  #define ENGINE_DEBUGBREAK() __builtin_trap()
#endif

#ifdef ENGINE_DEBUG
  #define ENGINE_ASSERT(cond, ...)                                                   \
    do {                                                                             \
      if (!(cond)) {                                                                 \
        ENGINE_LOG_FATAL("Assertion failed: " #cond " | " __VA_ARGS__);              \
        ENGINE_DEBUGBREAK();                                                         \
      }                                                                              \
    } while (0)
#else
  #define ENGINE_ASSERT(cond, ...) do { (void)sizeof(cond); } while (0)
#endif
