#pragma once
// 플랫폼 계층이 EventBus 로 발행하는 이벤트들. 값 타입(POD)으로 유지할 것.
// Window <-> Renderer <-> Game 은 서로를 직접 참조하지 않고 이 이벤트로만 통신한다.
#include "Input/KeyCode.hpp"

namespace engine {

struct WindowClosedEvent {};
struct WindowResizedEvent { int width; int height; };     // 드로어블(픽셀) 크기 - HiDPI 반영
struct WindowFocusEvent   { bool focused; };
// KeyEvent: scancode 는 기존 호환용(SDL 값 그대로), key 는 플랫폼 독립 KeyCode (Phase 5 의 InputManager 가 사용).
struct MouseMoveEvent     { float x; float y; };            // 드로어블(픽셀) 좌표, 좌상단 원점
struct MouseWheelEvent    { float dy; };                    // 위로 굴리면 +
struct MouseButtonEvent   { int button; bool pressed; float x; float y; };   // button: 1=좌 2=가운데 3=우 (SDL_BUTTON_*)
struct KeyEvent           { int scancode; bool pressed; bool repeat; KeyCode key = KeyCode::Unknown; };

} // namespace engine
