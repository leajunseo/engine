#pragma once
// 프레임 단위 선형(bump) 할당기. 프레임 시작에 Reset() 하면 전체가 O(1) 로 해제된다.
//  - 소멸자를 호출하지 않으므로 trivially destructible 타입 전용.
//  - 블록이 모자라면 새 블록을 추가하고, Reset 후에도 블록을 유지(고수위 유지) -> 정상 상태에서 malloc 0회.
#include <cstddef>
#include <cstdint>
#include <memory>
#include <type_traits>
#include <vector>

namespace engine {

class FrameArena {
public:
    explicit FrameArena(std::size_t blockBytes = 1u << 20) : blockBytes_(blockBytes) {}

    void* Allocate(std::size_t bytes, std::size_t align = alignof(std::max_align_t)) {
        for (;;) {
            if (current_ < blocks_.size()) {
                Block& b = blocks_[current_];
                const auto base    = reinterpret_cast<std::uintptr_t>(b.data.get() + b.used);
                const auto aligned = (base + align - 1) & ~(static_cast<std::uintptr_t>(align) - 1);
                const std::size_t pad = static_cast<std::size_t>(aligned - base);
                if (b.used + pad + bytes <= b.size) {
                    b.used += pad + bytes;
                    return reinterpret_cast<void*>(aligned);
                }
                ++current_;                       // 이 블록은 가득 참 -> 다음 블록 시도
            } else {
                Block b;
                b.size = bytes + align > blockBytes_ ? bytes + align : blockBytes_;
                b.data.reset(new std::byte[b.size]);
                blocks_.push_back(std::move(b));  // current_ 는 새 블록을 가리킨다
            }
        }
    }

    template <class T>
    T* AllocateArray(std::size_t count) {
        static_assert(std::is_trivially_destructible_v<T>, "FrameArena never runs destructors");
        return static_cast<T*>(Allocate(sizeof(T) * count, alignof(T)));
    }

    void Reset() {
        for (Block& b : blocks_) b.used = 0;
        current_ = 0;
    }

    std::size_t CapacityBytes() const { std::size_t n = 0; for (const Block& b : blocks_) n += b.size; return n; }

private:
    struct Block { std::unique_ptr<std::byte[]> data; std::size_t size = 0; std::size_t used = 0; };
    std::vector<Block> blocks_;
    std::size_t        current_    = 0;
    std::size_t        blockBytes_;
};

} // namespace engine
