#pragma once
// 고정 크기 객체 풀 (free-list). 같은 타입 객체를 대량으로 만들고 지우는 곳(쿼드트리 노드, 파티클 등)용.
//  - Create/Destroy 모두 O(1), 개별 malloc 없음. 청크 단위로만 확장하며 객체 주소는 변하지 않는다.
//  - 풀이 파괴될 때 살아있는 객체의 소멸자는 호출되지 않는다 (Destroy 로 직접 반환할 것).
//  - 스레드 세이프하지 않음.
#include <cstddef>
#include <memory>
#include <new>
#include <utility>
#include <vector>

namespace engine {

template <class T, std::size_t ChunkSize = 256>
class PoolAllocator {
public:
    PoolAllocator() = default;
    PoolAllocator(const PoolAllocator&)            = delete;
    PoolAllocator& operator=(const PoolAllocator&) = delete;

    template <class... Args>
    T* Create(Args&&... args) {
        if (!free_) Grow();
        Slot* s = free_;
        free_   = s->next;
        ++live_;
        return ::new (static_cast<void*>(s->storage)) T(std::forward<Args>(args)...);
    }

    void Destroy(T* p) {
        if (!p) return;
        p->~T();
        Slot* s = reinterpret_cast<Slot*>(p);
        s->next = free_;
        free_   = s;
        --live_;
    }

    std::size_t LiveCount() const { return live_; }

private:
    union Slot {
        alignas(T) unsigned char storage[sizeof(T)];
        Slot* next;
    };

    void Grow() {
        auto chunk = std::make_unique<Slot[]>(ChunkSize);
        for (std::size_t i = 0; i < ChunkSize; ++i) {
            chunk[i].next = free_;
            free_ = &chunk[i];
        }
        chunks_.push_back(std::move(chunk));
    }

    std::vector<std::unique_ptr<Slot[]>> chunks_;
    Slot*       free_ = nullptr;
    std::size_t live_ = 0;
};

} // namespace engine
