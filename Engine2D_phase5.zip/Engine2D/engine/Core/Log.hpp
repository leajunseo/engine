#pragma once
// ---------------------------------------------------------------------------
// Thread-safe logger. 콘솔(Info/Warning=stdout, Error/Fatal=stderr) + 선택적 파일 출력.
//
// [Bottleneck] 모든 출력이 단일 mutex 로 직렬화된다. Phase 1 규모에선 충분하지만
//   로그를 초당 수천 건 이상 찍는 워커 스레드가 생기면 lock-free MPSC 링 버퍼 +
//   전용 flush 스레드로 교체할 것 (인터페이스는 그대로 유지 가능).
// ---------------------------------------------------------------------------
#include <cstdint>

#if defined(__GNUC__) || defined(__clang__)
  #define ENGINE_PRINTF_FMT(fmtIdx, argIdx) __attribute__((format(printf, fmtIdx, argIdx)))
#else
  #define ENGINE_PRINTF_FMT(fmtIdx, argIdx)
#endif

namespace engine {

enum class LogLevel : std::uint8_t { Info = 0, Warning, Error, Fatal };

class Log {
public:
    /// filePath == nullptr 이면 콘솔 전용. 파일 열기에 실패해도 콘솔 로깅은 계속된다(false 반환).
    static bool Init(const char* filePath, LogLevel minLevel = LogLevel::Info);
    static void Shutdown();
    static void SetMinLevel(LogLevel level);

    // printf 스타일. 1KB 이하 메시지는 스택 버퍼만 사용(힙 할당 없음).
    static void Write(LogLevel level, const char* file, int line, const char* fmt, ...)
        ENGINE_PRINTF_FMT(4, 5);
};

} // namespace engine

#define ENGINE_LOG_INFO(...)  ::engine::Log::Write(::engine::LogLevel::Info,    __FILE__, __LINE__, __VA_ARGS__)
#define ENGINE_LOG_WARN(...)  ::engine::Log::Write(::engine::LogLevel::Warning, __FILE__, __LINE__, __VA_ARGS__)
#define ENGINE_LOG_ERROR(...) ::engine::Log::Write(::engine::LogLevel::Error,   __FILE__, __LINE__, __VA_ARGS__)
#define ENGINE_LOG_FATAL(...) ::engine::Log::Write(::engine::LogLevel::Fatal,   __FILE__, __LINE__, __VA_ARGS__)
