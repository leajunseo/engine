#include "Core/Window.hpp"

#include <SDL.h>

#include "Core/Events.hpp"
#include "Core/Log.hpp"

namespace engine {

Window::Window(EventBus& bus) : bus_(bus) {}
Window::~Window() { Destroy(); }

bool Window::Create(const WindowConfig& cfg) {
    if (window_) { ENGINE_LOG_WARN("Window::Create called twice"); return true; }

    if (SDL_InitSubSystem(SDL_INIT_VIDEO) != 0) {
        ENGINE_LOG_ERROR("SDL_InitSubSystem(VIDEO) failed: %s", SDL_GetError());
        return false;
    }
    videoInited_ = true;

    // --- OpenGL 컨텍스트 속성 (창 생성 '전'에 설정해야 한다) ----------------------
    SDL_GL_SetAttribute(SDL_GL_CONTEXT_MAJOR_VERSION, cfg.glMajor);
    SDL_GL_SetAttribute(SDL_GL_CONTEXT_MINOR_VERSION, cfg.glMinor);
    SDL_GL_SetAttribute(SDL_GL_CONTEXT_PROFILE_MASK,  SDL_GL_CONTEXT_PROFILE_CORE);
    int ctxFlags = 0;
#if defined(__APPLE__)
    ctxFlags |= SDL_GL_CONTEXT_FORWARD_COMPATIBLE_FLAG;   // macOS core profile 필수
#endif
#if defined(ENGINE_DEBUG)
    ctxFlags |= SDL_GL_CONTEXT_DEBUG_FLAG;                // GL 에러를 콜백으로 수신
#endif
    SDL_GL_SetAttribute(SDL_GL_CONTEXT_FLAGS, ctxFlags);
    SDL_GL_SetAttribute(SDL_GL_DOUBLEBUFFER, 1);
    SDL_GL_SetAttribute(SDL_GL_DEPTH_SIZE, 0);            // 2D: Z 정렬은 CPU 에서 -> 깊이 버퍼 불필요
    if (cfg.msaa > 0) {
        SDL_GL_SetAttribute(SDL_GL_MULTISAMPLEBUFFERS, 1);
        SDL_GL_SetAttribute(SDL_GL_MULTISAMPLESAMPLES, cfg.msaa);
    }

    Uint32 flags = SDL_WINDOW_OPENGL | SDL_WINDOW_ALLOW_HIGHDPI;
    if (cfg.resizable)  flags |= SDL_WINDOW_RESIZABLE;
    if (cfg.fullscreen) flags |= SDL_WINDOW_FULLSCREEN_DESKTOP;

    window_ = SDL_CreateWindow(cfg.title.c_str(),
                               SDL_WINDOWPOS_CENTERED, SDL_WINDOWPOS_CENTERED,
                               cfg.width, cfg.height, flags);
    if (!window_) {
        ENGINE_LOG_ERROR("SDL_CreateWindow failed: %s", SDL_GetError());
        Destroy();
        return false;
    }

    glContext_ = SDL_GL_CreateContext(window_);
    if (!glContext_) {
        ENGINE_LOG_ERROR("SDL_GL_CreateContext (GL %d.%d core) failed: %s",
                         cfg.glMajor, cfg.glMinor, SDL_GetError());
        Destroy();
        return false;
    }
    SDL_GL_MakeCurrent(window_, glContext_);
    SetVSync(cfg.vsync);

    int dw = 0, dh = 0;
    GetDrawableSize(dw, dh);
    ENGINE_LOG_INFO("Window created: %dx%d (drawable %dx%d)", cfg.width, cfg.height, dw, dh);
    return true;
}

void Window::Destroy() {
    if (glContext_)   { SDL_GL_DeleteContext(glContext_); glContext_ = nullptr; }
    if (window_)      { SDL_DestroyWindow(window_);       window_ = nullptr; }
    if (videoInited_) { SDL_QuitSubSystem(SDL_INIT_VIDEO); videoInited_ = false; }
}

void Window::PollEvents() {
    SDL_Event e;
    while (SDL_PollEvent(&e)) {
        switch (e.type) {
        case SDL_QUIT:
            bus_.Publish(WindowClosedEvent{});
            break;
        case SDL_WINDOWEVENT:
            if (e.window.event == SDL_WINDOWEVENT_SIZE_CHANGED) {
                int w = 0, h = 0;
                GetDrawableSize(w, h);
                bus_.Publish(WindowResizedEvent{w, h});
            } else if (e.window.event == SDL_WINDOWEVENT_FOCUS_GAINED) {
                bus_.Publish(WindowFocusEvent{true});
            } else if (e.window.event == SDL_WINDOWEVENT_FOCUS_LOST) {
                bus_.Publish(WindowFocusEvent{false});
            }
            break;
        case SDL_KEYDOWN:
        case SDL_KEYUP:
            bus_.Publish(KeyEvent{static_cast<int>(e.key.keysym.scancode),
                                  e.type == SDL_KEYDOWN, e.key.repeat != 0,
                                  KeyCodeFromScancode(static_cast<int>(e.key.keysym.scancode))});
            break;
        case SDL_MOUSEMOTION: {
            // SDL 마우스 좌표는 창(점) 단위 -> HiDPI 에서 드로어블(픽셀) 단위로 환산해 렌더러/카메라와 맞춘다
            int ww = 1, wh = 1, dw = 1, dh = 1;
            GetSize(ww, wh); GetDrawableSize(dw, dh);
            const float sx = ww > 0 ? static_cast<float>(dw) / static_cast<float>(ww) : 1.0f;
            const float sy = wh > 0 ? static_cast<float>(dh) / static_cast<float>(wh) : 1.0f;
            bus_.Publish(MouseMoveEvent{static_cast<float>(e.motion.x) * sx, static_cast<float>(e.motion.y) * sy});
            break;
        }
        case SDL_MOUSEBUTTONDOWN:
        case SDL_MOUSEBUTTONUP: {
            int ww = 1, wh = 1, dw = 1, dh = 1;
            GetSize(ww, wh); GetDrawableSize(dw, dh);
            const float sx = ww > 0 ? static_cast<float>(dw) / static_cast<float>(ww) : 1.0f;
            const float sy = wh > 0 ? static_cast<float>(dh) / static_cast<float>(wh) : 1.0f;
            bus_.Publish(MouseButtonEvent{static_cast<int>(e.button.button), e.type == SDL_MOUSEBUTTONDOWN,
                                          static_cast<float>(e.button.x) * sx, static_cast<float>(e.button.y) * sy});
            break;
        }
        case SDL_MOUSEWHEEL:
            bus_.Publish(MouseWheelEvent{static_cast<float>(e.wheel.y)});
            break;
        default: break;
        }
    }
}

void Window::SwapBuffers() { SDL_GL_SwapWindow(window_); }
void Window::SetTitle(const char* title) { if (window_) SDL_SetWindowTitle(window_, title); }

void Window::SetVSync(bool enabled) {
    if (SDL_GL_SetSwapInterval(enabled ? 1 : 0) != 0)
        ENGINE_LOG_WARN("SetSwapInterval failed: %s", SDL_GetError());
}

void Window::GetSize(int& w, int& h) const { SDL_GetWindowSize(window_, &w, &h); }
void Window::GetDrawableSize(int& w, int& h) const { SDL_GL_GetDrawableSize(window_, &w, &h); }

} // namespace engine
