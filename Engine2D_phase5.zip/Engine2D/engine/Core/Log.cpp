#include "Core/Log.hpp"

#include <atomic>
#include <chrono>
#include <cstdarg>
#include <cstdio>
#include <ctime>
#include <mutex>
#include <vector>

namespace engine {
namespace {

struct LogState {
    std::mutex             mutex;
    std::FILE*             file     = nullptr;
    std::atomic<LogLevel>  minLevel{LogLevel::Info};
};

LogState& State() {
    static LogState s;   // 첫 호출 시 스레드 세이프하게 초기화 (C++11 magic statics)
    return s;
}

const char* LevelName(LogLevel l) {
    switch (l) {
        case LogLevel::Info:    return "Info";
        case LogLevel::Warning: return "Warning";
        case LogLevel::Error:   return "Error";
        case LogLevel::Fatal:   return "Fatal";
    }
    return "?";
}

// main 스레드 = T0, 이후 로그를 처음 찍는 순서대로 T1, T2 ...
unsigned ThreadIndex() {
    static std::atomic<unsigned> counter{0};
    thread_local const unsigned id = counter.fetch_add(1);
    return id;
}

const char* Basename(const char* path) {
    const char* base = path;
    for (const char* p = path; *p; ++p)
        if (*p == '/' || *p == '\\') base = p + 1;
    return base;
}

} // namespace

bool Log::Init(const char* filePath, LogLevel minLevel) {
    LogState& s = State();
    std::lock_guard<std::mutex> lock(s.mutex);
    s.minLevel.store(minLevel);
    if (s.file) { std::fclose(s.file); s.file = nullptr; }
    if (!filePath) return true;

    s.file = std::fopen(filePath, "w");
    if (!s.file) {
        std::fprintf(stderr, "[Log] cannot open '%s' - console only\n", filePath);
        return false;
    }
    return true;
}

void Log::Shutdown() {
    LogState& s = State();
    std::lock_guard<std::mutex> lock(s.mutex);
    if (s.file) { std::fclose(s.file); s.file = nullptr; }
}

void Log::SetMinLevel(LogLevel level) { State().minLevel.store(level); }

void Log::Write(LogLevel level, const char* file, int line, const char* fmt, ...) {
    LogState& s = State();
    if (static_cast<int>(level) < static_cast<int>(s.minLevel.load())) return;

    // --- 메시지 포맷 (락 밖에서 수행: 임계 구역을 출력 I/O 만으로 최소화) ------------
    char              stackBuf[1024];
    std::vector<char> heapBuf;            // 1KB 초과 시에만 할당
    const char*       msg = stackBuf;

    va_list args, argsCopy;
    va_start(args, fmt);
    va_copy(argsCopy, args);
    const int n = std::vsnprintf(stackBuf, sizeof(stackBuf), fmt, args);
    va_end(args);
    if (n < 0) {
        msg = "(log format error)";
    } else if (static_cast<size_t>(n) >= sizeof(stackBuf)) {
        heapBuf.resize(static_cast<size_t>(n) + 1);
        std::vsnprintf(heapBuf.data(), heapBuf.size(), fmt, argsCopy);
        msg = heapBuf.data();
    }
    va_end(argsCopy);

    // --- 타임스탬프 ---------------------------------------------------------------
    const auto now = std::chrono::system_clock::now();
    const std::time_t t = std::chrono::system_clock::to_time_t(now);
    const int ms = static_cast<int>(
        std::chrono::duration_cast<std::chrono::milliseconds>(now.time_since_epoch()).count() % 1000);
    std::tm tm{};
#if defined(_WIN32)
    localtime_s(&tm, &t);
#else
    localtime_r(&t, &tm);
#endif
    char ts[16];
    std::snprintf(ts, sizeof(ts), "%02d:%02d:%02d.%03d", tm.tm_hour, tm.tm_min, tm.tm_sec, ms);

    const bool withLocation = level != LogLevel::Info;
    const unsigned tid = ThreadIndex();

    auto emit = [&](std::FILE* out) {
        if (withLocation)
            std::fprintf(out, "[%s][%s][T%u] %s  (%s:%d)\n", ts, LevelName(level), tid, msg, Basename(file), line);
        else
            std::fprintf(out, "[%s][%s][T%u] %s\n", ts, LevelName(level), tid, msg);
    };

    std::lock_guard<std::mutex> lock(s.mutex);
    std::FILE* console = (level >= LogLevel::Error) ? stderr : stdout;
    emit(console);
    if (s.file) emit(s.file);

    // Error 이상은 크래시 직전일 수 있으므로 즉시 flush. 그 외는 OS 버퍼링에 맡김.
    if (level >= LogLevel::Error) {
        std::fflush(console);
        if (s.file) std::fflush(s.file);
    }
}

} // namespace engine
