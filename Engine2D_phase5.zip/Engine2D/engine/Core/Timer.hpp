#pragma once
// 고정밀 시간 유틸. 모든 내부 시간은 int64 나노초로 다룬다.
//  - double 초 누적은 장시간 실행 시 정밀도가 깎이고(시뮬레이션 비결정성),
//    정수 누적은 오차가 없다.
#include <chrono>
#include <cstdint>

namespace engine {

class Timer {
public:
    using Clock = std::chrono::steady_clock;
    static_assert(Clock::is_steady, "game loop requires a monotonic clock");

    static std::int64_t NowNs() {
        return std::chrono::duration_cast<std::chrono::nanoseconds>(
                   Clock::now().time_since_epoch()).count();
    }
    static constexpr double NsToSec(std::int64_t ns) { return static_cast<double>(ns) * 1e-9; }
};

/// 1초 윈도우로 초당 횟수(FPS/UPS)를 측정한다. Tick() 은 매 이벤트마다, Sample() 은 매 프레임 호출.
class RateCounter {
public:
    void Tick() { ++count_; }

    /// 윈도우가 끝났으면 rate 를 갱신하고 true 반환.
    bool Sample(std::int64_t nowNs, std::int64_t windowNs = 1'000'000'000) {
        if (windowStart_ == 0) { windowStart_ = nowNs; return false; }
        const std::int64_t elapsed = nowNs - windowStart_;
        if (elapsed < windowNs) return false;
        rate_        = static_cast<double>(count_) * 1e9 / static_cast<double>(elapsed);
        count_       = 0;
        windowStart_ = nowNs;
        return true;
    }
    double Rate() const { return rate_; }

private:
    std::int64_t  windowStart_ = 0;
    std::uint32_t count_       = 0;
    double        rate_        = 0.0;
};

} // namespace engine
