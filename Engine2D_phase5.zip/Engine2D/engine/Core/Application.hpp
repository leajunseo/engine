#pragma once
#include <atomic>
#include <cstdint>
#include <string>

#include "Assets/AssetManager.hpp"
#include "Audio/AudioManager.hpp"
#include "Core/EventBus.hpp"
#include "Core/Window.hpp"
#include "Input/InputManager.hpp"
#include "Renderer/Renderer.hpp"

namespace engine {

class Application;

struct ApplicationConfig {
    WindowConfig window;
    int          fixedHz            = 60;      // 물리/로직 고정 업데이트 주파수
    int          maxUpdatesPerFrame = 8;       // 한 프레임에 허용하는 최대 고정 스텝 (spiral of death 방지)
    double       maxFrameSeconds    = 0.25;    // 프레임 시간 클램프 (브레이크포인트/창 드래그 후 폭주 방지)
    int          targetFps          = 0;       // 0 = 무제한. vsync 가 꺼져 있을 때만 적용
    bool         showStatsInTitle   = true;    // 창 제목에 FPS/UPS 표시
    std::string  logFile            = "engine.log";   // 빈 문자열이면 콘솔 전용
    bool         enableAudio        = true;    // false 면 오디오 장치를 열지 않는다 (Mixer 는 존재, 무음)
    AudioConfig  audio;
    std::string  assetRoot;                    // AssetManager 상대 경로 기준 폴더 (빈 문자열 = 현재 작업 폴더)
};

/// 게임(사용자) 코드가 구현하는 인터페이스. 엔진은 이 인터페이스만 알고 게임은 Application 만 안다.
class IGame {
public:
    virtual ~IGame() = default;

    virtual bool OnInit(Application& app)          { (void)app; return true; }
    /// 고정 간격(1/fixedHz 초)으로 호출. 물리·게임 로직은 여기서.
    virtual void OnFixedUpdate(double fixedDt) = 0;
    /// 렌더 프레임마다 1회, 고정 업데이트 이후. 카메라 스무딩·UI 애니메이션 등 가변 dt 작업용.
    virtual void OnVariableUpdate(double frameDt)  { (void)frameDt; }
    /// alpha ∈ [0,1): 직전 고정 틱 상태와 현재 틱 상태 사이의 보간 비율.
    ///   renderPos = lerp(prevPos, currPos, alpha)
    virtual void OnRender(Renderer& renderer, double alpha) = 0;
    virtual void OnShutdown()                      {}
    /// 창 제목 끝에 덧붙일 상태 문자열 (예: 스프라이트 수). 1초에 한 번 호출.
    virtual std::string StatusText() const         { return {}; }
};

class Application {
public:
    explicit Application(ApplicationConfig config);
    ~Application();
    Application(const Application&)            = delete;
    Application& operator=(const Application&) = delete;

    /// 초기화 -> 메인 루프 -> 종료. 프로세스 종료 코드를 반환한다.
    int Run(IGame& game);
    void RequestQuit() { running_.store(false); }     // 스레드 세이프

    EventBus& Events()       { return events_; }
    Window&   GetWindow()    { return window_; }
    Renderer& GetRenderer()  { return renderer_; }
    InputManager& Input()    { return input_; }       // 틱/프레임 경계는 Application 이 관리 (EndTick/EndFrame)
    AudioManager& Audio()    { return audio_; }
    AssetManager& Assets()   { return assets_; }      // Shutdown 시 GL 컨텍스트보다 먼저 Clear 된다

    double        FixedDelta() const     { return fixedDt_; }
    std::uint64_t FixedTickCount() const { return tickCount_; }

private:
    bool Initialize();
    void Shutdown();
    void MainLoop(IGame& game);
    void LimitFrameRate(std::int64_t frameStartNs) const;

    ApplicationConfig config_;
    EventBus          events_;       // 선언 순서 = 생성 순서 (파괴는 역순)
    InputManager      input_;        // events_ 뒤 (생성자에서 구독), window_ 보다 먼저 파괴돼도 안전
    Window            window_;
    Renderer          renderer_;
    AssetManager      assets_;       // renderer_ 뒤에 선언 -> 먼저 파괴
    AudioManager      audio_;        // 마지막 선언 -> 가장 먼저 파괴 (장치 콜백 정지)
    Subscription      closeSub_;
    Subscription      resizeSub_;

    std::atomic<bool> running_{false};
    std::int64_t      fixedStepNs_ = 0;
    std::int64_t      maxFrameNs_  = 0;
    double            fixedDt_     = 0.0;
    std::uint64_t     tickCount_   = 0;
    bool              logOpen_     = false;
};

} // namespace engine
