#include "Core/Application.hpp"

#include <algorithm>
#include <chrono>
#include <cstdio>
#include <cstdlib>
#include <thread>

#include <SDL.h>

#include "Audio/Wav.hpp"
#include "Core/Events.hpp"
#include "Core/Log.hpp"
#include "Core/Timer.hpp"

namespace engine {
namespace {
constexpr std::int64_t kNsPerSec = 1'000'000'000;
}

Application::Application(ApplicationConfig config)
    : config_(std::move(config)), input_(events_), window_(events_), audio_(config_.audio) {
    fixedStepNs_ = kNsPerSec / std::max(1, config_.fixedHz);   // 정수 나노초 스텝 -> 누적 오차 없음
    fixedDt_     = Timer::NsToSec(fixedStepNs_);
    maxFrameNs_  = static_cast<std::int64_t>(config_.maxFrameSeconds * 1e9);
    assets_.SetRoot(config_.assetRoot);
    assets_.RegisterLoader<AudioClip>([](const std::string& path) -> std::unique_ptr<AudioClip> {   // WAV 효과음 (핫 리로드 가능)
        auto clip = std::make_unique<AudioClip>();
        if (!LoadWavFile(path, *clip)) return nullptr;
        return clip;
    });
}

Application::~Application() { Shutdown(); }

bool Application::Initialize() {
    logOpen_ = true;
    Log::Init(config_.logFile.empty() ? nullptr : config_.logFile.c_str());
    ENGINE_LOG_INFO("Engine2D starting (fixed step %.3f ms, %d Hz)", fixedDt_ * 1000.0, config_.fixedHz);

    if (!window_.Create(config_.window)) return false;
    if (!renderer_.Init(window_))        return false;
    if (config_.enableAudio) audio_.Init();      // 실패해도 무음 모드로 계속 (로그에 경고)

    // 시스템 간 직접 참조 대신 이벤트 버스로 연결
    closeSub_  = events_.Subscribe<WindowClosedEvent>(
        [this](const WindowClosedEvent&) { RequestQuit(); });
    resizeSub_ = events_.Subscribe<WindowResizedEvent>(
        [this](const WindowResizedEvent& e) { renderer_.OnResize(e.width, e.height); });
    return true;
}

void Application::Shutdown() {
    closeSub_.Unsubscribe();
    resizeSub_.Unsubscribe();
    audio_.Shutdown();             // 장치 콜백을 먼저 멈춘다
    assets_.Clear();               // 텍스처 등 GL 자원은 컨텍스트가 살아있을 때 해제
    renderer_.Shutdown();
    window_.Destroy();
    if (logOpen_) {
        ENGINE_LOG_INFO("Engine2D shut down (%llu fixed ticks)",
                        static_cast<unsigned long long>(tickCount_));
        Log::Shutdown();
        logOpen_ = false;
    }
}

int Application::Run(IGame& game) {
    running_.store(true);
    if (!Initialize()) {
        ENGINE_LOG_FATAL("Engine initialization failed");
        // 콘솔이 곧 닫히는 환경(VS 디버깅)에서도 원인을 볼 수 있도록 메시지 박스 표시
        SDL_ShowSimpleMessageBox(SDL_MESSAGEBOX_ERROR, "Engine2D",
            "Initialization failed (OpenGL 3.3 core needed). See engine.log.", nullptr);
        return EXIT_FAILURE;
    }
    if (!game.OnInit(*this)) {
        ENGINE_LOG_FATAL("IGame::OnInit failed");
        return EXIT_FAILURE;
    }
    MainLoop(game);
    game.OnShutdown();
    return EXIT_SUCCESS;
}

// ---------------------------------------------------------------------------
// "Fix Your Timestep" 루프
//
//   frame N:  |--- frameNs ---|
//   acc    += frameNs
//   while (acc >= step) { FixedUpdate; acc -= step; }      <- 로직은 항상 일정한 dt
//   alpha   = acc / step                                   <- 남은 비율로 렌더 보간
//
// [Bottleneck] OnFixedUpdate 가 step(16.6ms) 보다 오래 걸리면 acc 가 계속 쌓여
//   한 프레임에 여러 번 실행 -> 더 느려지는 'spiral of death'. 두 겹으로 방어한다:
//   (1) frameNs 를 maxFrameNs_ 로 클램프  (2) 프레임당 스텝 수를 maxUpdatesPerFrame 로 제한하고
//   초과분은 버린다(시뮬레이션이 실시간보다 느려지는 쪽을 택함).
// ---------------------------------------------------------------------------
void Application::MainLoop(IGame& game) {
    RateCounter fps, ups;
    std::int64_t prev = Timer::NowNs();
    std::int64_t acc = 0;
    std::int64_t lastWarnNs = 0;

    while (running_.load()) {
        const std::int64_t frameStart = Timer::NowNs();
        const std::int64_t frameNs = std::min(frameStart - prev, maxFrameNs_);
        prev = frameStart;
        acc += frameNs;

        window_.PollEvents();          // 플랫폼 이벤트 -> EventBus (동기 Publish)
        events_.DispatchQueued();      // 워커 스레드가 Enqueue 한 이벤트
        if (!running_.load()) break;

        int steps = 0;
        while (acc >= fixedStepNs_ && steps < config_.maxUpdatesPerFrame) {
            game.OnFixedUpdate(fixedDt_);
            input_.EndTick();          // 틱 단위 입력 엣지 소비
            acc -= fixedStepNs_;
            ++steps; ++tickCount_;
            ups.Tick();
        }
        if (acc >= fixedStepNs_) {     // 상한에 걸림 -> 밀린 시간 폐기
            acc %= fixedStepNs_;
            if (frameStart - lastWarnNs > kNsPerSec) {        // 로그 스팸 방지: 초당 1회
                ENGINE_LOG_WARN("Fixed update can't keep up; dropping accumulated time "
                                "(maxUpdatesPerFrame=%d)", config_.maxUpdatesPerFrame);
                lastWarnNs = frameStart;
            }
        }

        game.OnVariableUpdate(Timer::NsToSec(frameNs));

        const double alpha = static_cast<double>(acc) / static_cast<double>(fixedStepNs_);
        renderer_.BeginFrame();
        game.OnRender(renderer_, alpha);
        renderer_.EndFrame();
        window_.SwapBuffers();         // [Bottleneck] vsync 켜짐 -> 여기서 블로킹되어 프레임 페이싱
        input_.EndFrame();             // 프레임 단위 입력 엣지/마우스 이동량 초기화
        audio_.Update();               // 끝난 음악 스트림 정리

        fps.Tick();
        if (config_.showStatsInTitle) {
            const std::int64_t now = Timer::NowNs();
            const bool f = fps.Sample(now);
            const bool u = ups.Sample(now);
            if (f && u) {
                const RenderStats& rs = renderer_.Stats();
                const std::string status = game.StatusText();
                char title[320];
                std::snprintf(title, sizeof(title), "%s | %.0f FPS | %.0f UPS | %.2f ms | %u draws, %u quads%s%s",
                              config_.window.title.c_str(), fps.Rate(), ups.Rate(),
                              fps.Rate() > 0.0 ? 1000.0 / fps.Rate() : 0.0,
                              rs.drawCalls, rs.quads, status.empty() ? "" : " | ", status.c_str());
                window_.SetTitle(title);
            }
        }
        LimitFrameRate(frameStart);
    }
}

void Application::LimitFrameRate(std::int64_t frameStartNs) const {
    if (config_.targetFps <= 0 || config_.window.vsync) return;
    const std::int64_t deadline = frameStartNs + kNsPerSec / config_.targetFps;
    for (;;) {
        const std::int64_t remain = deadline - Timer::NowNs();
        if (remain <= 0) break;
        // 하이브리드 대기: OS 스케줄러 지터(~1-2ms)를 감안해 대부분은 sleep, 마지막 구간은 spin.
        // [Bottleneck] 순수 sleep_for 는 정밀도가 낮고 순수 spin 은 CPU 코어를 100% 소모한다.
        if (remain > 2'000'000) std::this_thread::sleep_for(std::chrono::nanoseconds(remain - 1'500'000));
        else                    std::this_thread::yield();
    }
}

} // namespace engine
