#pragma once
// ---------------------------------------------------------------------------
// Scene = Registry(ECS) + 변환 계층(SceneGraph).
//   모든 Scene 엔티티는 Name/Transform/Node 를 가진다 (Scene::Create 가 붙임).
//
// 한 고정 틱의 권장 순서
//   scene.BeginTick();            // 직전 월드 상태 스냅샷 (렌더 보간용)
//   ... 로직 / 물리 ...           // Transform 로컬 값 수정
//   scene.UpdateTransforms();     // 로컬 -> 월드 행렬 (부모 먼저)
//   scene.FlushDestroyed();       // DestroyLater 로 예약된 엔티티 정리
//
// 이벤트 (SetEventBus 로 연결했을 때)
//   EntityCreatedEvent   : 컴포넌트 기본 세트가 붙은 직후
//   EntityDestroyedEvent : 컴포넌트가 아직 살아있을 때 (자식 -> 부모 순). 핸들러에서 정리 작업(물리 바디 삭제 등)을 한다.
//
// [Bottleneck] UpdateTransforms 는 매번 모든 엔티티를 재계산한다 (O(n), 행렬 곱 1회/엔티티).
//   수만 개 이상이 되면 dirty 플래그 + 깊이 순 정렬 / 정적 서브트리 스킵으로 교체.
// ---------------------------------------------------------------------------
#include <cstddef>
#include <string>
#include <utility>
#include <vector>

#include "Core/EventBus.hpp"
#include "Scene/Components.hpp"
#include "Scene/ECS.hpp"

namespace engine {

struct EntityCreatedEvent   { Entity entity; };
struct EntityDestroyedEvent { Entity entity; };

class Scene {
public:
    Scene() = default;
    Scene(const Scene&)            = delete;
    Scene& operator=(const Scene&) = delete;

    void SetEventBus(EventBus* bus) { bus_ = bus; }

    // ---- 엔티티 ----
    /// parent 가 유효하면 그 자식으로 붙는다. position 은 부모 기준 로컬 위치.
    Entity Create(const std::string& name = {}, Vec2 position = {0.0f, 0.0f}, Entity parent = kNullEntity);
    /// 즉시 삭제 (하위 트리 전체). 이미 죽은 엔티티면 false.
    bool Destroy(Entity e);
    /// 안전한 삭제 예약 (순회/이벤트 핸들러 안에서 사용). FlushDestroyed 에서 실제 삭제하고 개수를 반환.
    void DestroyLater(Entity e) { if (IsAlive(e)) pending_.push_back(e); }
    std::size_t FlushDestroyed();
    bool IsAlive(Entity e) const { return reg_.IsAlive(e); }
    std::size_t Count() const { return reg_.AliveCount(); }
    void Clear();
    Entity Find(const std::string& name) const;     // 이름이 같은 첫 엔티티 (선형 탐색, 에디터/초기화용)

    // ---- 컴포넌트 (Registry 로 위임) ----
    Registry&       Reg()       { return reg_; }
    const Registry& Reg() const { return reg_; }
    template <class T, class... A> T& Add(Entity e, A&&... a) { return reg_.Add<T>(e, std::forward<A>(a)...); }
    template <class T> void Remove(Entity e)                  { reg_.Remove<T>(e); }
    template <class T> bool Has(Entity e) const               { return reg_.Has<T>(e); }
    template <class T> T*       TryGet(Entity e)              { return reg_.TryGet<T>(e); }
    template <class T> const T* TryGet(Entity e) const        { return reg_.TryGet<T>(e); }
    template <class T> T&       Get(Entity e)                 { return reg_.Get<T>(e); }
    template <class T, class... Ts, class F> void Each(F&& f) { reg_.Each<T, Ts...>(std::forward<F>(f)); }

    // ---- 계층 ----
    /// parent 가 kNullEntity 면 루트로. 순환(자기 자신/자손을 부모로)이면 false.
    /// keepWorld=true 면 월드 위치/회전/스케일을 유지하도록 로컬 값을 역산한다 (직전 UpdateTransforms 결과 기준, 전단은 근사).
    bool   SetParent(Entity child, Entity parent, bool keepWorld = false);
    Entity Parent(Entity e) const;
    Entity FirstChild(Entity e) const;
    Entity NextSibling(Entity e) const;
    std::size_t ChildCount(Entity e) const;
    bool   IsAncestor(Entity ancestor, Entity e) const;       // ancestor 가 e 의 (직/간접) 조상인가
    std::vector<Entity> Children(Entity e) const;
    /// f(Entity child). 순회 중 f 가 child 를 삭제/이동해도 안전 (다음 형제를 미리 읽음).
    template <class F> void ForEachChild(Entity e, F&& f) const {
        const Node* n = reg_.TryGet<Node>(e);
        if (!n) return;
        Entity c = n->firstChild;
        while (c.Valid()) {
            const Node* cn = reg_.TryGet<Node>(c);
            if (!cn) break;
            const Entity next = cn->next;
            f(c);
            c = next;
        }
    }

    // ---- 변환 ----
    void BeginTick();
    void UpdateTransforms();
    void ResetInterpolation(Entity e) { if (Transform* t = reg_.TryGet<Transform>(e)) t->hasPrev = false; }

private:
    void Unlink(Entity e);
    void Link(Entity child, Entity parent);
    void CollectSubtreePostOrder(Entity root, std::vector<Entity>& out) const;

    Registry reg_;
    EventBus* bus_ = nullptr;
    std::vector<Entity> pending_;
    std::vector<Entity> scratchRoots_, scratchStack_;
};

} // namespace engine
