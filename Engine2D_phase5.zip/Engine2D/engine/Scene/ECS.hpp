#pragma once
// ---------------------------------------------------------------------------
// 최소 ECS: 세대(generation) 붙은 Entity + sparse-set 컴포넌트 풀.
//
//   Registry reg;
//   Entity e = reg.Create();
//   reg.Add<Position>(e, {1, 2});
//   reg.Each<Position, Velocity>([](Entity e, Position& p, Velocity& v) { ... });
//
// 설계
//  * Entity = {index, generation}. Destroy 하면 세대가 올라가 옛 핸들은 자동 무효 (BodyId 와 같은 방식).
//  * 컴포넌트 풀 = sparse set: dense 배열(연속 메모리, 순회 빠름) + sparse[entityIndex] -> dense 위치.
//    삭제는 swap-and-pop (O(1), 순서 비보존).
//  * Each<Ts...> 는 가장 작은 풀을 기준으로 순회하고 나머지 풀에서 O(1) 조회 -> O(min(|풀|)).
//  * 컴포넌트 타입 ID 는 EventBus 와 같이 템플릿 static 으로 부여 (RTTI 없음).
//
// 주의 (구조 변경)
//  * Each 순회 중 Add/Remove/Destroy 하면 dense 배열이 바뀌어 순회가 깨질 수 있다.
//    순회 중에는 DestroyLater(e) 를 쓰고 순회가 끝난 뒤 FlushDestroyed() 를 호출할 것 (Scene 이 이 흐름을 제공).
//  * Get<T>() 가 돌려준 포인터/참조는 같은 타입에 Add/Remove 가 일어나면 무효가 된다 (벡터 재할당 / swap-pop).
// ---------------------------------------------------------------------------
#include <cstddef>
#include <cstdint>
#include <functional>
#include <memory>
#include <tuple>
#include <type_traits>
#include <utility>
#include <vector>

namespace engine {

struct Entity {
    std::uint32_t index = 0xFFFFFFFFu;
    std::uint32_t generation = 0;
    bool Valid() const { return index != 0xFFFFFFFFu; }          // '핸들이 비어있지 않다' (살아있는지는 Registry::IsAlive)
    bool operator==(const Entity& o) const { return index == o.index && generation == o.generation; }
    bool operator!=(const Entity& o) const { return !(*this == o); }
    std::uint64_t Pack() const { return (static_cast<std::uint64_t>(generation) << 32) | index; }
};
inline constexpr Entity kNullEntity{};

namespace detail {

inline std::size_t NextComponentTypeId() {
    static std::size_t counter = 0;
    return counter++;
}
template <class T>
std::size_t ComponentTypeId() {
    static const std::size_t id = NextComponentTypeId();
    return id;
}

struct IPool {
    virtual ~IPool() = default;
    virtual void Remove(std::uint32_t entityIndex) = 0;      // 없으면 무시
    virtual bool Has(std::uint32_t entityIndex) const = 0;
    virtual std::size_t Size() const = 0;
};

template <class T>
class Pool final : public IPool {
public:
    static constexpr std::uint32_t kNone = 0xFFFFFFFFu;

    template <class... Args>
    T& Emplace(std::uint32_t entityIndex, Args&&... args) {
        if (entityIndex >= sparse_.size()) sparse_.resize(static_cast<std::size_t>(entityIndex) + 1, kNone);
        std::uint32_t& slot = sparse_[entityIndex];
        if (slot != kNone) {                                  // 이미 있음 -> 덮어쓰기
            dense_[slot] = T{std::forward<Args>(args)...};
            return dense_[slot];
        }
        slot = static_cast<std::uint32_t>(dense_.size());
        entities_.push_back(entityIndex);
        dense_.emplace_back(std::forward<Args>(args)...);
        return dense_.back();
    }
    T* Find(std::uint32_t entityIndex) {
        if (entityIndex >= sparse_.size() || sparse_[entityIndex] == kNone) return nullptr;
        return &dense_[sparse_[entityIndex]];
    }
    const T* Find(std::uint32_t entityIndex) const {
        if (entityIndex >= sparse_.size() || sparse_[entityIndex] == kNone) return nullptr;
        return &dense_[sparse_[entityIndex]];
    }
    void Remove(std::uint32_t entityIndex) override {
        if (entityIndex >= sparse_.size() || sparse_[entityIndex] == kNone) return;
        const std::uint32_t pos = sparse_[entityIndex];
        const std::uint32_t last = static_cast<std::uint32_t>(dense_.size() - 1);
        if (pos != last) {                                    // 마지막 원소를 빈 자리로 (swap-and-pop)
            dense_[pos] = std::move(dense_[last]);
            entities_[pos] = entities_[last];
            sparse_[entities_[pos]] = pos;
        }
        dense_.pop_back();
        entities_.pop_back();
        sparse_[entityIndex] = kNone;
    }
    bool Has(std::uint32_t entityIndex) const override { return Find(entityIndex) != nullptr; }
    std::size_t Size() const override { return dense_.size(); }

    const std::vector<std::uint32_t>& EntityIndices() const { return entities_; }
    T& DenseAt(std::size_t i) { return dense_[i]; }

private:
    std::vector<std::uint32_t> sparse_;     // entityIndex -> dense 위치
    std::vector<std::uint32_t> entities_;   // dense 위치 -> entityIndex
    std::vector<T>             dense_;
};

} // namespace detail

class Registry {
public:
    Registry() = default;
    Registry(const Registry&)            = delete;
    Registry& operator=(const Registry&) = delete;

    // ---- 엔티티 수명 ----
    Entity Create() {
        std::uint32_t idx;
        if (!freeList_.empty()) { idx = freeList_.back(); freeList_.pop_back(); }
        else { idx = static_cast<std::uint32_t>(generations_.size()); generations_.push_back(0); alive_.push_back(0); }
        alive_[idx] = 1;
        ++aliveCount_;
        return Entity{idx, generations_[idx]};
    }
    bool IsAlive(Entity e) const {
        return e.index < generations_.size() && alive_[e.index] && generations_[e.index] == e.generation;
    }
    /// 즉시 삭제: 모든 컴포넌트 제거 + 세대 증가. 이미 죽은/무효 핸들이면 false.
    bool Destroy(Entity e) {
        if (!IsAlive(e)) return false;
        for (auto& p : pools_) if (p) p->Remove(e.index);
        alive_[e.index] = 0;
        ++generations_[e.index];
        freeList_.push_back(e.index);
        --aliveCount_;
        return true;
    }
    /// 순회 중에도 안전한 삭제 예약. FlushDestroyed() 에서 실제 삭제 (중복 예약 OK).
    void DestroyLater(Entity e) { if (IsAlive(e)) pending_.push_back(e); }
    /// 예약된 삭제를 실행하고 실제로 삭제된 개수를 반환.
    std::size_t FlushDestroyed() {
        std::size_t n = 0;
        for (std::size_t i = 0; i < pending_.size(); ++i) if (Destroy(pending_[i])) ++n;   // Destroy 훅이 예약을 추가해도 안전하도록 인덱스 순회
        pending_.clear();
        return n;
    }
    std::size_t AliveCount() const { return aliveCount_; }
    bool HasPendingDestroy() const { return !pending_.empty(); }

    /// 살아있는 모든 엔티티 (생성 순서가 아닌 index 순). 순회 중 구조 변경 금지.
    template <class F> void ForEachEntity(F&& f) const {       // f(Entity)
        for (std::uint32_t i = 0; i < alive_.size(); ++i) if (alive_[i]) f(Entity{i, generations_[i]});
    }

    // ---- 컴포넌트 ----
    template <class T, class... Args>
    T& Add(Entity e, Args&&... args) {
        return GetOrCreatePool<T>().Emplace(e.index, std::forward<Args>(args)...);
    }
    template <class T> void Remove(Entity e) { if (IsAlive(e)) if (auto* p = FindPool<T>()) p->Remove(e.index); }
    template <class T> bool Has(Entity e) const {
        const auto* p = FindPool<T>();
        return p && IsAlive(e) && p->Has(e.index);
    }
    template <class T> T* TryGet(Entity e) {
        auto* p = FindPool<T>();
        return (p && IsAlive(e)) ? p->Find(e.index) : nullptr;
    }
    template <class T> const T* TryGet(Entity e) const {
        const auto* p = FindPool<T>();
        return (p && IsAlive(e)) ? p->Find(e.index) : nullptr;
    }
    /// 없으면 nullptr 대신 정의되지 않은 동작 -> Has 로 확인했을 때만 사용. 확실치 않으면 TryGet.
    template <class T> T& Get(Entity e) { return *TryGet<T>(e); }
    template <class T> const T& Get(Entity e) const { return *TryGet<T>(e); }
    template <class T> std::size_t Count() const { const auto* p = FindPool<T>(); return p ? p->Size() : 0; }

    // ---- 순회 ----
    /// 지정한 컴포넌트를 모두 가진 엔티티마다 f(Entity, Ts&...) 호출. 순회 중 구조 변경 금지.
    template <class... Ts, class F>
    void Each(F&& f) {
        static_assert(sizeof...(Ts) > 0, "Each needs at least one component type");
        auto pools = std::make_tuple(FindPool<Ts>()...);
        if (!AllNonNull(pools, std::index_sequence_for<Ts...>{})) return;
        // 가장 작은 풀의 엔티티 목록을 기준으로 순회
        const std::vector<std::uint32_t>* driver = nullptr;
        std::size_t best = ~std::size_t{0};
        ((std::get<detail::Pool<Ts>*>(pools)->Size() < best
              ? (best = std::get<detail::Pool<Ts>*>(pools)->Size(), driver = &std::get<detail::Pool<Ts>*>(pools)->EntityIndices(), 0) : 0), ...);
        const std::vector<std::uint32_t>& list = *driver;
        for (std::size_t i = 0; i < list.size(); ++i) {
            const std::uint32_t idx = list[i];
            auto comps = std::make_tuple(std::get<detail::Pool<Ts>*>(pools)->Find(idx)...);
            if (!AllNonNull(comps, std::index_sequence_for<Ts...>{})) continue;
            f(Entity{idx, generations_[idx]}, *std::get<Ts*>(comps)...);
        }
    }

    void Clear() {
        pools_.clear();
        generations_.clear(); alive_.clear(); freeList_.clear(); pending_.clear();
        aliveCount_ = 0;
    }

private:
    template <class Tup, std::size_t... I>
    static bool AllNonNull(const Tup& t, std::index_sequence<I...>) { return ((std::get<I>(t) != nullptr) && ...); }

    template <class T> detail::Pool<T>* FindPool() const {
        const std::size_t id = detail::ComponentTypeId<T>();
        if (id >= pools_.size() || !pools_[id]) return nullptr;
        return static_cast<detail::Pool<T>*>(pools_[id].get());
    }
    template <class T> detail::Pool<T>& GetOrCreatePool() {
        const std::size_t id = detail::ComponentTypeId<T>();
        if (id >= pools_.size()) pools_.resize(id + 1);
        if (!pools_[id]) pools_[id] = std::make_unique<detail::Pool<T>>();
        return static_cast<detail::Pool<T>&>(*pools_[id]);
    }

    std::vector<std::unique_ptr<detail::IPool>> pools_;
    std::vector<std::uint32_t>                  generations_;
    std::vector<std::uint8_t>                   alive_;
    std::vector<std::uint32_t>                  freeList_;
    std::vector<Entity>                         pending_;
    std::size_t                                 aliveCount_ = 0;
};

} // namespace engine
