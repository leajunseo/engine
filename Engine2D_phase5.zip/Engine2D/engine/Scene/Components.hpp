#pragma once
// Scene 모듈이 기본 제공하는 컴포넌트. 다른 모듈(렌더러/물리)을 참조하는 컴포넌트는 Systems/ 에 둔다.
#include <string>

#include "Math/Affine2D.hpp"
#include "Math/Math.hpp"
#include "Scene/ECS.hpp"

namespace engine {

struct Name { std::string value; };

/// 로컬 TRS(부모 기준) + 월드 행렬(Scene::UpdateTransforms 가 계산) + 렌더 보간용 직전 틱 월드 상태.
/// 로컬 값은 직접 수정해도 된다 (다음 UpdateTransforms 에서 반영).
struct Transform {
    Vec2  position{0.0f, 0.0f};
    float rotation = 0.0f;                 // 라디안, 반시계
    Vec2  scale{1.0f, 1.0f};

    Affine2D world;                        // 읽기 전용 (UpdateTransforms 결과)
    Vec2  prevWorldPosition{0.0f, 0.0f};   // Scene::BeginTick 에서 갱신
    float prevWorldRotation = 0.0f;
    bool  hasPrev = false;                 // false 면 보간 없이 현재 값 사용 (새로 생성/텔레포트 직후)

    Vec2  WorldPosition() const { return world.Position(); }
    float WorldRotation() const { return world.Rotation(); }
    Vec2  WorldScale() const    { return world.Scale(); }
    Vec2  InterpolatedPosition(float alpha) const { return hasPrev ? Lerp(prevWorldPosition, world.Position(), alpha) : world.Position(); }
    float InterpolatedRotation(float alpha) const { return hasPrev ? LerpAngle(prevWorldRotation, world.Rotation(), alpha) : world.Rotation(); }
};

/// 계층 연결 정보 (Scene 만 수정한다). 형제는 이중 연결 리스트, 자식 순서 = 추가 순서.
struct Node {
    Entity parent, firstChild, lastChild, prev, next;
    std::uint32_t childCount = 0;
};

} // namespace engine
