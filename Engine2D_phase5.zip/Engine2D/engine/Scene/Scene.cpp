#include "Scene/Scene.hpp"

#include <algorithm>

namespace engine {

Entity Scene::Create(const std::string& name, Vec2 position, Entity parent) {
    const Entity e = reg_.Create();
    reg_.Add<Name>(e, Name{name});
    Transform& t = reg_.Add<Transform>(e);
    t.position = position;
    reg_.Add<Node>(e);
    if (parent.Valid() && reg_.IsAlive(parent)) Link(e, parent);
    if (bus_) bus_->Publish(EntityCreatedEvent{e});
    return e;
}

void Scene::CollectSubtreePostOrder(Entity root, std::vector<Entity>& out) const {
    // 반복 DFS (깊은 계층에서 스택 오버플로 방지). 결과: 자식이 항상 부모보다 앞.
    std::vector<std::pair<Entity, bool>> st;
    st.push_back({root, false});
    while (!st.empty()) {
        auto [e, expanded] = st.back();
        st.pop_back();
        if (expanded) { out.push_back(e); continue; }
        st.push_back({e, true});
        ForEachChild(e, [&](Entity c) { st.push_back({c, false}); });
    }
}

bool Scene::Destroy(Entity e) {
    if (!reg_.IsAlive(e)) return false;
    Unlink(e);                                         // 서브트리 루트만 부모에서 떼면 충분
    std::vector<Entity> victims;
    CollectSubtreePostOrder(e, victims);
    for (Entity v : victims) {
        if (bus_) bus_->Publish(EntityDestroyedEvent{v});     // 컴포넌트가 아직 살아있음
    }
    for (Entity v : victims) reg_.Destroy(v);
    return true;
}

std::size_t Scene::FlushDestroyed() {
    std::size_t n = 0;
    for (std::size_t i = 0; i < pending_.size(); ++i) {       // 핸들러가 예약을 추가해도 안전
        // 하위 트리가 함께 삭제되므로 '삭제된 개수'는 루트 기준으로 센다
        if (Destroy(pending_[i])) ++n;
    }
    pending_.clear();
    return n;
}

void Scene::Clear() {
    // 이벤트 핸들러가 정리할 기회를 주기 위해 루트부터 하나씩 삭제
    std::vector<Entity> roots;
    reg_.Each<Node>([&](Entity e, Node& n) { if (!n.parent.Valid()) roots.push_back(e); });
    for (Entity r : roots) Destroy(r);
    pending_.clear();
}

Entity Scene::Find(const std::string& name) const {
    Entity found;
    reg_.ForEachEntity([&](Entity e) {
        if (found.Valid()) return;
        const Name* n = reg_.TryGet<Name>(e);
        if (n && n->value == name) found = e;
    });
    return found;
}

// ---------------------------------------------------------------- 계층
void Scene::Unlink(Entity e) {
    Node* n = reg_.TryGet<Node>(e);
    if (!n || !n->parent.Valid()) return;
    Node* p = reg_.TryGet<Node>(n->parent);
    if (p) {
        if (n->prev.Valid()) { if (Node* pn = reg_.TryGet<Node>(n->prev)) pn->next = n->next; }
        else p->firstChild = n->next;
        if (n->next.Valid()) { if (Node* nn = reg_.TryGet<Node>(n->next)) nn->prev = n->prev; }
        else p->lastChild = n->prev;
        if (p->childCount > 0) --p->childCount;
    }
    n->parent = n->prev = n->next = kNullEntity;
}

void Scene::Link(Entity child, Entity parent) {
    Node* n = reg_.TryGet<Node>(child);
    Node* p = reg_.TryGet<Node>(parent);
    if (!n || !p) return;
    n->parent = parent;
    n->prev = p->lastChild;
    n->next = kNullEntity;
    if (p->lastChild.Valid()) { if (Node* last = reg_.TryGet<Node>(p->lastChild)) last->next = child; }
    else p->firstChild = child;
    p->lastChild = child;
    ++p->childCount;
}

bool Scene::IsAncestor(Entity ancestor, Entity e) const {
    const Node* n = reg_.TryGet<Node>(e);
    while (n && n->parent.Valid()) {
        if (n->parent == ancestor) return true;
        n = reg_.TryGet<Node>(n->parent);
    }
    return false;
}

bool Scene::SetParent(Entity child, Entity parent, bool keepWorld) {
    if (!reg_.IsAlive(child)) return false;
    if (parent.Valid()) {
        if (!reg_.IsAlive(parent) || parent == child || IsAncestor(child, parent)) return false;   // 순환 방지
    }
    Transform* t = reg_.TryGet<Transform>(child);
    Affine2D world = t ? t->world : Affine2D{};
    Unlink(child);
    if (parent.Valid()) Link(child, parent);
    if (keepWorld && t) {
        const Transform* pt = parent.Valid() ? reg_.TryGet<Transform>(parent) : nullptr;
        const Affine2D parentWorld = pt ? pt->world : Affine2D{};
        if (parentWorld.Invertible()) {
            const Affine2D local = Compose(parentWorld.Inverse(), world);
            t->position = local.Position();
            t->rotation = local.Rotation();
            t->scale    = local.Scale();
        }
    }
    return true;
}

Entity Scene::Parent(Entity e) const { const Node* n = reg_.TryGet<Node>(e); return n ? n->parent : kNullEntity; }
Entity Scene::FirstChild(Entity e) const { const Node* n = reg_.TryGet<Node>(e); return n ? n->firstChild : kNullEntity; }
Entity Scene::NextSibling(Entity e) const { const Node* n = reg_.TryGet<Node>(e); return n ? n->next : kNullEntity; }
std::size_t Scene::ChildCount(Entity e) const { const Node* n = reg_.TryGet<Node>(e); return n ? n->childCount : 0; }

std::vector<Entity> Scene::Children(Entity e) const {
    std::vector<Entity> out;
    ForEachChild(e, [&](Entity c) { out.push_back(c); });
    return out;
}

// ---------------------------------------------------------------- 변환
void Scene::BeginTick() {
    reg_.Each<Transform>([](Entity, Transform& t) {
        t.prevWorldPosition = t.world.Position();
        t.prevWorldRotation = t.world.Rotation();
        t.hasPrev = true;
    });
}

void Scene::UpdateTransforms() {
    scratchRoots_.clear();
    reg_.Each<Node, Transform>([&](Entity e, Node& n, Transform&) { if (!n.parent.Valid()) scratchRoots_.push_back(e); });

    scratchStack_.clear();
    for (Entity root : scratchRoots_) {
        scratchStack_.push_back(root);
        while (!scratchStack_.empty()) {                       // 전위 순회: 부모가 항상 자식보다 먼저 계산됨
            const Entity e = scratchStack_.back();
            scratchStack_.pop_back();
            Transform* t = reg_.TryGet<Transform>(e);
            Node* n = reg_.TryGet<Node>(e);
            if (!t || !n) continue;
            const Transform* pt = n->parent.Valid() ? reg_.TryGet<Transform>(n->parent) : nullptr;
            const Affine2D local = Affine2D::FromTRS(t->position, t->rotation, t->scale);
            t->world = pt ? Compose(pt->world, local) : local;
            if (!t->hasPrev) { t->prevWorldPosition = t->world.Position(); t->prevWorldRotation = t->world.Rotation(); }
            for (Entity c = n->firstChild; c.Valid();) {
                scratchStack_.push_back(c);
                const Node* cn = reg_.TryGet<Node>(c);
                c = cn ? cn->next : kNullEntity;
            }
        }
    }
}

} // namespace engine
