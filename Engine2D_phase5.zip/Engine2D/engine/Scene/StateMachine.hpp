#pragma once
// ---------------------------------------------------------------------------
// 범용 상태 머신 (게임 화면 상태 / 엔티티 AI 공용). StateId 는 보통 enum class.
//
//   enum class S { Idle, Chase, Attack };
//   StateMachine<S> fsm;
//   fsm.Define(S::Idle).onEnter = [] { ... };
//   fsm.Define(S::Chase).onUpdate = [&](double dt) { ... };
//   fsm.AddTransition(S::Idle, S::Chase, [&] { return dist < 200; });     // 조건 전이 (등록 순서 = 우선순위)
//   fsm.AddAnyTransition(S::Idle, [&] { return hp <= 0; });               // 어느 상태에서든
//   fsm.Start(S::Idle);
//   fsm.Update(dt);                                                       // 매 틱
//
// 스택 연산 (일시정지 메뉴처럼 '위에 얹었다가 돌아오는' 상태)
//   Push(S::Paused)  : 현재 상태 onPause -> 새 상태 onEnter.   Pop() : 현재 onExit -> 아래 상태 onResume.
//   Update/전이 검사는 맨 위 상태에만 적용된다.
//
// 재진입 안전: 콜백(onEnter/onUpdate/onExit/조건) 안에서 Change/Push/Pop 을 불러도 즉시 실행하지 않고
//   콜백이 끝난 뒤 순서대로 처리한다. Request(id) 는 항상 다음 Update 시작 시점에 적용된다.
// ---------------------------------------------------------------------------
#include <cstddef>
#include <functional>
#include <unordered_map>
#include <utility>
#include <vector>

#include "Core/Log.hpp"

namespace engine {

template <class StateId>
class StateMachine {
public:
    struct State {
        std::function<void()>       onEnter;
        std::function<void(double)> onUpdate;
        std::function<void()>       onExit;
        std::function<void()>       onPause;    // 위에 다른 상태가 Push 될 때
        std::function<void()>       onResume;   // 위의 상태가 Pop 되어 다시 맨 위가 될 때
    };

    /// 상태를 정의(또는 기존 정의를 가져와서 수정). 반환된 참조는 Define 을 다시 부르기 전까지 유효.
    State& Define(StateId id) { return states_[id]; }

    void AddTransition(StateId from, StateId to, std::function<bool()> cond) {
        transitions_.push_back({false, from, to, std::move(cond)});
    }
    void AddAnyTransition(StateId to, std::function<bool()> cond) {
        transitions_.push_back({true, to, to, std::move(cond)});
    }
    /// 상태가 바뀔 때마다 (from, to) 로 호출. Start 시에는 호출되지 않음.
    void SetOnChange(std::function<void(StateId, StateId)> fn) { onChange_ = std::move(fn); }

    // ---- 수명 ----
    void Start(StateId initial) {
        Stop();
        Enqueue({Op::Push, initial});
        Drain();
    }
    /// 스택을 비우며 모든 상태의 onExit 호출.
    void Stop() {
        if (busy_) { Enqueue({Op::Stop, StateId{}}); return; }
        busy_ = true;
        while (!stack_.empty()) { StateId top = stack_.back(); Call(top, &State::onExit); stack_.pop_back(); }
        busy_ = false;
        queue_.clear();
    }

    // ---- 전이 ----
    void Change(StateId next)  { Enqueue({Op::Change, next}); Drain(); }     // 맨 위 상태를 교체
    void Push(StateId next)    { Enqueue({Op::Push, next});   Drain(); }
    void Pop()                 { Enqueue({Op::Pop, StateId{}}); Drain(); }
    void Request(StateId next) { requested_.push_back(next); }                // 다음 Update 시작 시 Change

    void Update(double dt) {
        if (stack_.empty()) return;
        if (!requested_.empty()) {
            std::vector<StateId> reqs;
            reqs.swap(requested_);
            for (const StateId& r : reqs) Change(r);
        }
        if (stack_.empty()) return;
        busy_ = true;
        const StateId cur = stack_.back();
        timeInState_ += dt;
        if (auto it = states_.find(cur); it != states_.end() && it->second.onUpdate) it->second.onUpdate(dt);
        // 조건 전이: 등록 순서대로 검사, 처음 참인 것 하나만 적용 (onUpdate 가 이미 상태를 바꿨다면 건너뜀)
        if (queue_.empty() && !stack_.empty() && stack_.back() == cur) {
            for (const Transition& t : transitions_) {
                if (!t.any && !(t.from == cur)) continue;
                if (t.any && t.to == cur) continue;
                if (t.cond && t.cond()) { queue_.push_back({Op::Change, t.to}); break; }
            }
        }
        busy_ = false;
        Drain();
    }

    // ---- 조회 ----
    bool Running() const { return !stack_.empty(); }
    const StateId& Current() const { return stack_.back(); }                  // Running() 일 때만
    bool Is(StateId id) const { return !stack_.empty() && stack_.back() == id; }
    bool Contains(StateId id) const { for (const StateId& s : stack_) if (s == id) return true; return false; }   // 스택 어딘가에
    std::size_t Depth() const { return stack_.size(); }
    double TimeInState() const { return timeInState_; }                       // 맨 위 상태에 들어온 뒤 누적 시간(초)

private:
    enum class Op { Change, Push, Pop, Stop };
    struct Pending { Op op; StateId id; };
    struct Transition { bool any; StateId from; StateId to; std::function<bool()> cond; };

    void Enqueue(Pending p) { queue_.push_back(std::move(p)); }

    void Drain() {
        if (busy_) return;                                    // 콜백 안: 바깥 루프가 처리
        busy_ = true;
        for (std::size_t i = 0; i < queue_.size(); ++i) {     // 콜백이 큐에 추가해도 이어서 처리
            const Pending p = queue_[i];
            switch (p.op) {
            case Op::Change: {
                const bool had = !stack_.empty();
                const StateId from = had ? stack_.back() : p.id;
                if (had) { Call(from, &State::onExit); stack_.pop_back(); }
                Enter(p.id);
                if (had && onChange_) onChange_(from, p.id);
                break;
            }
            case Op::Push:
                if (!stack_.empty()) Call(stack_.back(), &State::onPause);
                Enter(p.id);
                break;
            case Op::Pop:
                if (stack_.empty()) break;
                Call(stack_.back(), &State::onExit);
                stack_.pop_back();
                timeInState_ = 0.0;
                if (!stack_.empty()) Call(stack_.back(), &State::onResume);
                break;
            case Op::Stop:
                while (!stack_.empty()) { StateId top = stack_.back(); Call(top, &State::onExit); stack_.pop_back(); }
                break;
            }
        }
        queue_.clear();
        busy_ = false;
    }

    void Enter(StateId id) {
        if (states_.find(id) == states_.end()) ENGINE_LOG_WARN("StateMachine: entering a state with no definition");
        stack_.push_back(id);
        timeInState_ = 0.0;
        Call(id, &State::onEnter);
    }
    void Call(const StateId& id, std::function<void()> State::* member) {
        auto it = states_.find(id);
        if (it != states_.end() && (it->second.*member)) (it->second.*member)();
    }

    std::unordered_map<StateId, State> states_;
    std::vector<Transition>            transitions_;
    std::vector<StateId>               stack_;
    std::vector<Pending>               queue_;
    std::vector<StateId>               requested_;
    std::function<void(StateId, StateId)> onChange_;
    double timeInState_ = 0.0;
    bool   busy_ = false;
};

} // namespace engine
