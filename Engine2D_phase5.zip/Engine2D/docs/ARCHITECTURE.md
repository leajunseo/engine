# Engine2D — Architecture (Phase 1~5)

> 가정한 스택: **C++17 · SDL2(창/입력/컨텍스트) · OpenGL 3.3 Core · GLEW · CMake**
> (요청서의 `[사용할 언어 지정]` 자리표시자에 예시값을 채택. 바꾸려면 Window/Renderer 두 모듈만 교체하면 됨)

## 1. 디렉토리 구조 (최종 목표 / ★ = Phase 1 구현 완료)

```
Engine2D/
├── CMakeLists.txt                  ★
├── docs/ARCHITECTURE.md            ★
├── engine/                         # 정적 라이브러리 'engine'
│   ├── Core/                       # 플랫폼·루프·인프라 (아무것에도 의존하지 않음)
│   │   ├── Application.hpp/.cpp    ★ 고정 타임스텝 메인 루프, 수명 관리, IGame 인터페이스
│   │   ├── Window.hpp/.cpp         ★ SDL2 창 + GL 컨텍스트 (RAII), 플랫폼 이벤트 -> EventBus
│   │   ├── EventBus.hpp            ★ 타입 안전 디스패처 (즉시 Publish + 스레드 세이프 Enqueue)
│   │   ├── Events.hpp              ★ 플랫폼 이벤트 정의
│   │   ├── Log.hpp/.cpp            ★ 스레드 세이프 로거 (Info/Warning/Error/Fatal, 콘솔+파일)
│   │   ├── Timer.hpp               ★ 나노초 정수 시계, FPS/UPS 측정기
│   │   ├── Assert.hpp              ★ Debug 전용 ENGINE_ASSERT
│   │   ├── Memory/                 ★ Phase 2: PoolAllocator, FrameArena
│   │   └── Jobs/                   # (선택) 워커 스레드 풀
│   ├── Renderer/
│   │   ├── Renderer.hpp/.cpp       ★ GL 로더/상태/뷰포트/프레임 경계
│   │   ├── Shader, Texture, TextureAtlas       ★ Phase 2
│   │   ├── SpriteBatch, Camera2D, RenderLayer  ★ Phase 2
│   ├── Physics/                    ★ Phase 3
│   │   ├── Collision.hpp/.cpp      ★ Shape(원/박스/볼록 다각형), AABB, 내로페이즈(AABB 고속경로, 원, SAT+클리핑) -> Manifold
│   │   ├── Quadtree.hpp/.cpp       ★ 브로드페이즈 (매 스텝 재구성, 중복 없는 후보 쌍, 영역 질의)
│   │   └── PhysicsWorld.hpp/.cpp   ★ 바디 수명(세대 ID), 순차 임펄스 솔버, 충돌/트리거 이벤트, 질의(점/영역/픽)
├── tests/physics_tests.cpp         ★ 창/GL 없이 도는 물리 단위 테스트 (ctest)
│   ├── Scene/                      ★ Phase 4: ECS(Registry), Scene(Transform 계층), StateMachine, Components
│   ├── Systems/                    ★ Phase 4: Behavior / Physics 연결 / Render(DrawSprites), StandardComponents
│   ├── Input/                      ★ Phase 5: KeyCode(플랫폼 독립), InputManager(상태/액션/축/바인딩 저장)
│   ├── Audio/                      ★ Phase 5: Mixer(보이스 풀/버스), Wav, MusicStream(스트리밍), AudioManager(SDL 장치)
│   ├── Assets/                     ★ Phase 4: AssetManager(캐시+핸들+핫 리로드), ImageLoader(BMP/TGA, 선택 stb)
├── tests/scene_tests.cpp           ★ Phase 4 단위 테스트 (ECS/계층/FSM/에셋/이미지/물리 연결)
├── tests/input_tests.cpp, audio_tests.cpp  ★ Phase 5 단위 테스트
└── sandbox/main.cpp, scene_demo.cpp, input_audio_demo.cpp ★ 데모 게임 (IGame 구현)
```

## 2. 레이어 / 의존 방향

```
 ┌────────────────────────── Game (sandbox/, 사용자 코드) ──────────────────────────┐
 │                         implements IGame                                          │
 └───────────────────────────────────────┬───────────────────────────────────────────┘
                                         │ uses
 ┌───────────────────────────────────────▼───────────────────────────────────────────┐
 │ Application (루프 오케스트레이션, 수명 관리)                                      │
 └───┬───────────────┬──────────────────┬──────────────────┬─────────────────────────┘
     │ owns          │ owns             │ owns             │ (Phase 3-5)
 ┌───▼────┐     ┌────▼─────┐      ┌─────▼─────┐   ┌────────▼─────────────────────────┐
 │ Window │     │ Renderer │      │ EventBus  │   │ Physics · Scene · Assets · Input │
 └───┬────┘     └────┬─────┘      └─────▲─────┘   │ · Audio                          │
     │ SDL2/GL ctx   │ OpenGL           │         └────────┬─────────────────────────┘
     │               │                  │ Publish / Subscribe (직접 참조 없음)
     └───────────────┴──────────────────┴──────────────────┘
                      ▼ 모두가 사용하는 최하층
                 Log · Timer · Assert
```

**규칙**
1. 의존은 위 -> 아래 한 방향. `Core` 는 `Renderer` 를 알지 못한다 (Application 만 둘을 조립).
2. 형제 모듈(Window ↔ Renderer, Physics ↔ Audio …)은 서로 include 하지 않고 **EventBus 이벤트**로만 통신.
3. SDL / OpenGL 헤더는 `.cpp` 안에만 둔다 -> 백엔드 교체(Vulkan, SDL3 등) 시 공개 헤더 불변.
4. 소유권은 RAII(`unique_ptr` / 값 멤버) 로 명확히. 원시 `new/delete` 없음.

## 3. 메인 루프 (Fix Your Timestep)

```
 ┌───────────────────────────────────────────────────────────────────────────┐
 │ frameNs = min(now - prev, maxFrameNs)      # 클램프 (spiral of death 1차)   │
 │ acc    += frameNs                                                           │
 │ PollEvents(); EventBus.DispatchQueued()                                     │
 │                                                                             │
 │ steps = 0                                                                   │
 │ while acc >= stepNs and steps < maxUpdatesPerFrame:   # 2차 방어            │
 │     game.OnFixedUpdate(stepNs)      ◄── 항상 동일한 dt (결정론적)           │
 │     acc -= stepNs; steps++                                                  │
 │ if acc >= stepNs: acc %= stepNs     # 못 따라가면 밀린 시간 폐기 + 경고     │
 │                                                                             │
 │ game.OnVariableUpdate(frameDt)      ◄── 카메라 스무딩, UI 등                │
 │ alpha = acc / stepNs                ◄── 0 ≤ alpha < 1                       │
 │ BeginFrame → game.OnRender(alpha) → EndFrame → SwapBuffers (vsync 대기)     │
 └───────────────────────────────────────────────────────────────────────────┘
 render_state = lerp(prev_tick_state, curr_tick_state, alpha)
```

- 시간은 **int64 나노초**로만 누적 -> 장시간 실행해도 드리프트/비결정성 없음.
- `stepNs = 1e9 / fixedHz` (정수 나눗셈, 60Hz = 16,666,666 ns).

## 4. 병목 지점 & 최적화 메모

| 위치 | 병목 | 대응 |
|---|---|---|
| `Log::Write` | 전역 mutex 직렬화 | 포맷은 락 밖에서 수행. 고빈도 로그가 필요해지면 MPSC 링 버퍼 + flush 스레드 |
| `EventBus::Enqueue` | `std::function` 힙 할당 | 즉시 `Publish` 는 무할당. 고빈도 큐 이벤트는 타입별 SPSC 링으로 교체 |
| `OnFixedUpdate` 과부하 | spiral of death | 프레임 시간 클램프 + 프레임당 스텝 상한 + 초과분 폐기 |
| `SwapBuffers` | vsync 블로킹 | vsync 끄면 `targetFps` 하이브리드 sleep+spin 리미터 사용 |
| GL Debug Output | SYNCHRONOUS 모드는 느림 | `ENGINE_DEBUG` 빌드에서만 활성화 |
| 스프라이트 (Phase 2 구현) | 드로우콜 수 | 동적 VBO 배칭, 텍스처 아틀라스로 바인드 변경 최소화, 레이어/텍스처 기준 정렬 후 한 번에 제출 |

## 5. 알려진 한계 (Phase 1)

- Windows 에서 창 드래그/리사이즈 중에는 OS 의 모달 루프 때문에 `PollEvents` 가 막혀 루프가 멈춘다. (SDL event watch 또는 별도 렌더 스레드로 해결 가능 - 추후 단계)
- `KeyEvent` 는 SDL scancode 를 그대로 노출. Phase 5 에서 플랫폼 독립 `KeyCode` 로 교체.
- EventBus 의 `Subscribe/Publish` 는 메인 스레드 전용 (`Enqueue` 만 멀티스레드 안전).

## 6. Physics (Phase 3)

**Step 파이프라인** (`PhysicsWorld::Step(dt)`, `OnFixedUpdate` 에서 호출)

```
 1. prev <- curr, 힘/중력 -> 속도 (감쇠, 속도 상한)
 2. Quadtree 후보 쌍 (정렬 -> 결정론)           ← 브로드페이즈
 3. 레이어/마스크 필터 -> Collide() -> Manifold   ← 내로페이즈 (+ 이전 스텝 임펄스 이월 = warm starting)
 4. 속도 제약: 마찰 -> 법선, velocityIterations 회 (누적 임펄스를 0 이상으로 클램프)
 5. 위치 적분   6. 침투 보정(선형, slop 허용)
 7. AABB/트리 갱신   8. 이벤트 발행 (Begin/End, TriggerEnter/Exit)
```

| 항목 | 설계 |
|---|---|
| 도형 | Circle / Box / Polygon(볼록, <=8). 로컬 원점 = 무게중심, CCW, 모서리 법선 사전 계산 |
| 판정 | 원-원, 다각형-원(보로노이 영역), 다각형-다각형 = SAT(최소 침투축) + 참조면/입사면 클리핑(접촉점 2개), 회전 0 박스 쌍은 AABB 고속 경로 |
| 접촉점 ID | (참조면, 입사면, 순서) 로 만든 피처 ID -> 프레임이 바뀌어도 같은 점에 누적 임펄스를 이월 -> 쌓기 안정 |
| 반발/마찰 | 반발 = max(a,b), 마찰 = sqrt(a*b). `restitutionThreshold` 이하 속도는 반발 없음(떨림 방지) |
| 유형 | Static / Kinematic(속도로만 이동) / Dynamic. 센서(isSensor)는 겹침 이벤트만 |
| ID | `BodyId{index, generation}` - 삭제된 바디 id 는 자동 무효(슬롯 재사용 안전) |
| 이벤트 | Step 이 끝난 뒤 EventBus 로 발행. 핸들러에서 Create/DestroyBody 해도 안전 |
| 결정론 | 후보 쌍/End 이벤트 정렬, 고정 dt, 난수 없음 -> 같은 입력이면 비트 단위로 같은 결과 (테스트로 검증) |
| 렌더 보간 | `InterpolatedPosition/Rotation(body, alpha)` |

**병목 & 한계**

| 위치 | 내용 | 대응 |
|---|---|---|
| 브로드페이즈 | 매 스텝 트리 재구성 O(n log n). 루트에 남는 큰 정적 물체는 모든 아이템과 검사됨 | 정적 물체 전용 트리 분리 / 증분 갱신(loose quadtree) |
| 솔버 | O(접촉 x 반복). 큰 더미에서 가장 큰 비용 | 아일랜드 분할 + 슬리핑(미구현), 멀티스레드 |
| 터널링 | 연속 충돌 검사(CCD) 없음: 얇은 물체가 한 스텝에 자기 두께보다 멀리 가면 통과 | `maxLinearSpeed` 제한, 서브스텝, 이후 단계에서 스윕 테스트 |
| 위치 보정 | 접촉당 1회 선형 보정(회전 미보정). 깊은 침투가 쌓이면 약간 눌림 | 위치 반복(NGS) |
| 슬리핑 | 없음: 정지한 더미도 계속 계산 | 아일랜드 단위 슬립 |
| 도형 | 오목 다각형/복합 콜라이더, 관절(joint) 미지원 | Phase 4 이후 |
| 질의 | 점/영역 질의만 (레이캐스트 없음) | 추가 예정 |

## 7. Scene / ECS / 상태 머신 / 에셋 (Phase 4)

**한 고정 틱의 순서** (`scene_demo.cpp` 참고)

```
 scene.BeginTick();            # 직전 월드 상태 스냅샷 (렌더 보간용)
 UpdateBehaviors(scene, dt);   # Behavior 컴포넌트 onStart/onUpdate
 world.Step(dt);               # 물리
 physicsSys.SyncFromPhysics(); # 바디 -> Transform
 scene.UpdateTransforms();     # 로컬 -> 월드 (부모 먼저)
 scene.FlushDestroyed();       # DestroyLater 예약분 정리
 ... 렌더: DrawSprites(scene, batch, alpha)
```

| 모듈 | 설계 |
|---|---|
| ECS (`Scene/ECS.hpp`) | 세대 붙은 `Entity{index,generation}` + sparse-set 컴포넌트 풀(dense 순회, swap-pop 삭제). `Each<Ts...>` 는 가장 작은 풀 기준 순회. 순회 중 구조 변경은 `DestroyLater` + `FlushDestroyed` |
| Scene | Registry + 변환 계층. 모든 엔티티는 Name/Transform/Node 보유. 부모 회전/스케일이 자식에 전파. `EntityCreated/DestroyedEvent` 발행(자식→부모 순) |
| StateMachine<S> | 조건 전이(등록 순서 = 우선순위), Any 전이, **스택**(Push/Pop: 일시정지 메뉴), 콜백 안에서 Change/Push/Pop 호출해도 안전(지연 처리) |
| Systems | `PhysicsSystem`: 엔티티↔바디 연결, 엔티티 삭제 시 바디 삭제, 물리 이벤트를 엔티티 이벤트로 번역. `BehaviorSystem`, `RenderSystem(DrawSprites)` |
| AssetManager | 경로 키 캐시 + `Asset<T>` 핸들(레퍼런스 카운팅), 타입별 로더(Texture/ImageData/Blob/Text), `ReloadChanged()` 핫 리로드(실패 시 기존 데이터 유지), `CollectUnused()`, `Application::Assets()` 로 접근, 종료 시 GL 컨텍스트보다 먼저 `Clear()` |
| ImageLoader | BMP/TGA 내장 디코더(경계 검사, 크기 상한 16384), `ENGINE_HAS_STB` 시 PNG/JPG 등 추가 |

**병목 & 한계**
- `UpdateTransforms` 는 매번 전체 O(n) 재계산 -> 수만 개 이상이면 dirty 플래그 + 정적 서브트리 스킵.
- 물리 도형은 엔티티 스케일을 반영하지 않음. 바디 엔티티는 루트로 둘 것(자식이면 부모 이동이 한 틱 늦음).
- Behavior 는 `std::function` 기반 -> 수천 개 이상이면 전용 컴포넌트/시스템으로.
- 핫 리로드는 파일 수정 시각 폴링(`ReloadChanged`, 데모는 0.5초 주기). 파일 감시 API 로 교체 가능.

## 8. Input / Audio (Phase 5)

**입력** — `Window` 가 SDL 이벤트를 `KeyEvent{key=KeyCode}`/Mouse 이벤트로 EventBus 에 발행하고, `InputManager`(`app.Input()`)가 구독해서 상태를 모은다. SDL 헤더는 `KeyCode.cpp`/`Window.cpp` 에만 있다.

| 항목 | 설계 |
|---|---|
| KeyCode | 물리적 키 위치(scancode) 기준 -> 자판 배열이 달라도 WASD 는 같은 위치. `KeyName()`/`KeyCodeFromName()` 으로 저장용 문자열 변환 |
| 상태 | `Down` 은 어디서나 동일. 엣지는 두 종류: `Pressed/Released`(렌더 프레임 단위, OnVariableUpdate/OnRender 용)와 `PressedTick/ReleasedTick`(고정 틱 단위, OnFixedUpdate 용 — 틱이 안 도는 프레임의 입력도 다음 틱까지 유지, 한 프레임에 틱이 여러 번이어도 첫 틱에서만 true) |
| 액션/축 | `DefineAction/BindKey/BindMouse`, `DefineAxis/BindAxisKeys/MouseX/Y/Wheel`. 같은 액션의 여러 입력은 OR, 액션 엣지는 상태가 바뀔 때 한 번만. 키 축은 [-1,1] 로 제한 |
| 안전장치 | 포커스를 잃으면 눌린 키를 모두 뗌 처리, 키 반복 이벤트 무시 |
| 리바인드 | `LastPressedKey()`, `FindActionUsing(key)`(충돌 안내), `SaveBindings/LoadBindings`(텍스트 형식: `action Jump key Space`, `axis MoveX keys A D`; 잘못된 줄은 건너뛰고 보고) |

**오디오** — `Mixer` 는 SDL 에 의존하지 않는 순수 CPU 믹서(`Mix(float*, frames)`), `AudioManager`(`app.Audio()`)가 SDL 장치 콜백에서 이를 호출한다 -> 사운드카드 없이 단위 테스트 가능.

| 항목 | 설계 |
|---|---|
| 효과음 | 고정 크기 보이스 풀(기본 64), `VoiceId{index,generation}`(재생이 끝난 id 는 자동 무효), 가득 차면 오래된 비반복 보이스부터 훔침. 볼륨/피치(선형 보간 리샘플)/팬(등전력)/루프, 짧은 페이드아웃 Stop 으로 딸깍 소리 방지 |
| 믹스 | 마스터 + 버스(Sfx/Music) 볼륨은 블록 안에서 선형 보간(계단 없음), 합산 후 [-1,1] 클램프, NaN/Inf 는 0, `PeakLevels()` 로 클리핑 감시 |
| 음악 | `StreamingMusic`: 디코더 스레드가 WAV 를 읽어 믹서 레이트로 리샘플해 ~1초 링 버퍼에 채우고 오디오 스레드는 복사만 -> 콜백이 디스크 I/O 로 막히지 않음. 페이드인/아웃, 크로스페이드, 루프(이음매 없음), 일시정지. 버퍼 부족이면 그 구간만 무음 |
| 에셋 | `Application` 이 `AudioClip` 로더를 AssetManager 에 등록 -> `app.Assets().Load<AudioClip>("x.wav")`, 핫 리로드 지원(재생 중인 소리는 옛 데이터로 끝까지) |
| WAV | PCM 8/16/24/32, float32, 모노/스테레오 디코드(경계 검사, 길이 상한), 16bit 인코드 |
| 장치 없음 | `Init` 실패 시 무음 모드로 계속 (모든 호출 안전, 소리만 안 남) |

**한계**: 장치 핫플러그 시 자동 재연결 없음 · 음악은 WAV 만(OGG/MP3 미지원) · 리샘플러는 선형 보간(고주파가 약간 뭉개짐) · 게임패드 미지원 · 3D/거리 감쇠 없음(팬만) · `scene_demo`/`sandbox` 는 아직 SDL scancode 를 직접 사용(동작에는 문제 없음, 점진적으로 `app.Input()` 으로 이전 가능).
