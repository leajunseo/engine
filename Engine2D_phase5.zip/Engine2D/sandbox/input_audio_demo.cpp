// Phase 5 데모: InputManager(액션/축/리바인드/저장) + AudioManager(효과음 풀, 팬/피치, 버스 볼륨, 스트리밍 음악).
//   이동        WASD / 방향키              (축 MoveX, MoveY)
//   발사        Space / 마우스 왼쪽         (액션 Fire)  -> 마우스 쪽으로 탄환 + 효과음 (화면 X 위치에 따라 팬)
//   대시        Shift                       (액션 Dash)  -> 짧은 가속 + 휙 소리
//   M           음악 켜기/끄기 (페이드)      - / =  마스터 볼륨      , / .  음악 볼륨      ; / '  효과음 볼륨
//   F2          Fire 리바인드 (다음에 누르는 키)   F3 바인딩 저장   F4 바인딩 불러오기   F5 기본값 복원
//   ESC         종료
// 소리는 모두 코드로 합성해서 assets/ 에 WAV 로 쓴 뒤 AssetManager 로 읽는다 (외부 파일 불필요).
//   assets/blip.wav 를 다른 WAV 로 바꿔 저장하면 실행 중에 핫 리로드된다.
#include <SDL.h>

#include <algorithm>
#include <cmath>
#include <cstdint>
#include <cstdio>
#include <filesystem>
#include <random>
#include <string>
#include <vector>

#include "Audio/Wav.hpp"
#include "Core/Application.hpp"
#include "Core/Log.hpp"
#include "Renderer/Camera2D.hpp"

using namespace engine;
namespace fs = std::filesystem;

namespace {

constexpr int   kRate = 44100;

// ---- 절차적 소리 합성 ---------------------------------------------------------------------------------------
std::vector<float> SynthBlip(float f0, float f1, float seconds, float amp) {       // 주파수가 f0 -> f1 로 미끄러지는 사각파 + 감쇠
    const int n = static_cast<int>(seconds * kRate);
    std::vector<float> v(static_cast<std::size_t>(n));
    float phase = 0.0f;
    for (int i = 0; i < n; ++i) {
        const float t = static_cast<float>(i) / static_cast<float>(n);
        phase += (f0 + (f1 - f0) * t) / static_cast<float>(kRate);
        const float sq = (phase - std::floor(phase)) < 0.5f ? 1.0f : -1.0f;
        v[static_cast<std::size_t>(i)] = sq * amp * (1.0f - t) * (1.0f - t);
    }
    return v;
}

std::vector<float> SynthNoise(float seconds, float amp) {                           // 저역 통과 노이즈 + 감쇠 (휙)
    std::mt19937 rng(7);
    std::uniform_real_distribution<float> d(-1.0f, 1.0f);
    const int n = static_cast<int>(seconds * kRate);
    std::vector<float> v(static_cast<std::size_t>(n));
    float lp = 0.0f;
    for (int i = 0; i < n; ++i) {
        const float t = static_cast<float>(i) / static_cast<float>(n);
        lp += (d(rng) - lp) * 0.12f;
        v[static_cast<std::size_t>(i)] = lp * amp * (1.0f - t);
    }
    return v;
}

std::vector<float> SynthMusic(float seconds) {                                      // 아르페지오 + 베이스 (정수 박자 길이 -> 루프 이음매 없음)
    const int n = static_cast<int>(seconds * kRate);
    std::vector<float> v(static_cast<std::size_t>(n), 0.0f);
    const float notes[8] = {220.0f, 261.63f, 329.63f, 392.0f, 440.0f, 392.0f, 329.63f, 261.63f};
    const int per = n / 16;
    for (int i = 0; i < n; ++i) {
        const int slot = std::min(15, i / per);
        const float f = notes[(slot / 2) % 8];
        const float local = static_cast<float>(i % per) / static_cast<float>(per);
        const float env = std::exp(-3.0f * local);
        const float t = static_cast<float>(i) / static_cast<float>(kRate);
        const float bass = 0.18f * std::sin(2.0f * kPi * 55.0f * t);
        v[static_cast<std::size_t>(i)] = 0.25f * std::sin(2.0f * kPi * f * t) * env + bass;
    }
    return v;
}

void WriteMono(const std::string& path, const std::vector<float>& mono) {
    if (!SaveWav16(path, mono.data(), mono.size(), 1, kRate)) ENGINE_LOG_WARN("could not write %s", path.c_str());
}

struct Bullet { Vec2 pos, vel; float life; };

} // namespace

class InputAudioDemo final : public IGame {
public:
    bool OnInit(Application& app) override {
        app_ = &app;
        InputManager& in = app.Input();

        // ---- 액션/축 정의 + 기본 바인딩 ----
        fire_  = in.DefineAction("Fire");
        dash_  = in.DefineAction("Dash");
        moveX_ = in.DefineAxis("MoveX");
        moveY_ = in.DefineAxis("MoveY");
        SetDefaultBindings();

        // ---- 소리 만들기 -> 파일 -> AssetManager (핫 리로드 가능) ----
        std::error_code ec;
        fs::create_directories(app.Assets().Root(), ec);
        auto path = [&](const char* name) { return app.Assets().Resolve(name); };
        if (!fs::exists(path("blip.wav")))   WriteMono(path("blip.wav"),   SynthBlip(880.0f, 220.0f, 0.18f, 0.35f));
        if (!fs::exists(path("whoosh.wav"))) WriteMono(path("whoosh.wav"), SynthNoise(0.28f, 0.9f));
        if (!fs::exists(path("thud.wav")))   WriteMono(path("thud.wav"),   SynthBlip(140.0f, 40.0f, 0.22f, 0.7f));
        if (!fs::exists(path("bgm.wav")))    WriteMono(path("bgm.wav"),    SynthMusic(8.0f));
        blip_   = app.Assets().Load<AudioClip>("blip.wav");
        whoosh_ = app.Assets().Load<AudioClip>("whoosh.wav");
        thud_   = app.Assets().Load<AudioClip>("thud.wav");
        if (!blip_ || !whoosh_ || !thud_) return false;

        bindingsPath_ = path("bindings.txt");
        if (!app.Audio().HasDevice()) ENGINE_LOG_WARN("no audio device: running silent (everything else still works)");
        app.Audio().PlayMusic(path("bgm.wav"), true, 1.5f);
        musicOn_ = true;
        ENGINE_LOG_INFO("Phase 5 demo ready - move WASD, fire Space/click, dash Shift, M music, F2 rebind");
        return true;
    }

    void OnShutdown() override {
        app_->Audio().StopMusic(0.0f);
        blip_.Reset(); whoosh_.Reset(); thud_.Reset();
    }

    void OnFixedUpdate(double dtD) override {
        const float dt = static_cast<float>(dtD);
        InputManager& in = app_->Input();
        AudioManager& au = app_->Audio();

        // 이동: 축 값(-1..1) -> 속도. 대시는 짧은 감쇠 가속.
        Vec2 dir{in.Value(moveX_), in.Value(moveY_)};
        if (dir.LengthSq() > 1.0f) dir = Normalized(dir);
        if (in.PressedTick(dash_) && dashLeft_ <= 0.0f) {
            dashLeft_ = 0.18f;
            au.PlaySfx(*whoosh_, {0.8f, 1.0f + dir.x * 0.1f, Clamp(player_.x / 640.0f, -1.0f, 1.0f), false});
        }
        const float speed = 320.0f + (dashLeft_ > 0.0f ? 900.0f * (dashLeft_ / 0.18f) : 0.0f);
        dashLeft_ -= dt;
        player_ = player_ + dir * (speed * dt);
        player_.x = Clamp(player_.x, -610.0f, 610.0f);
        player_.y = Clamp(player_.y, -340.0f, 340.0f);

        // 발사: 틱 단위 엣지(PressedTick) -> 프레임이 길어져도 누락/중복 없음
        if (in.PressedTick(fire_)) {
            const Vec2 aim = Normalized(mouseWorld_ - player_);
            bullets_.push_back({player_, (aim.LengthSq() > 0.0f ? aim : Vec2{1, 0}) * 900.0f, 1.2f});
            const float pitch = 0.9f + 0.4f * static_cast<float>(rng_() % 1000) / 1000.0f;
            au.PlaySfx(*blip_, {0.7f, pitch, Clamp(player_.x / 640.0f, -1.0f, 1.0f), false});
        }
        for (Bullet& b : bullets_) {
            b.pos = b.pos + b.vel * dt;
            b.life -= dt;
            if (std::fabs(b.pos.x) > 640.0f || std::fabs(b.pos.y) > 360.0f) {      // 가장자리에 부딪히면 쿵 (팬 = 부딪힌 위치)
                if (b.life > 0.0f) au.PlaySfx(*thud_, {0.5f, 1.0f, Clamp(b.pos.x / 640.0f, -1.0f, 1.0f), false});
                b.life = 0.0f;
            }
        }
        bullets_.erase(std::remove_if(bullets_.begin(), bullets_.end(), [](const Bullet& b) { return b.life <= 0.0f; }), bullets_.end());
    }

    void OnVariableUpdate(double frameDt) override {
        InputManager& in = app_->Input();
        AudioManager& au = app_->Audio();
        Mixer& mx = au.GetMixer();
        camera_.SetViewport(app_->GetRenderer().ViewportWidth(), app_->GetRenderer().ViewportHeight());
        const Vec2 m = in.MousePosition();
        mouseWorld_ = camera_.ScreenToWorld(m.x, m.y);

        if (in.Pressed(KeyCode::Escape) && !rebinding_) app_->RequestQuit();
        if (in.Pressed(KeyCode::M)) {
            musicOn_ = !musicOn_;
            if (musicOn_) au.PlayMusic(app_->Assets().Resolve("bgm.wav"), true, 1.0f);
            else          au.StopMusic(1.0f);
        }
        auto adjust = [](float v, float d) { return Clamp(v + d, 0.0f, 1.5f); };
        if (in.Pressed(KeyCode::Minus))      mx.SetMasterVolume(adjust(mx.MasterVolume(), -0.1f));
        if (in.Pressed(KeyCode::Equals))     mx.SetMasterVolume(adjust(mx.MasterVolume(), +0.1f));
        if (in.Pressed(KeyCode::Comma))      mx.SetBusVolume(AudioBus::Music, adjust(mx.BusVolume(AudioBus::Music), -0.1f));
        if (in.Pressed(KeyCode::Period))     mx.SetBusVolume(AudioBus::Music, adjust(mx.BusVolume(AudioBus::Music), +0.1f));
        if (in.Pressed(KeyCode::Semicolon))  mx.SetBusVolume(AudioBus::Sfx,   adjust(mx.BusVolume(AudioBus::Sfx),   -0.1f));
        if (in.Pressed(KeyCode::Apostrophe)) mx.SetBusVolume(AudioBus::Sfx,   adjust(mx.BusVolume(AudioBus::Sfx),   +0.1f));

        // ---- 리바인드: F2 를 누르고 다음에 누르는 키를 Fire 에 묶는다 ----
        if (rebinding_) {
            const KeyCode k = in.LastPressedKey();
            if (k != KeyCode::Unknown && k != KeyCode::F2) {
                if (k == KeyCode::Escape) {
                    rebindMsg_ = "rebind cancelled";
                    rebinding_ = false;
                } else {
                    const std::string other = in.FindActionUsing(k);
                    if (!other.empty() && other != "Fire") {
                        rebindMsg_ = std::string(KeyName(k)) + " is used by " + other + " - pick another";     // 계속 대기
                    } else {
                        in.ClearBindings(fire_);
                        in.BindKey(fire_, k);
                        in.BindMouse(fire_, MouseButton::Left);
                        rebindMsg_ = std::string("Fire = ") + KeyName(k) + " / Mouse Left";
                        rebinding_ = false;
                    }
                }
                ENGINE_LOG_INFO("%s", rebindMsg_.c_str());
            }
        } else {
            if (in.Pressed(KeyCode::F2)) { rebinding_ = true; rebindMsg_ = "press a key for Fire (Esc cancels)"; }
            if (in.Pressed(KeyCode::F3)) { rebindMsg_ = in.SaveBindings(bindingsPath_) ? "bindings saved" : "save failed"; }
            if (in.Pressed(KeyCode::F4)) {
                std::vector<std::string> errs;
                rebindMsg_ = in.LoadBindings(bindingsPath_, &errs) ? "bindings loaded" : "load failed or had errors";
            }
            if (in.Pressed(KeyCode::F5)) { SetDefaultBindings(); rebindMsg_ = "default bindings restored"; }
        }

        reloadTimer_ += static_cast<float>(frameDt);
        if (reloadTimer_ > 0.5f) { reloadTimer_ = 0.0f; reloads_ += static_cast<int>(app_->Assets().ReloadChanged()); }
    }

    void OnRender(Renderer& r, double alpha) override {
        (void)alpha;
        camera_.SetViewport(r.ViewportWidth(), r.ViewportHeight());
        r.Clear(0.06f, 0.07f, 0.10f);
        r.BeginScene(camera_);
        SpriteBatch& b = r.Batch();
        const InputManager& in = app_->Input();

        b.DrawRect({0, 0}, {1280, 720}, {0.09f, 0.10f, 0.14f, 1.0f}, 0.0f, -2);
        for (const Bullet& bu : bullets_) b.DrawRect(bu.pos, {10, 10}, {1.0f, 0.85f, 0.3f, 1.0f}, 0.0f, 1);
        const bool dashing = dashLeft_ > 0.0f;
        b.DrawRect(player_, dashing ? Vec2{44, 24} : Vec2{32, 32}, dashing ? Color{0.6f, 0.9f, 1.0f} : Color{0.3f, 0.7f, 1.0f}, 0.0f, 2);
        b.DrawRect(mouseWorld_, {10, 10}, {1.0f, 1.0f, 1.0f, 0.6f}, kPi / 4.0f, 3);

        // 입력 상태 표시등 (왼쪽 아래): Fire / Dash / 이동 4방향
        auto lamp = [&](float x, bool on, Color c) { b.DrawRect({-600.0f + x, -330.0f}, {22, 22}, on ? c : Color{0.2f, 0.2f, 0.25f}, 0.0f, 5); };
        lamp(0,   in.Down(fire_), {1.0f, 0.85f, 0.3f});
        lamp(30,  in.Down(dash_), {0.6f, 0.9f, 1.0f});
        lamp(60,  in.Value(moveX_) < 0.0f, {0.5f, 1.0f, 0.5f});
        lamp(90,  in.Value(moveX_) > 0.0f, {0.5f, 1.0f, 0.5f});
        lamp(120, in.Value(moveY_) > 0.0f, {0.5f, 1.0f, 0.5f});
        lamp(150, in.Value(moveY_) < 0.0f, {0.5f, 1.0f, 0.5f});
        if (rebinding_) b.DrawRect({0, 300}, {420, 10}, {1.0f, 0.4f, 0.4f, 1.0f}, 0.0f, 5);

        // 레벨 미터 (오른쪽 아래): 출력 피크 L/R + 볼륨(마스터/음악/효과음)
        Mixer& mx = app_->Audio().GetMixer();
        const Mixer::Levels pk = mx.PeakLevels();
        auto bar = [&](float x, float value, Color c) {
            const float h = 120.0f * Clamp(value, 0.0f, 1.0f);
            b.DrawRect({x, -270.0f}, {14, 120}, {0.15f, 0.15f, 0.2f}, 0.0f, 4);
            b.DrawRect({x, -330.0f + h * 0.5f}, {14, std::max(h, 1.0f)}, c, 0.0f, 5);
        };
        bar(420, pk.left,  pk.left  > 1.0f ? Color{1.0f, 0.3f, 0.3f} : Color{0.4f, 1.0f, 0.5f});
        bar(440, pk.right, pk.right > 1.0f ? Color{1.0f, 0.3f, 0.3f} : Color{0.4f, 1.0f, 0.5f});
        bar(480, mx.MasterVolume() / 1.5f, {0.9f, 0.9f, 0.9f});
        bar(500, mx.BusVolume(AudioBus::Music) / 1.5f, {0.8f, 0.5f, 1.0f});
        bar(520, mx.BusVolume(AudioBus::Sfx) / 1.5f, {1.0f, 0.8f, 0.4f});
        r.EndScene();
    }

    std::string StatusText() const override {
        Mixer& mx = app_->Audio().GetMixer();
        char buf[260];
        std::snprintf(buf, sizeof(buf), "audio %s | voices %d | music %s | vol M%.1f/B%.1f/S%.1f | reloads %d%s%s",
                      app_->Audio().HasDevice() ? "on" : "SILENT", mx.ActiveVoices(), musicOn_ ? "on" : "off",
                      static_cast<double>(mx.MasterVolume()), static_cast<double>(mx.BusVolume(AudioBus::Music)),
                      static_cast<double>(mx.BusVolume(AudioBus::Sfx)), reloads_,
                      rebindMsg_.empty() ? "" : " | ", rebindMsg_.c_str());
        return buf;
    }

private:
    void SetDefaultBindings() {
        InputManager& in = app_->Input();
        in.ClearBindings(fire_); in.ClearBindings(dash_); in.ClearBindings(moveX_); in.ClearBindings(moveY_);
        in.BindKey(fire_, KeyCode::Space);  in.BindMouse(fire_, MouseButton::Left);
        in.BindKey(dash_, KeyCode::LShift); in.BindKey(dash_, KeyCode::RShift);
        in.BindAxisKeys(moveX_, KeyCode::A, KeyCode::D);  in.BindAxisKeys(moveX_, KeyCode::Left, KeyCode::Right);
        in.BindAxisKeys(moveY_, KeyCode::S, KeyCode::W);  in.BindAxisKeys(moveY_, KeyCode::Down, KeyCode::Up);
    }

    Application* app_ = nullptr;
    Camera2D camera_;
    ActionId fire_, dash_;
    AxisId   moveX_, moveY_;
    Asset<AudioClip> blip_, whoosh_, thud_;
    std::string bindingsPath_, rebindMsg_;
    Vec2  player_{0, 0}, mouseWorld_{0, 0};
    float dashLeft_ = 0.0f, reloadTimer_ = 0.0f;
    int   reloads_ = 0;
    bool  musicOn_ = false, rebinding_ = false;
    std::vector<Bullet> bullets_;
    std::mt19937 rng_{99};
};

int main(int, char**) {
    ApplicationConfig cfg;
    cfg.window.title  = "Engine2D Phase 5 - Input / Audio";
    cfg.window.width  = 1280;
    cfg.window.height = 720;
    cfg.assetRoot     = "assets";
    cfg.logFile       = "engine_input_audio.log";

    Application app(cfg);
    InputAudioDemo game;
    return app.Run(game);
}
