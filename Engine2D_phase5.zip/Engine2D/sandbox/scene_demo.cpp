// Phase 4 데모: ECS · 씬 그래프 · 상태 머신 · 에셋 매니저(핫 리로드) · 물리 연결.
//   Space / 우클릭  커서 위치에 도형 생성      F  30개 생성      C  동적 물체 삭제      P  일시정지(스택 상태)   .  일시정지 중 한 스텝
//   H  badge.bmp 를 다시 써서 핫 리로드 시연 (왼쪽 위 계층 구조의 붉은 행성 위 배지 색이 실시간으로 바뀐다)
//   방향키 카메라   Q/E 회전   휠 줌   R 카메라 리셋   V vsync   ESC 종료
//   - 왼쪽: 태양 -> 행성 -> 달 계층 (부모 회전/스케일이 자식에게 전파됨). 붉은 행성은 스케일이 맥동한다.
//   - 가운데: 커서를 따라오는 사각형 = 엔티티 AI 상태 머신 (Idle -> Chase -> Attack).
//   - 아래: 물리 엔티티. 초록 영역(센서)을 지나면 번쩍이고, 강한 충돌은 링 이펙트(수명 컴포넌트)를 만든다.
#include <SDL.h>

#include <algorithm>
#include <cmath>
#include <cstdint>
#include <cstdio>
#include <filesystem>
#include <memory>
#include <random>
#include <string>
#include <vector>

#include "Core/Application.hpp"
#include "Core/Events.hpp"
#include "Core/Log.hpp"
#include "Renderer/Camera2D.hpp"
#include "Renderer/RenderLayer.hpp"
#include "Renderer/TextureAtlas.hpp"
#include "Scene/Scene.hpp"
#include "Scene/StateMachine.hpp"
#include "Systems/BehaviorSystem.hpp"
#include "Systems/PhysicsSystem.hpp"
#include "Systems/RenderSystem.hpp"
#include "Systems/StandardComponents.hpp"

using namespace engine;
namespace fs = std::filesystem;

namespace {

// ---- 이 데모에서 정의한 사용자 컴포넌트 ----------------------------------------------------------------------
struct Flash    { float t = 0.0f; Color base; };            // 센서 통과 시 번쩍임
struct Lifetime { float left = 0.0f, total = 0.0f; float startSize = 0.0f, growth = 0.0f; };

enum class GameState { Playing, Paused };
enum class AiState   { Idle, Chase, Attack };

constexpr int   kTile = 32, kCols = 3;
enum Tile { TCircle = 0, TBox = 1, TRing = 2 };
constexpr float kTileR = 0.9f;

bool TileInside(int tile, float x, float y) {
    const float d = std::sqrt(x * x + y * y);
    switch (tile) {
    case TCircle: return d <= kTileR;
    case TBox:    return std::fabs(x) <= kTileR && std::fabs(y) <= kTileR;
    default:      return d <= kTileR && d >= 0.72f;
    }
}

std::vector<std::uint8_t> BuildAtlasPixels() {
    const int W = kTile * kCols, H = kTile;
    std::vector<std::uint8_t> px(static_cast<std::size_t>(W * H * 4), 0);
    const float step = 2.0f / static_cast<float>(kTile);
    for (int t = 0; t < kCols; ++t) {
        for (int y = 0; y < kTile; ++y) {
            for (int x = 0; x < kTile; ++x) {
                const float nx = (static_cast<float>(x) + 0.5f) * step - 1.0f, ny = (static_cast<float>(y) + 0.5f) * step - 1.0f;
                if (!TileInside(t, nx, ny)) continue;
                const bool edge = !TileInside(t, nx - step, ny) || !TileInside(t, nx + step, ny) || !TileInside(t, nx, ny - step) || !TileInside(t, nx, ny + step);
                std::uint8_t v = edge ? 140 : 255;
                if (t == TCircle && !edge && ny > -0.09f && ny < 0.09f && nx > 0.0f) v = 170;     // 회전 표시 막대
                std::uint8_t* p = &px[static_cast<std::size_t>((y * W + t * kTile + x) * 4)];
                p[0] = p[1] = p[2] = v; p[3] = 255;
            }
        }
    }
    return px;
}

Color FromHue(float h) {
    const float r = Clamp(std::fabs(h * 6.0f - 3.0f) - 1.0f, 0.0f, 1.0f);
    const float g = Clamp(2.0f - std::fabs(h * 6.0f - 2.0f), 0.0f, 1.0f);
    const float b = Clamp(2.0f - std::fabs(h * 6.0f - 4.0f), 0.0f, 1.0f);
    return {0.35f + 0.65f * r, 0.35f + 0.65f * g, 0.35f + 0.65f * b, 1.0f};
}

// 32x32 배지 이미지(BMP): 배경색 + 흰 테두리. 색이 hue 로 정해져 H 키로 다시 쓰면 핫 리로드된다.
void WriteBadge(const std::string& path, float hue) {
    constexpr int N = 32;
    std::vector<std::uint8_t> px(N * N * 4);
    const Color c = FromHue(hue);
    for (int y = 0; y < N; ++y) {
        for (int x = 0; x < N; ++x) {
            const bool border = x < 3 || y < 3 || x >= N - 3 || y >= N - 3;
            const bool cross = std::abs(x - y) < 3 || std::abs(x + y - (N - 1)) < 3;
            std::uint8_t* p = &px[static_cast<std::size_t>((y * N + x) * 4)];
            if (border || cross) { p[0] = p[1] = p[2] = 255; }
            else { p[0] = static_cast<std::uint8_t>(c.r * 255.0f); p[1] = static_cast<std::uint8_t>(c.g * 255.0f); p[2] = static_cast<std::uint8_t>(c.b * 255.0f); }
            p[3] = 255;
        }
    }
    if (!SaveBMP(path, N, N, px.data())) ENGINE_LOG_WARN("could not write %s", path.c_str());
}

} // namespace

class SceneDemo final : public IGame {
public:
    bool OnInit(Application& app) override {
        app_ = &app;
        scene_.SetEventBus(&app.Events());
        world_.SetEventBus(&app.Events());
        physics_ = std::make_unique<PhysicsSystem>(scene_, world_, app.Events());

        // ---- 에셋: 절차적 아틀라스 등록 + 파일 텍스처 로드 ----
        auto atlas = std::make_unique<TextureAtlas>();
        const std::vector<std::uint8_t> px = BuildAtlasPixels();
        if (!atlas->CreateFromPixels(kTile * kCols, kTile, px.data(), TextureFilter::Linear)) return false;
        atlas->AddGrid(kCols, 1);
        atlas_ = app.Assets().Add<TextureAtlas>("atlas", std::move(atlas));

        std::error_code ec;
        fs::create_directories(app.Assets().Root(), ec);
        badgePath_ = app.Assets().Resolve("badge.bmp");
        WriteBadge(badgePath_, badgeHue_);
        badge_ = app.Assets().LoadTexture("badge.bmp", TextureFilter::Nearest);
        if (!badge_) return false;

        // ---- 입력 / 이벤트 ----
        auto& bus = app.Events();
        subs_.push_back(bus.Subscribe<KeyEvent>([this](const KeyEvent& e) { OnKey(e); }));
        subs_.push_back(bus.Subscribe<MouseMoveEvent>([this](const MouseMoveEvent& e) { mouse_ = {e.x, e.y}; }));
        subs_.push_back(bus.Subscribe<MouseWheelEvent>([this](const MouseWheelEvent& e) { targetZoom_ = Clamp(targetZoom_ * std::pow(1.15f, e.dy), 0.2f, 5.0f); }));
        subs_.push_back(bus.Subscribe<MouseButtonEvent>([this](const MouseButtonEvent& e) {
            if (e.button == 3 && e.pressed) Spawn(camera_.ScreenToWorld(e.x, e.y));
        }));
        // 물리 이벤트가 '엔티티' 이벤트로 번역되어 도착한다
        subs_.push_back(bus.Subscribe<EntityTriggerEnterEvent>([this](const EntityTriggerEnterEvent& e) {
            if (Flash* f = scene_.TryGet<Flash>(e.other)) f->t = 0.4f;
            ++triggers_;
        }));
        subs_.push_back(bus.Subscribe<EntityCollisionBeginEvent>([this](const EntityCollisionBeginEvent& e) {
            if (e.impactSpeed > 260.0f && ringCount_ < 150) SpawnRing(e.point, Clamp(e.impactSpeed / 900.0f, 0.3f, 1.0f));
        }));

        // ---- 상태 머신: 게임 상태 (Playing 위에 Paused 를 얹었다 내린다) ----
        game_.Define(GameState::Playing).onUpdate = [this](double dt) { Simulate(dt); };
        game_.Define(GameState::Paused);
        game_.Start(GameState::Playing);

        BuildWorld();
        BuildHierarchyDemo();
        BuildChaser();
        scene_.UpdateTransforms();
        ResetCamera();
        zoom_ = targetZoom_;
        ENGINE_LOG_INFO("Phase 4 demo ready - Space spawn, F burst, P pause, H hot-reload badge.bmp");
        return true;
    }

    void OnShutdown() override {
        scene_.Clear();                       // 이벤트로 물리 바디 정리
        badge_.Reset();
        atlas_.Reset();
    }

    void OnFixedUpdate(double dt) override {
        if (game_.Is(GameState::Paused) && stepOnce_) { Simulate(dt); stepOnce_ = false; }
        game_.Update(dt);
    }

    void OnVariableUpdate(double frameDt) override {
        const float dt = static_cast<float>(frameDt);
        camera_.SetViewport(app_->GetRenderer().ViewportWidth(), app_->GetRenderer().ViewportHeight());
        float mx = 0, my = 0;
        if (Key(SDL_SCANCODE_RIGHT)) mx += 1;
        if (Key(SDL_SCANCODE_LEFT))  mx -= 1;
        if (Key(SDL_SCANCODE_UP))    my += 1;
        if (Key(SDL_SCANCODE_DOWN))  my -= 1;
        const float c = std::cos(camera_.Rotation()), s = std::sin(camera_.Rotation());
        const float speed = 900.0f / zoom_ * dt;
        camera_.SetPosition(camera_.Position() + Vec2{(c * mx - s * my) * speed, (s * mx + c * my) * speed});
        float rot = camera_.Rotation();
        if (Key(SDL_SCANCODE_Q)) rot += 1.2f * dt;
        if (Key(SDL_SCANCODE_E)) rot -= 1.2f * dt;
        camera_.SetRotation(rot);
        zoom_ += (targetZoom_ - zoom_) * (1.0f - std::exp(-12.0f * dt));
        camera_.SetZoom(zoom_);
        mouseWorld_ = camera_.ScreenToWorld(mouse_.x, mouse_.y);

        // 핫 리로드: 0.5초마다 파일 수정 시각 확인
        reloadTimer_ += dt;
        if (reloadTimer_ > 0.5f) { reloadTimer_ = 0.0f; reloads_ += static_cast<int>(app_->Assets().ReloadChanged()); }
    }

    void OnRender(Renderer& r, double alpha) override {
        camera_.SetViewport(r.ViewportWidth(), r.ViewportHeight());
        const float a = game_.Is(GameState::Paused) ? 1.0f : static_cast<float>(alpha);    // 정지 중에는 보간하지 않음(깜빡임 방지)
        r.Clear(0.07f, 0.08f, 0.11f);
        r.BeginScene(camera_);
        DrawSprites(scene_, r.Batch(), a);
        r.EndScene();
    }

    std::string StatusText() const override {
        char buf[200];
        std::snprintf(buf, sizeof(buf), "%zu entities | %d bodies | AI: %s | game: %s | assets %zu (reloads %d) | triggers %d",
                      scene_.Count(), world_.Stats().bodies, AiName(), game_.Is(GameState::Paused) ? "PAUSED" : "playing",
                      app_->Assets().Count(), reloads_, triggers_);
        return buf;
    }

private:
    // ------------------------------------------------------------------ 시뮬레이션 1틱
    void Simulate(double dt) {
        const float fdt = static_cast<float>(dt);
        scene_.BeginTick();
        UpdateBehaviors(scene_, dt);                        // 계층 회전, AI 등
        world_.Step(fdt);
        physics_->SyncFromPhysics();

        scene_.Each<Flash, SpriteRenderer>([&](Entity, Flash& f, SpriteRenderer& sr) {
            if (f.t > 0.0f) f.t = std::max(0.0f, f.t - fdt);
            const float k = Clamp(f.t / 0.4f, 0.0f, 1.0f);
            sr.color = {Lerp(f.base.r, 1.0f, k), Lerp(f.base.g, 1.0f, k), Lerp(f.base.b, 1.0f, k), 1.0f};
        });
        scene_.Each<Lifetime, SpriteRenderer>([&](Entity e, Lifetime& l, SpriteRenderer& sr) {
            l.left -= fdt;
            const float k = Clamp(1.0f - l.left / l.total, 0.0f, 1.0f);
            const float d = l.startSize + l.growth * k;
            sr.size = {d, d};
            sr.color.a = (1.0f - k) * 0.9f;
            if (l.left <= 0.0f) { scene_.DestroyLater(e); --ringCount_; }        // 순회 중에는 예약만
        });

        scene_.UpdateTransforms();
        scene_.FlushDestroyed();
    }

    // ------------------------------------------------------------------ 월드 구성
    Entity MakeBox(const char* name, Vec2 pos, Vec2 half, Color color, BodyType type, bool sensor) {
        Entity e = scene_.Create(name, pos);
        SpriteRenderer sr;
        sr.texture = &atlas_->GetTexture();
        sr.region = atlas_->Region(TBox);
        sr.size = {2.0f * half.x / kTileR, 2.0f * half.y / kTileR};
        sr.color = color;
        sr.layer = sensor ? RenderLayer::Background + 5 : RenderLayer::Default - 10;
        scene_.Add<SpriteRenderer>(e, sr);
        BodyDef bd;
        bd.type = type;
        bd.shape = Shape::MakeBox(half.x, half.y);
        bd.isSensor = sensor;
        physics_->AttachBody(e, bd);
        return e;
    }

    void BuildWorld() {
        MakeBox("ground", {0, -420}, {900, 20}, {0.30f, 0.33f, 0.42f}, BodyType::Static, false);
        MakeBox("wall L", {-900, -50}, {20, 400}, {0.30f, 0.33f, 0.42f}, BodyType::Static, false);
        MakeBox("wall R", {900, -50}, {20, 400}, {0.30f, 0.33f, 0.42f}, BodyType::Static, false);
        MakeBox("sensor", {250, -380}, {160, 20}, {0.2f, 0.9f, 0.4f, 0.18f}, BodyType::Static, true);

        // 좌우로 왕복하는 키네마틱 발판: Behavior 가 바디 속도를 정한다 (Transform 은 SyncFromPhysics 가 따라감)
        Entity plat = MakeBox("platform", {-250, -280}, {110, 12}, {0.95f, 0.60f, 0.20f}, BodyType::Kinematic, false);
        auto dir = std::make_shared<float>(1.0f);
        Behavior b;
        b.onUpdate = [this, dir](Entity self, Scene& sc, double) {
            Body* body = world_.Get(physics_->BodyOf(self));
            const Transform* t = sc.TryGet<Transform>(self);
            if (!body || !t) return;
            if (t->position.x > 300.0f) *dir = -1.0f;
            if (t->position.x < -600.0f) *dir = 1.0f;
            body->velocity = {*dir * 130.0f, 0.0f};
        };
        scene_.Add<Behavior>(plat, b);
    }

    Entity MakeDisc(const char* name, Entity parent, Vec2 localPos, float diameter, Color color, int layer) {
        Entity e = scene_.Create(name, localPos, parent);
        SpriteRenderer sr;
        sr.texture = &atlas_->GetTexture();
        sr.region = atlas_->Region(TCircle);
        sr.size = {diameter / kTileR, diameter / kTileR};
        sr.color = color;
        sr.layer = layer;
        scene_.Add<SpriteRenderer>(e, sr);
        return e;
    }
    void Spin(Entity e, float speed) {
        Behavior b;
        b.onUpdate = [speed](Entity self, Scene& sc, double dt) { sc.Get<Transform>(self).rotation += speed * static_cast<float>(dt); };
        scene_.Add<Behavior>(e, b);
    }

    // 태양 -> 행성 -> 달 / 붉은 행성(스케일 맥동) -> 배지. 자식의 로컬 값은 고정, 부모만 돌고 커진다.
    void BuildHierarchyDemo() {
        const int L = RenderLayer::Default + 5;
        Entity sun = MakeDisc("sun", kNullEntity, {-450, 120}, 90, {1.0f, 0.85f, 0.25f}, L);
        Spin(sun, 0.35f);
        Entity planet = MakeDisc("planet", sun, {150, 0}, 44, {0.35f, 0.6f, 1.0f}, L + 1);
        Spin(planet, 1.4f);
        MakeDisc("moon", planet, {46, 0}, 18, {0.75f, 0.75f, 0.8f}, L + 2);
        Entity red = MakeDisc("red planet", sun, {-230, 0}, 34, {0.95f, 0.35f, 0.3f}, L + 1);
        Spin(red, -0.9f);
        auto pulse = std::make_shared<float>(0.0f);
        Behavior pb = scene_.Get<Behavior>(red);
        auto spinFn = pb.onUpdate;
        pb.onUpdate = [spinFn, pulse](Entity self, Scene& sc, double dt) {
            spinFn(self, sc, dt);
            *pulse += static_cast<float>(dt) * 2.0f;
            const float s = 1.0f + 0.35f * std::sin(*pulse);
            sc.Get<Transform>(self).scale = {s, s};         // 자식(배지)도 함께 커졌다 작아진다
        };
        scene_.Add<Behavior>(red, pb);

        Entity badge = scene_.Create("badge", {0, 0}, red);
        SpriteRenderer sr;
        sr.SetTexture(badge_);                              // 핫 리로드되는 에셋 핸들 (색이 바뀌어도 같은 텍스처 주소)
        sr.size = {26, 26};
        sr.layer = L + 3;
        scene_.Add<SpriteRenderer>(badge, sr);
        Spin(badge, 2.5f);
    }

    // 커서를 쫓는 엔티티: 상태 머신으로 행동을 전환
    struct Chaser {
        StateMachine<AiState> fsm;
        AiState shown = AiState::Idle;
    };

    void BuildChaser() {
        chaserEnt_ = scene_.Create("chaser", {0, 150});
        SpriteRenderer sr;
        sr.texture = &atlas_->GetTexture();
        sr.region = atlas_->Region(TBox);
        sr.size = {52, 52};
        sr.color = {0.6f, 0.6f, 0.65f};
        sr.layer = RenderLayer::Default + 10;
        scene_.Add<SpriteRenderer>(chaserEnt_, sr);
        scene_.Get<Transform>(chaserEnt_).rotation = kPi * 0.25f;

        chaser_ = std::make_shared<Chaser>();
        std::shared_ptr<Chaser> ch = chaser_;
        Entity self = chaserEnt_;
        auto dist = [this, self] { return (mouseWorld_ - scene_.Get<Transform>(self).position).Length(); };
        auto tint = [this, self](Color c) { scene_.Get<SpriteRenderer>(self).color = c; };
        auto timeFloat = [ch] { return static_cast<float>(ch->fsm.TimeInState()); };

        ch->fsm.Define(AiState::Idle).onEnter = [ch, tint] { ch->shown = AiState::Idle; tint({0.6f, 0.6f, 0.65f}); };
        ch->fsm.Define(AiState::Idle).onUpdate = [this, self, timeFloat](double) {           // 제자리에서 천천히 흔들림
            scene_.Get<Transform>(self).rotation = kPi * 0.25f + 0.25f * std::sin(timeFloat() * 3.0f);
        };
        ch->fsm.Define(AiState::Chase).onEnter = [ch, tint] { ch->shown = AiState::Chase; tint({1.0f, 0.65f, 0.2f}); };
        ch->fsm.Define(AiState::Chase).onUpdate = [this, self](double dt) {
            Transform& t = scene_.Get<Transform>(self);
            const Vec2 d = mouseWorld_ - t.position;
            t.position += Normalized(d) * (230.0f * static_cast<float>(dt));
            t.rotation += 6.0f * static_cast<float>(dt);
        };
        ch->fsm.Define(AiState::Attack).onEnter = [ch, tint] { ch->shown = AiState::Attack; tint({1.0f, 0.2f, 0.2f}); };
        ch->fsm.Define(AiState::Attack).onUpdate = [this, self, timeFloat](double) {         // 맥동
            const float s = 1.0f + 0.25f * std::sin(timeFloat() * 18.0f);
            scene_.Get<Transform>(self).scale = {s, s};
        };
        ch->fsm.Define(AiState::Attack).onExit = [this, self] { scene_.Get<Transform>(self).scale = {1, 1}; };
        ch->fsm.AddTransition(AiState::Idle,   AiState::Chase,  [dist] { return dist() < 380.0f; });
        ch->fsm.AddTransition(AiState::Chase,  AiState::Attack, [dist] { return dist() < 60.0f; });
        ch->fsm.AddTransition(AiState::Attack, AiState::Chase,  [dist] { return dist() > 95.0f; });
        ch->fsm.AddTransition(AiState::Chase,  AiState::Idle,   [dist] { return dist() > 480.0f; });
        ch->fsm.Start(AiState::Idle);

        Behavior b;
        b.onUpdate = [ch](Entity, Scene&, double dt) { ch->fsm.Update(dt); };
        scene_.Add<Behavior>(chaserEnt_, b);
    }

    // ------------------------------------------------------------------ 생성 / 삭제
    void Spawn(Vec2 pos) {
        if (world_.Stats().bodies > 1500) return;
        const int kind = static_cast<int>(rng_() % 3u);
        const float r = 10.0f + static_cast<float>(rng_() % 1000u) / 1000.0f * 22.0f;
        Entity e = scene_.Create("body", pos);
        SpriteRenderer sr;
        sr.texture = &atlas_->GetTexture();
        BodyDef bd;
        bd.restitution = 0.35f;
        if (kind == 0) { sr.region = atlas_->Region(TCircle); sr.size = {2 * r / kTileR, 2 * r / kTileR}; bd.shape = Shape::MakeCircle(r); }
        else if (kind == 1) { sr.region = atlas_->Region(TBox); sr.size = {2 * r / kTileR, 2 * r / kTileR}; bd.shape = Shape::MakeBox(r, r); }
        else { sr.region = atlas_->Region(TBox); sr.size = {3 * r / kTileR, r / kTileR}; bd.shape = Shape::MakeBox(1.5f * r, 0.5f * r); }
        sr.color = FromHue(static_cast<float>(rng_() % 1000u) / 1000.0f);
        scene_.Add<SpriteRenderer>(e, sr);
        scene_.Add<Flash>(e, Flash{0.0f, sr.color});
        bd.angularVelocity = (static_cast<float>(rng_() % 1000u) / 500.0f - 1.0f) * 3.0f;
        physics_->AttachBody(e, bd);
    }

    void SpawnRing(Vec2 p, float strength) {
        Entity e = scene_.Create("ring", p);
        SpriteRenderer sr;
        sr.texture = &atlas_->GetTexture();
        sr.region = atlas_->Region(TRing);
        sr.size = {24, 24};
        sr.color = {1.0f, 0.95f, 0.5f, 0.9f};
        sr.layer = RenderLayer::Foreground;
        scene_.Add<SpriteRenderer>(e, sr);
        scene_.Add<Lifetime>(e, Lifetime{0.35f, 0.35f, 24.0f, 90.0f * strength});
        ++ringCount_;
    }

    void ClearDynamic() {
        std::vector<Entity> victims;
        scene_.Each<Flash>([&](Entity e, Flash&) { victims.push_back(e); });
        for (Entity e : victims) scene_.DestroyLater(e);
        scene_.FlushDestroyed();                            // 연결된 물리 바디도 EntityDestroyedEvent 로 함께 삭제됨
    }

    // ------------------------------------------------------------------ 입력
    bool Key(int sc) const { return sc >= 0 && sc < 512 && keys_[sc]; }
    float Rand(float lo, float hi) { return lo + (hi - lo) * static_cast<float>(rng_() % 10000u) / 10000.0f; }

    void OnKey(const KeyEvent& e) {
        if (e.scancode >= 0 && e.scancode < 512) keys_[e.scancode] = e.pressed;
        if (!e.pressed || e.repeat) return;
        switch (e.scancode) {
        case SDL_SCANCODE_ESCAPE: app_->RequestQuit(); break;
        case SDL_SCANCODE_SPACE:  Spawn(mouseWorld_); break;
        case SDL_SCANCODE_F:      for (int i = 0; i < 30; ++i) Spawn({mouseWorld_.x + Rand(-120, 120), mouseWorld_.y + Rand(-80, 80)}); break;
        case SDL_SCANCODE_C:      ClearDynamic(); break;
        case SDL_SCANCODE_P:      if (game_.Is(GameState::Paused)) game_.Pop(); else game_.Push(GameState::Paused); break;
        case SDL_SCANCODE_PERIOD: if (game_.Is(GameState::Paused)) stepOnce_ = true; break;
        case SDL_SCANCODE_H:      badgeHue_ = std::fmod(badgeHue_ + 0.23f, 1.0f); WriteBadge(badgePath_, badgeHue_); break;
        case SDL_SCANCODE_R:      ResetCamera(); break;
        case SDL_SCANCODE_V:      vsync_ = !vsync_; app_->GetWindow().SetVSync(vsync_); break;
        default: break;
        }
    }

    void ResetCamera() { camera_.SetPosition({0, -100}); camera_.SetRotation(0.0f); targetZoom_ = 0.7f; }
    const char* AiName() const {
        switch (chaser_ ? chaser_->shown : AiState::Idle) { case AiState::Idle: return "Idle"; case AiState::Chase: return "Chase"; default: return "Attack"; }
    }

    Application* app_ = nullptr;
    Scene scene_;
    PhysicsWorld world_;
    std::unique_ptr<PhysicsSystem> physics_;
    StateMachine<GameState> game_;
    std::shared_ptr<Chaser> chaser_;
    Entity chaserEnt_;
    Asset<TextureAtlas> atlas_;
    Asset<Texture> badge_;
    std::string badgePath_;
    float badgeHue_ = 0.6f;

    Camera2D camera_;
    float zoom_ = 0.7f, targetZoom_ = 0.7f;
    Vec2 mouse_{0, 0}, mouseWorld_{0, 0};
    bool keys_[512] = {};
    bool stepOnce_ = false, vsync_ = true;
    float reloadTimer_ = 0.0f;
    int reloads_ = 0, triggers_ = 0, ringCount_ = 0;
    std::mt19937 rng_{12345};
    std::vector<Subscription> subs_;
};

int main(int, char**) {
    ApplicationConfig cfg;
    cfg.window.title  = "Engine2D Phase 4 - Scene / ECS / FSM / Assets";
    cfg.window.width  = 1280;
    cfg.window.height = 720;
    cfg.assetRoot     = "assets";
    cfg.logFile       = "engine_scene.log";

    Application app(cfg);
    SceneDemo game;
    return app.Run(game);
}
