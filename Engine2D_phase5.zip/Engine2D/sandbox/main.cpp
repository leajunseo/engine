// Phase 3 데모: 2D 강체 물리 (원/박스/다각형 충돌, 쿼드트리 브로드페이즈, 순차 임펄스 솔버).
//   마우스 좌클릭 드래그  물체 잡아 끌기        Space / 우클릭  커서 위치에 도형 1개 생성      F  50개 생성
//   C  동적 물체 모두 삭제     G  중력 on/off      P  일시정지 (. 키: 한 스텝)       D  디버그(쿼드트리/접촉점) 토글
//   방향키 카메라 이동   Q/E 회전   휠 줌   R 카메라 리셋   V vsync   ESC 종료
//   초록 영역 = 센서(트리거): 통과하는 물체가 번쩍인다.  강한 충돌은 CollisionBeginEvent 로 받아 링 이펙트를 그린다.
#include <SDL.h>     // SDL_main(Windows) + SDL_SCANCODE_* (Phase 5 에서 엔진 KeyCode 로 대체)

#include <algorithm>
#include <cmath>
#include <cstdint>
#include <cstdio>
#include <random>
#include <string>
#include <unordered_map>
#include <vector>

#include "Core/Application.hpp"
#include "Core/Events.hpp"
#include "Core/Log.hpp"
#include "Physics/PhysicsWorld.hpp"
#include "Renderer/Camera2D.hpp"
#include "Renderer/RenderLayer.hpp"
#include "Renderer/TextureAtlas.hpp"

using namespace engine;

namespace {

constexpr float kHalfW = 800.0f, kHalfH = 450.0f;       // 아레나 내부 절반 크기
constexpr float kStartZoom = 0.75f;
constexpr int   kMaxDynamic = 2000;           // Debug 빌드는 Release 보다 훨씬 느려서 보수적으로 제한

// ---- 절차적 아틀라스: 32x32 타일 8개 (4열 x 2행). 흰색 + 회색 외곽선 -> 색은 Sprite::color 로 틴트 ----------
constexpr int kTile = 32, kCols = 4, kRows = 2;
enum Tile { TCircle = 0, TBox = 1, TTri = 2, TPent = 3, THex = 4, TRing = 5 };
constexpr float kTileR = 0.9f;                           // 타일 좌표(-1..1)에서 도형의 반지름. 스프라이트 크기 = 2R / 0.9

int PolySides(int tile) { return tile == TTri ? 3 : tile == TPent ? 5 : 6; }

bool TileInside(int tile, float x, float y) {            // x,y ∈ [-1,1], y 는 아래가 +
    switch (tile) {
    case TCircle: return std::sqrt(x * x + y * y) <= kTileR;
    case TBox:    return std::fabs(x) <= kTileR && std::fabs(y) <= kTileR;
    case TRing: { const float d = std::sqrt(x * x + y * y); return d <= kTileR && d >= 0.72f; }
    default: {                                           // 정다각형, 꼭짓점 0 이 위쪽 (물리 Shape::MakeRegularPolygon 과 동일)
        const int n = PolySides(tile);
        const float px = x, py = -y;                     // Y-up 으로
        const float apothem = kTileR * std::cos(kPi / static_cast<float>(n));
        for (int k = 0; k < n; ++k) {
            const float phi = kPi * 0.5f + 2.0f * kPi * static_cast<float>(k) / static_cast<float>(n) + kPi / static_cast<float>(n);
            if (px * std::cos(phi) + py * std::sin(phi) > apothem) return false;
        }
        return true;
    }
    }
}

std::vector<std::uint8_t> BuildAtlasPixels() {
    const int W = kTile * kCols, H = kTile * kRows;
    std::vector<std::uint8_t> px(static_cast<std::size_t>(W * H * 4), 0);
    const float step = 2.0f / static_cast<float>(kTile);
    for (int t = 0; t < kCols * kRows; ++t) {
        const int ox = (t % kCols) * kTile, oy = (t / kCols) * kTile;
        for (int y = 0; y < kTile; ++y) {
            for (int x = 0; x < kTile; ++x) {
                const float nx = (static_cast<float>(x) + 0.5f) * step - 1.0f;
                const float ny = (static_cast<float>(y) + 0.5f) * step - 1.0f;
                if (t > TRing || !TileInside(t, nx, ny)) continue;
                const bool edge = !TileInside(t, nx - step, ny) || !TileInside(t, nx + step, ny) ||
                                  !TileInside(t, nx, ny - step) || !TileInside(t, nx, ny + step);
                std::uint8_t v = edge ? 140 : 255;
                // 회전을 눈으로 확인할 수 있게 원 타일에는 중심에서 오른쪽으로 뻗는 막대를 그린다
                if (t == TCircle && !edge && ny > -0.09f && ny < 0.09f && nx > 0.0f) v = 170;
                std::uint8_t* p = &px[static_cast<std::size_t>(((oy + y) * W + (ox + x)) * 4)];
                p[0] = p[1] = p[2] = v; p[3] = 255;
            }
        }
    }
    return px;
}

Color FromHue(float h) {
    const float r = Clamp(std::fabs(h * 6.0f - 3.0f) - 1.0f, 0.0f, 1.0f);
    const float g = Clamp(2.0f - std::fabs(h * 6.0f - 2.0f), 0.0f, 1.0f);
    const float b = Clamp(2.0f - std::fabs(h * 6.0f - 4.0f), 0.0f, 1.0f);
    return {0.35f + 0.65f * r, 0.35f + 0.65f * g, 0.35f + 0.65f * b, 1.0f};
}

void DrawLine(SpriteBatch& batch, Vec2 a, Vec2 b, float thickness, Color c, int layer) {
    const Vec2 d = b - a;
    const float len = d.Length();
    if (len < 1e-4f) return;
    batch.DrawRect((a + b) * 0.5f, {len, thickness}, c, std::atan2(d.y, d.x), layer);
}

struct Pulse { Vec2 pos; float age; float strength; };

} // namespace

class DemoGame final : public IGame {
public:
    bool OnInit(Application& app) override {
        app_ = &app;
        const std::vector<std::uint8_t> px = BuildAtlasPixels();
        if (!atlas_.CreateFromPixels(kTile * kCols, kTile * kRows, px.data(), TextureFilter::Linear)) return false;
        atlas_.AddGrid(kCols, kRows);

        world_.SetEventBus(&app.Events());
        subs_.push_back(app.Events().Subscribe<KeyEvent>([this](const KeyEvent& e) { OnKey(e); }));
        subs_.push_back(app.Events().Subscribe<MouseMoveEvent>([this](const MouseMoveEvent& e) { mouse_ = {e.x, e.y}; }));
        subs_.push_back(app.Events().Subscribe<MouseWheelEvent>([this](const MouseWheelEvent& e) {
            targetZoom_ = Clamp(targetZoom_ * std::pow(1.15f, e.dy), 0.1f, 6.0f);
        }));
        subs_.push_back(app.Events().Subscribe<MouseButtonEvent>([this](const MouseButtonEvent& e) { OnMouseButton(e); }));

        // 물리 이벤트: 강한 충돌 -> 링 이펙트, 센서 통과 -> 번쩍임
        subs_.push_back(app.Events().Subscribe<CollisionBeginEvent>([this](const CollisionBeginEvent& e) {
            ++collisionCount_;
            if (e.impactSpeed > 250.0f && pulses_.size() < 200) pulses_.push_back({e.point, 0.0f, Clamp(e.impactSpeed / 900.0f, 0.2f, 1.0f)});
        }));
        subs_.push_back(app.Events().Subscribe<TriggerEnterEvent>([this](const TriggerEnterEvent& e) {
            ++triggerCount_;
            flash_[e.other.index] = 0.35f;
        }));

        ResetCamera();
        zoom_ = targetZoom_;
        BuildScene();
        ENGINE_LOG_INFO("Phase 3 demo ready - LMB drag, Space spawn, F burst, D debug, G gravity, C clear, P pause");
        return true;
    }

    void OnShutdown() override { atlas_.Destroy(); }

    // 고정 틱: 입력 반영(드래그 스프링, 키네마틱 발판) -> 물리 스텝
    void OnFixedUpdate(double dt) override {
        const float fdt = static_cast<float>(dt);
        if (paused_ && !stepOnce_) return;
        stepOnce_ = false;

        if (Body* plat = world_.Get(platform_)) {                // 좌우로 왕복하는 키네마틱 발판
            if (plat->position.x > 450.0f) platDir_ = -1.0f;
            if (plat->position.x < -450.0f) platDir_ = 1.0f;
            plat->velocity = {platDir_ * 140.0f, 0.0f};
        }
        if (drag_.Valid()) {
            if (Body* b = world_.Get(drag_)) {
                const Vec2 anchor = b->xf.Apply(dragLocal_);
                const Vec2 vAnchor = b->velocity + Cross(b->angularVelocity, anchor - b->position);
                Vec2 f = (mouseWorld_ - anchor) * (b->mass * 120.0f) - vAnchor * (b->mass * 12.0f);   // 질량에 비례한 스프링-댐퍼
                const float maxF = b->mass * 60000.0f;
                if (f.Length() > maxF) f = Normalized(f) * maxF;
                world_.ApplyForceAtPoint(drag_, f, anchor);
            } else {
                drag_ = BodyId{};
            }
        }
        world_.Step(fdt);
    }

    void OnVariableUpdate(double frameDt) override {
        const float dt = static_cast<float>(frameDt);
        camera_.SetViewport(app_->GetRenderer().ViewportWidth(), app_->GetRenderer().ViewportHeight());

        float mx = 0, my = 0;
        if (Key(SDL_SCANCODE_RIGHT)) mx += 1;
        if (Key(SDL_SCANCODE_LEFT))  mx -= 1;
        if (Key(SDL_SCANCODE_UP))    my += 1;
        if (Key(SDL_SCANCODE_DOWN))  my -= 1;
        const float c = std::cos(camera_.Rotation()), s = std::sin(camera_.Rotation());
        const float speed = 900.0f / zoom_ * dt;
        camera_.SetPosition(camera_.Position() + Vec2{(c * mx - s * my) * speed, (s * mx + c * my) * speed});

        float rot = camera_.Rotation();
        if (Key(SDL_SCANCODE_Q)) rot += 1.2f * dt;
        if (Key(SDL_SCANCODE_E)) rot -= 1.2f * dt;
        camera_.SetRotation(rot);
        zoom_ += (targetZoom_ - zoom_) * (1.0f - std::exp(-12.0f * dt));
        camera_.SetZoom(zoom_);

        mouseWorld_ = camera_.ScreenToWorld(mouse_.x, mouse_.y);

        for (Pulse& p : pulses_) p.age += dt;
        pulses_.erase(std::remove_if(pulses_.begin(), pulses_.end(), [](const Pulse& p) { return p.age > 0.35f; }), pulses_.end());
        for (auto it = flash_.begin(); it != flash_.end();) {
            it->second -= dt;
            it = it->second <= 0.0f ? flash_.erase(it) : std::next(it);
        }
    }

    void OnRender(Renderer& r, double alpha) override {
        camera_.SetViewport(r.ViewportWidth(), r.ViewportHeight());
        const float a = static_cast<float>(alpha);
        r.Clear(0.07f, 0.08f, 0.11f);
        r.BeginScene(camera_);
        SpriteBatch& batch = r.Batch();
        const Texture* tex = &atlas_.GetTexture();

        world_.ForEachBody([&](BodyId id, const Body& b) {
            const Vec2 pos = PhysicsWorld::InterpolatedPosition(b, a);
            const float rot = PhysicsWorld::InterpolatedRotation(b, a);

            if (b.type != BodyType::Dynamic) {                   // 정적/키네마틱/센서: 단색 사각형 (큰 도형이라 타일 외곽선 대신)
                Color col = b.type == BodyType::Static ? Color{0.30f, 0.33f, 0.42f} : Color{0.95f, 0.60f, 0.20f};
                int layer = RenderLayer::Default - 10;
                if (b.isSensor) { col = {0.2f, 0.9f, 0.4f, 0.16f}; layer = RenderLayer::Background + 5; }
                batch.DrawRect(pos, {b.shape.halfExtents.x * 2.0f, b.shape.halfExtents.y * 2.0f}, col, rot, layer);
                return;
            }
            Sprite s;
            s.texture = tex;
            s.layer = RenderLayer::Default;
            s.position = pos;
            s.rotation = rot;
            Color col = FromHue(static_cast<float>((id.index * 2654435761u) % 1000u) / 1000.0f);
            if (auto f = flash_.find(id.index); f != flash_.end()) {
                const float k = Clamp(f->second / 0.35f, 0.0f, 1.0f);
                col = {Lerp(col.r, 1.0f, k), Lerp(col.g, 1.0f, k), Lerp(col.b, 1.0f, k), 1.0f};
            }
            s.color = col;
            if (b.shape.type == ShapeType::Circle) {
                s.region = atlas_.Region(TCircle);
                s.size = {2.0f * b.shape.radius / kTileR, 2.0f * b.shape.radius / kTileR};
            } else if (b.shape.type == ShapeType::Box) {
                s.region = atlas_.Region(TBox);
                s.size = {2.0f * b.shape.halfExtents.x / kTileR, 2.0f * b.shape.halfExtents.y / kTileR};
            } else {
                const int tile = b.shape.count == 3 ? TTri : b.shape.count == 5 ? TPent : THex;
                s.region = atlas_.Region(tile);
                float R = 0.0f;                                  // 외접 반지름 (정다각형이라 모든 꼭짓점이 같은 거리)
                for (int i = 0; i < b.shape.count; ++i) R = std::max(R, b.shape.verts[i].Length());
                s.size = {2.0f * R / kTileR, 2.0f * R / kTileR};
            }
            batch.Draw(s);
        });

        const float line = 1.5f / zoom_;

        // 충돌 이벤트 링
        for (const Pulse& p : pulses_) {
            const float k = p.age / 0.35f;
            Sprite ring;
            ring.texture = tex;
            ring.region = atlas_.Region(TRing);
            ring.position = p.pos;
            const float d = (24.0f + 90.0f * p.strength * k);
            ring.size = {d, d};
            ring.color = {1.0f, 0.95f, 0.5f, (1.0f - k) * 0.9f};
            ring.layer = RenderLayer::Foreground;
            batch.Draw(ring);
        }

        // 드래그 선
        if (drag_.Valid()) {
            if (const Body* b = world_.Get(drag_))
                DrawLine(batch, b->xf.Apply(dragLocal_), mouseWorld_, 2.0f / zoom_, {1.0f, 0.9f, 0.2f, 1.0f}, RenderLayer::Overlay);
        }

        // 디버그: 쿼드트리 셀, 접촉점/법선
        if (debug_) {
            world_.Tree().ForEachNode([&](const AABB& bb, int depth, int items) {
                const float t = Clamp(static_cast<float>(depth) / 6.0f, 0.0f, 1.0f);
                const Color c{0.25f + 0.2f * t, 0.55f - 0.2f * t, 0.9f, items > 0 ? 0.55f : 0.18f};
                const Vec2 lo = bb.min, hi = bb.max;
                DrawLine(batch, {lo.x, lo.y}, {hi.x, lo.y}, line, c, RenderLayer::Foreground + 1);
                DrawLine(batch, {hi.x, lo.y}, {hi.x, hi.y}, line, c, RenderLayer::Foreground + 1);
                DrawLine(batch, {hi.x, hi.y}, {lo.x, hi.y}, line, c, RenderLayer::Foreground + 1);
                DrawLine(batch, {lo.x, hi.y}, {lo.x, lo.y}, line, c, RenderLayer::Foreground + 1);
            });
            for (const auto& ci : world_.Contacts()) {
                for (int i = 0; i < ci.manifold.count; ++i) {
                    const Vec2 p = ci.manifold.points[i].position;
                    batch.DrawRect(p, {5.0f / zoom_, 5.0f / zoom_}, {1.0f, 0.25f, 0.25f, 1.0f}, 0.0f, RenderLayer::Overlay);
                    DrawLine(batch, p, p + ci.manifold.normal * (18.0f / zoom_), line, {1.0f, 0.8f, 0.2f, 1.0f}, RenderLayer::Overlay);
                }
            }
        }

        // 커서 링 (화면 기준 크기 고정)
        Sprite cur;
        cur.texture = tex;
        cur.region = atlas_.Region(TRing);
        cur.position = mouseWorld_;
        cur.size = {36.0f / zoom_, 36.0f / zoom_};
        cur.color = {1.0f, 1.0f, 1.0f, 0.8f};
        cur.layer = RenderLayer::Overlay + 1;
        batch.Draw(cur);

        r.EndScene();
    }

    std::string StatusText() const override {
        const PhysicsStats& st = world_.Stats();
        char buf[160];
        std::snprintf(buf, sizeof(buf), "%d bodies | %d contacts | %d pairs | physics %.2f ms | hits %d | trigger %d%s%s",
                      st.bodies, st.contacts, st.broadPairs, st.stepMs, collisionCount_, triggerCount_,
                      debug_ ? " | debug" : "", paused_ ? " | PAUSED" : "");
        return buf;
    }

private:
    bool Key(int scancode) const { return scancode >= 0 && scancode < 512 && keys_[scancode]; }

    void OnKey(const KeyEvent& e) {
        if (e.scancode >= 0 && e.scancode < 512) keys_[e.scancode] = e.pressed;
        if (!e.pressed || e.repeat) return;
        switch (e.scancode) {
        case SDL_SCANCODE_ESCAPE: app_->RequestQuit(); break;
        case SDL_SCANCODE_SPACE:  SpawnRandom(mouseWorld_); break;
        case SDL_SCANCODE_F:      for (int i = 0; i < 50; ++i) SpawnRandom({mouseWorld_.x + Rand(-120, 120), mouseWorld_.y + Rand(-80, 80)}); break;
        case SDL_SCANCODE_C:      ClearDynamic(); break;
        case SDL_SCANCODE_G:      gravityOn_ = !gravityOn_; world_.Settings().gravity = gravityOn_ ? Vec2{0, -980} : Vec2{0, 0}; break;
        case SDL_SCANCODE_P:      paused_ = !paused_; break;
        case SDL_SCANCODE_PERIOD: if (paused_) stepOnce_ = true; break;
        case SDL_SCANCODE_D:      debug_ = !debug_; break;
        case SDL_SCANCODE_R:      ResetCamera(); break;
        case SDL_SCANCODE_V:      vsync_ = !vsync_; app_->GetWindow().SetVSync(vsync_); break;
        default: break;
        }
    }

    void OnMouseButton(const MouseButtonEvent& e) {
        const Vec2 wp = camera_.ScreenToWorld(e.x, e.y);
        if (e.button == 1) {
            if (e.pressed) {
                drag_ = world_.PickBody(wp);
                if (const Body* b = world_.Get(drag_)) dragLocal_ = b->xf.ApplyInverse(wp);
            } else {
                drag_ = BodyId{};
            }
        } else if (e.button == 3 && e.pressed) {
            SpawnRandom(wp);
        }
    }

    float Rand(float lo, float hi) { return std::uniform_real_distribution<float>(lo, hi)(rng_); }

    void ResetCamera() { camera_.SetPosition({0, 0}); camera_.SetRotation(0); targetZoom_ = kStartZoom; }

    BodyId AddStatic(Vec2 pos, Vec2 half, float rot = 0.0f) {
        BodyDef d;
        d.type = BodyType::Static;
        d.shape = Shape::MakeBox(half.x, half.y);
        d.position = pos;
        d.rotation = rot;
        d.friction = 0.6f;
        d.restitution = 0.2f;
        return world_.CreateBody(d);
    }

    void BuildScene() {
        world_.Clear();
        drag_ = BodyId{};
        // 아레나 (안쪽 면이 x=±800, y=±450)
        AddStatic({0, -kHalfH - 30}, {kHalfW + 60, 30});
        AddStatic({0,  kHalfH + 30}, {kHalfW + 60, 30});
        AddStatic({-kHalfW - 30, 0}, {30, kHalfH + 60});
        AddStatic({ kHalfW + 30, 0}, {30, kHalfH + 60});
        // 경사로 (회전된 정적 박스 -> SAT 클리핑 경로)
        AddStatic({-420, -170}, {260, 12}, -0.38f);
        AddStatic({ 440, -260}, {260, 12},  0.30f);

        BodyDef plat;                                           // 움직이는 발판 (키네마틱)
        plat.type = BodyType::Kinematic;
        plat.shape = Shape::MakeBox(130, 12);
        plat.position = {0, -330};
        plat.friction = 0.9f;
        platform_ = world_.CreateBody(plat);
        platDir_ = 1.0f;

        BodyDef zone;                                           // 센서 (충돌 없이 감지만)
        zone.type = BodyType::Static;
        zone.isSensor = true;
        zone.shape = Shape::MakeBox(110, 90);
        zone.position = {0, 120};
        world_.CreateBody(zone);

        for (int i = 0; i < 260; ++i) SpawnRandom({Rand(-700, 700), Rand(-50, 420)});
    }

    void ClearDynamic() {
        std::vector<BodyId> kill;
        world_.ForEachBody([&](BodyId id, const Body& b) { if (b.type == BodyType::Dynamic) kill.push_back(id); });
        for (BodyId id : kill) world_.DestroyBody(id);
        flash_.clear();
        pulses_.clear();
        drag_ = BodyId{};
    }

    void SpawnRandom(Vec2 pos) {
        if (world_.Stats().bodies >= kMaxDynamic) return;
        BodyDef d;
        d.position = pos;
        d.rotation = Rand(0.0f, 2.0f * kPi);
        d.velocity = {Rand(-80, 80), Rand(-80, 80)};
        d.angularVelocity = Rand(-2, 2);
        d.restitution = Rand(0.1f, 0.6f);
        d.friction = Rand(0.3f, 0.8f);
        const float size = Rand(10.0f, 26.0f);
        switch (std::uniform_int_distribution<int>(0, 4)(rng_)) {
        case 0: d.shape = Shape::MakeCircle(size); break;
        case 1: d.shape = Shape::MakeBox(size, size * Rand(0.5f, 1.2f)); break;
        case 2: d.shape = Shape::MakeRegularPolygon(3, size * 1.15f); break;
        case 3: d.shape = Shape::MakeRegularPolygon(5, size * 1.1f); break;
        default: d.shape = Shape::MakeRegularPolygon(6, size * 1.05f); break;
        }
        world_.CreateBody(d);
    }

    Application*              app_ = nullptr;
    TextureAtlas              atlas_;
    Camera2D                  camera_;
    PhysicsWorld              world_;
    std::vector<Subscription> subs_;
    std::mt19937              rng_{2026};
    Vec2                      mouse_{0, 0}, mouseWorld_{0, 0};
    float                     zoom_ = kStartZoom, targetZoom_ = kStartZoom;
    bool                      keys_[512] = {};
    bool                      vsync_ = true, debug_ = false, paused_ = false, stepOnce_ = false, gravityOn_ = true;

    BodyId                    platform_, drag_;
    Vec2                      dragLocal_{0, 0};
    float                     platDir_ = 1.0f;
    std::vector<Pulse>        pulses_;
    std::unordered_map<std::uint32_t, float> flash_;
    int                       collisionCount_ = 0, triggerCount_ = 0;
};

int main(int, char**) {
    ApplicationConfig cfg;
    cfg.window.title  = "Engine2D Sandbox";
    cfg.window.width  = 1280;
    cfg.window.height = 720;

    Application app(cfg);
    DemoGame game;
    return app.Run(game);
}
