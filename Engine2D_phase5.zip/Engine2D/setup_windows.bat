@echo off
REM Installs vcpkg to C:\vcpkg and sets VCPKG_ROOT. Run once.
if exist C:\vcpkg\vcpkg.exe goto setenv
where git >nul 2>nul
if errorlevel 1 goto nogit
git clone https://github.com/microsoft/vcpkg C:\vcpkg
if errorlevel 1 goto err
call C:\vcpkg\bootstrap-vcpkg.bat -disableMetrics
if errorlevel 1 goto err
:setenv
setx VCPKG_ROOT C:\vcpkg >nul
echo.
echo Done. Close Visual Studio completely, reopen it, then open this folder.
pause
exit /b 0
:nogit
echo git was not found. Install Git for Windows first: https://git-scm.com/download/win
pause
exit /b 1
:err
echo Failed. Check your internet connection and try again.
pause
exit /b 1
