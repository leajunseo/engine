# Engine2D — Phase 5 (Core + 2D 렌더러 + 물리 + 씬/ECS/에셋 + 입력/오디오)

## 실행 대상
- `sandbox` : Phase 3 물리 샌드박스
- `scene_demo` : **Phase 4 데모** — 태양/행성/달 계층 변환, 엔티티 AI 상태 머신(Idle→Chase→Attack), 물리 엔티티·센서·이펙트, `badge.bmp` 핫 리로드(H 키)
- `input_audio_demo` : **Phase 5 데모** — 액션/축 입력, 리바인드·저장, 효과음(팬/피치), 버스 볼륨, 스트리밍 음악, 레벨 미터
- `physics_tests`, `scene_tests`, `input_tests`, `audio_tests` : 창/GL/사운드카드 없이 도는 단위 테스트 (`ctest` 로 한 번에)

### sandbox 조작
 좌클릭 드래그 물체 잡기 · Space/우클릭 도형 생성 · F 50개 생성 · C 삭제 · G 중력 · P 일시정지(`.` 한 스텝)
· D 디버그(쿼드트리/접촉점) · 방향키 카메라 이동 · Q/E 회전 · 휠 줌 · R 카메라 리셋 · V vsync · ESC 종료

### scene_demo 조작
Space/우클릭 도형 생성 · F 30개 생성 · C 동적 물체 삭제 · P 일시정지(스택 상태, `.` 한 스텝) · H 배지 핫 리로드 · 방향키/Q/E/휠/R 카메라 · V vsync · ESC 종료

### input_audio_demo 조작
WASD/방향키 이동 · Space/마우스 왼쪽 발사 · Shift 대시 · M 음악 on/off · `-` `=` 마스터 볼륨 · `,` `.` 음악 볼륨 · `;` `'` 효과음 볼륨
· **F2** Fire 리바인드(다음에 누르는 키) · F3 바인딩 저장 · F4 불러오기 · F5 기본값 · ESC 종료
(소리는 코드로 합성해 `assets/` 에 WAV 로 저장. `assets/blip.wav` 를 다른 WAV 로 덮어쓰면 실행 중 핫 리로드. 소리 장치가 없으면 무음으로 계속 실행)

단위 테스트(창 불필요): `physics_tests`, `scene_tests`, `input_tests`, `audio_tests` 실행 (VS 시작 항목에서 선택) 또는 `ctest`.

이미지: BMP/TGA 는 내장 디코더로 항상 읽힘. PNG/JPG 등은 `stb`(vcpkg.json 에 포함) 가 있으면 자동 활성화(`ENGINE_HAS_STB`).

## Windows (Visual Studio 2026)
1. VS 설치 관리자에서 **"C++를 사용한 데스크톱 개발"** 워크로드 + **CMake 도구** 구성요소 확인 (git 필요)
2. `setup_windows.bat` 더블클릭 (vcpkg 를 C:\vcpkg 에 설치하고 VCPKG_ROOT 설정; 이미 vcpkg 가 있으면 `setx VCPKG_ROOT <경로>` 만 해도 됨)
3. **VS 를 완전히 종료 후 재실행** → 파일 > 열기 > 폴더 → 이 폴더
4. 상단 구성 `Debug`(windows-x64-debug), 시작 항목 `sandbox` → F5
   - 첫 구성 때 vcpkg 가 SDL2/GLEW 를 빌드하느라 몇 분 걸립니다(출력 창 "CMake" 확인).
   - 구성이 꼬이면: 프로젝트 > CMake 캐시 삭제 및 다시 구성
   - 창이 안 뜨면 실행 폴더의 `engine.log` 확인 (OpenGL 3.3 core 필요)

## Linux / macOS
```bash
# Ubuntu: sudo apt install build-essential cmake libsdl2-dev libglew-dev
# macOS : brew install cmake sdl2 glew
cmake -S . -B build -DCMAKE_BUILD_TYPE=Debug && cmake --build build -j && ./build/sandbox
```
아키텍처는 `docs/ARCHITECTURE.md` 참고.
