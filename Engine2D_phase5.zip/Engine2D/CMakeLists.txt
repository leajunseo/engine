cmake_minimum_required(VERSION 3.21)

# vcpkg 툴체인 자동 탐색 (project() 보다 먼저 와야 한다).
#  1) 프리셋/명령줄에서 CMAKE_TOOLCHAIN_FILE 을 줬으면 그대로 사용
#  2) C:/vcpkg (setup_windows.bat 이 설치) - VS 2026 번들 vcpkg 는 git 저장소가 아니라 매니페스트 모드가 실패하기 쉬워 우선한다
#  3) 환경변수 VCPKG_ROOT
if(NOT CMAKE_TOOLCHAIN_FILE)
  if(WIN32 AND EXISTS "C:/vcpkg/scripts/buildsystems/vcpkg.cmake")
    set(CMAKE_TOOLCHAIN_FILE "C:/vcpkg/scripts/buildsystems/vcpkg.cmake" CACHE STRING "" FORCE)
    set(ENV{VCPKG_ROOT} "C:/vcpkg")
  elseif(DEFINED ENV{VCPKG_ROOT} AND EXISTS "$ENV{VCPKG_ROOT}/scripts/buildsystems/vcpkg.cmake")
    set(CMAKE_TOOLCHAIN_FILE "$ENV{VCPKG_ROOT}/scripts/buildsystems/vcpkg.cmake" CACHE STRING "" FORCE)
  endif()
endif()

project(Engine2D VERSION 0.5.0 LANGUAGES CXX)

set(CMAKE_CXX_STANDARD 17)
set(CMAKE_CXX_STANDARD_REQUIRED ON)
set(CMAKE_CXX_EXTENSIONS OFF)
if(NOT CMAKE_BUILD_TYPE AND NOT CMAKE_CONFIGURATION_TYPES)
  set(CMAKE_BUILD_TYPE RelWithDebInfo)
endif()

if(MSVC)
  add_compile_options(/utf-8)          # 소스가 UTF-8(한글 주석) -> 한국어 Windows(CP949)에서 깨짐/C4819 방지
endif()
if(WIN32 AND NOT CMAKE_TOOLCHAIN_FILE)
  message(FATAL_ERROR "vcpkg 를 찾지 못했습니다. README 의 'Windows' 절차(setup_windows.bat)를 먼저 실행하세요.")
endif()

find_package(SDL2 REQUIRED)          # SDL2::SDL2 타깃 (SDL2 2.0.12+)
find_package(GLEW REQUIRED)          # GLEW::GLEW
find_package(OpenGL REQUIRED)        # OpenGL::GL
find_package(Threads REQUIRED)
find_path(STB_INCLUDE_DIR stb_image.h)   # 선택: 있으면 PNG/JPG 등 로드 (vcpkg 'stb')

# ---------------------------------------------------------------- engine
add_library(engine STATIC
  engine/Core/Log.cpp
  engine/Core/Window.cpp
  engine/Core/Application.cpp
  engine/Renderer/Renderer.cpp
  engine/Renderer/Shader.cpp
  engine/Renderer/Texture.cpp
  engine/Renderer/TextureAtlas.cpp
  engine/Renderer/Camera2D.cpp
  engine/Renderer/SpriteBatch.cpp
  engine/Physics/Collision.cpp
  engine/Physics/Quadtree.cpp
  engine/Physics/PhysicsWorld.cpp
  engine/Scene/Scene.cpp
  engine/Assets/AssetManager.cpp
  engine/Assets/ImageLoader.cpp
  engine/Systems/BehaviorSystem.cpp
  engine/Systems/PhysicsSystem.cpp
  engine/Systems/RenderSystem.cpp
  engine/Input/KeyCode.cpp
  engine/Input/InputManager.cpp
  engine/Audio/Wav.cpp
  engine/Audio/Mixer.cpp
  engine/Audio/MusicStream.cpp
  engine/Audio/AudioManager.cpp
)
target_include_directories(engine PUBLIC ${CMAKE_CURRENT_SOURCE_DIR}/engine)
target_link_libraries(engine PUBLIC SDL2::SDL2 GLEW::GLEW OpenGL::GL Threads::Threads)
target_compile_definitions(engine PUBLIC $<$<CONFIG:Debug>:ENGINE_DEBUG>)
if(STB_INCLUDE_DIR)
  target_include_directories(engine PRIVATE ${STB_INCLUDE_DIR})
  target_compile_definitions(engine PRIVATE ENGINE_HAS_STB)
endif()
if(WIN32)
  target_compile_definitions(engine PUBLIC NOMINMAX WIN32_LEAN_AND_MEAN)   # windows.h 의 min/max 매크로가 std::min/max 를 깨는 것 방지
endif()

if(MSVC)
  target_compile_options(engine PRIVATE /W4 /permissive-)
else()
  target_compile_options(engine PRIVATE -Wall -Wextra -Wpedantic -Wshadow -Wconversion)
endif()

# ---------------------------------------------------------------- sandbox
add_executable(sandbox sandbox/main.cpp)
target_link_libraries(sandbox PRIVATE engine $<TARGET_NAME_IF_EXISTS:SDL2::SDL2main>)

# ---------------------------------------------------------------- physics tests (GL/창 불필요)
add_executable(physics_tests tests/physics_tests.cpp)
target_link_libraries(physics_tests PRIVATE engine)
enable_testing()
add_test(NAME physics_tests COMMAND physics_tests)

# ---------------------------------------------------------------- Phase 4: scene demo + tests
add_executable(scene_demo sandbox/scene_demo.cpp)
target_link_libraries(scene_demo PRIVATE engine $<TARGET_NAME_IF_EXISTS:SDL2::SDL2main>)

add_executable(scene_tests tests/scene_tests.cpp)
target_link_libraries(scene_tests PRIVATE engine)
add_test(NAME scene_tests COMMAND scene_tests)

# ---------------------------------------------------------------- Phase 5: input + audio demo + tests
add_executable(input_audio_demo sandbox/input_audio_demo.cpp)
target_link_libraries(input_audio_demo PRIVATE engine $<TARGET_NAME_IF_EXISTS:SDL2::SDL2main>)

add_executable(input_tests tests/input_tests.cpp)
target_link_libraries(input_tests PRIVATE engine)
add_test(NAME input_tests COMMAND input_tests)

add_executable(audio_tests tests/audio_tests.cpp)
target_link_libraries(audio_tests PRIVATE engine)
add_test(NAME audio_tests COMMAND audio_tests)
