// Phase 4 단위 테스트: ECS · 씬 그래프 · 상태 머신 · 에셋 매니저 · 이미지 디코더 · 물리 연결 (창/GL 불필요). 실패하면 종료 코드 1.
#include <chrono>
#include <cmath>
#include <cstdio>
#include <filesystem>
#include <fstream>
#include <string>
#include <thread>
#include <vector>

#include "Assets/AssetManager.hpp"
#include "Assets/ImageLoader.hpp"
#include "Core/EventBus.hpp"
#include "Physics/PhysicsWorld.hpp"
#include "Scene/Scene.hpp"
#include "Scene/StateMachine.hpp"
#include "Systems/BehaviorSystem.hpp"
#include "Systems/PhysicsSystem.hpp"
#include "Systems/StandardComponents.hpp"

using namespace engine;
namespace fs = std::filesystem;

static int g_fail = 0, g_checks = 0;
#define CHECK(cond)                                                                   \
    do { ++g_checks; if (!(cond)) { ++g_fail; std::printf("  FAIL %s:%d  %s\n", __FILE__, __LINE__, #cond); } } while (0)
#define CHECK_NEAR(a, b, tol)                                                         \
    do { ++g_checks; const double va = (a), vb = (b);                                 \
         if (std::fabs(va - vb) > (tol)) { ++g_fail; std::printf("  FAIL %s:%d  %s=%g  expected %g (+-%g)\n", __FILE__, __LINE__, #a, va, vb, (double)(tol)); } } while (0)

struct Pos { float x = 0, y = 0; };
struct Vel { float x = 0, y = 0; };
struct Tag { int v = 0; };

// ------------------------------------------------------------------ ECS
static void TestEcs() {
    std::printf("[ecs]\n");
    Registry r;
    Entity a = r.Create(), b = r.Create(), c = r.Create();
    r.Add<Pos>(a, Pos{1, 2});
    r.Add<Pos>(b, Pos{3, 4});
    r.Add<Vel>(b, Vel{5, 6});
    r.Add<Pos>(c, Pos{7, 8});
    CHECK(r.Has<Pos>(a) && !r.Has<Vel>(a));
    CHECK(r.Count<Pos>() == 3 && r.Count<Vel>() == 1);

    int visited = 0;
    r.Each<Pos, Vel>([&](Entity e, Pos& p, Vel& v) { ++visited; CHECK(e == b); CHECK(p.x == 3 && v.y == 6); });
    CHECK(visited == 1);
    visited = 0;
    r.Each<Vel, Pos>([&](Entity, Vel&, Pos&) { ++visited; });          // 타입 순서가 달라도 같은 결과
    CHECK(visited == 1);
    r.Each<Tag>([&](Entity, Tag&) { ++visited; });                       // 풀이 아예 없는 타입
    CHECK(visited == 1);

    // 덮어쓰기
    r.Add<Pos>(a, Pos{9, 9});
    CHECK(r.Count<Pos>() == 3 && r.Get<Pos>(a).x == 9);

    // swap-pop 삭제 후에도 나머지 데이터가 올바른가
    r.Remove<Pos>(a);
    CHECK(!r.Has<Pos>(a) && r.Count<Pos>() == 2);
    CHECK(r.Get<Pos>(b).x == 3 && r.Get<Pos>(c).x == 7);

    // 세대: 삭제된 핸들은 무효, 슬롯 재사용
    CHECK(r.Destroy(b));
    CHECK(!r.IsAlive(b) && !r.Destroy(b));
    CHECK(!r.Has<Pos>(b) && r.TryGet<Pos>(b) == nullptr);
    Entity d = r.Create();
    CHECK(d.index == b.index && d.generation != b.generation);           // 슬롯 재사용 + 세대 증가
    CHECK(!r.Has<Pos>(d));                                               // 옛 컴포넌트가 새 엔티티에 새어나오지 않음
    CHECK(r.AliveCount() == 3);

    // 지연 삭제 (순회 중 안전)
    int n = 0;
    r.Each<Pos>([&](Entity e, Pos&) { ++n; r.DestroyLater(e); });
    CHECK(n == 1 && r.AliveCount() == 3);
    CHECK(r.FlushDestroyed() == 1 && r.AliveCount() == 2);
}

// ------------------------------------------------------------------ 씬 그래프
static void TestHierarchy() {
    std::printf("[scene hierarchy]\n");
    Scene s;
    Entity root = s.Create("root", {100, 0});
    Entity arm  = s.Create("arm", {10, 0}, root);
    Entity hand = s.Create("hand", {5, 0}, arm);
    CHECK(s.Parent(hand) == arm && s.Parent(arm) == root && !s.Parent(root).Valid());
    CHECK(s.ChildCount(root) == 1 && s.FirstChild(root) == arm);

    s.UpdateTransforms();
    CHECK_NEAR(s.Get<Transform>(hand).WorldPosition().x, 115, 1e-4);

    // 부모 회전 90도 -> 자식 월드 위치가 따라 돎
    s.Get<Transform>(root).rotation = kPi * 0.5f;
    s.UpdateTransforms();
    const Vec2 hp = s.Get<Transform>(hand).WorldPosition();
    CHECK_NEAR(hp.x, 100, 1e-3);
    CHECK_NEAR(hp.y, 15, 1e-3);
    CHECK_NEAR(s.Get<Transform>(hand).WorldRotation(), kPi * 0.5f, 1e-4);

    // 스케일 전파
    s.Get<Transform>(root).rotation = 0;
    s.Get<Transform>(root).scale = {2, 2};
    s.UpdateTransforms();
    CHECK_NEAR(s.Get<Transform>(hand).WorldPosition().x, 130, 1e-3);      // 100 + (10+5)*2
    CHECK_NEAR(s.Get<Transform>(hand).WorldScale().x, 2, 1e-4);

    // 자식 순서 = 추가 순서
    Entity c2 = s.Create("c2", {}, root), c3 = s.Create("c3", {}, root);
    std::vector<Entity> kids = s.Children(root);
    CHECK(kids.size() == 3 && kids[0] == arm && kids[1] == c2 && kids[2] == c3);

    // 순환 방지
    CHECK(!s.SetParent(root, hand));
    CHECK(!s.SetParent(root, root));
    CHECK(s.IsAncestor(root, hand) && !s.IsAncestor(hand, root));

    // 재부모화 (가운데 형제 이동 후 리스트 일관성)
    CHECK(s.SetParent(c2, c3));
    kids = s.Children(root);
    CHECK(kids.size() == 2 && kids[0] == arm && kids[1] == c3);
    CHECK(s.ChildCount(root) == 2 && s.ChildCount(c3) == 1);
    CHECK(s.SetParent(c2, kNullEntity));
    CHECK(!s.Parent(c2).Valid() && s.ChildCount(c3) == 0);

    // keepWorld: 월드 위치/회전/스케일 유지
    s.Get<Transform>(root).position = {0, 0};
    s.Get<Transform>(root).rotation = 0.7f;
    s.Get<Transform>(root).scale = {2, 2};                                         // 균일 스케일이면 TRS 로 정확히 복원된다
    s.Get<Transform>(c2).position = {40, 25};
    s.Get<Transform>(c2).rotation = 0.0f;
    s.Get<Transform>(c2).scale = {1, 1};
    s.UpdateTransforms();
    const Affine2D before = s.Get<Transform>(c2).world;
    CHECK(s.SetParent(c2, root, true));
    s.UpdateTransforms();
    const Affine2D after = s.Get<Transform>(c2).world;
    CHECK_NEAR(after.tx, before.tx, 1e-3); CHECK_NEAR(after.ty, before.ty, 1e-3);
    CHECK_NEAR(after.a, before.a, 1e-3);   CHECK_NEAR(after.b, before.b, 1e-3);
    CHECK_NEAR(after.c, before.c, 1e-3);   CHECK_NEAR(after.d, before.d, 1e-3);

    // 비균일 스케일 부모 아래에서는 전단(shear)이 생겨 TRS 로 정확히 표현할 수 없다: 위치는 정확, 나머지는 근사 (문서화된 한계)
    s.Get<Transform>(root).scale = {2, 3};
    s.SetParent(c2, kNullEntity);
    s.Get<Transform>(c2).position = {40, 25};
    s.Get<Transform>(c2).rotation = 0.0f;
    s.Get<Transform>(c2).scale = {1, 1};
    s.UpdateTransforms();
    const Vec2 wp = s.Get<Transform>(c2).WorldPosition();
    CHECK(s.SetParent(c2, root, true));
    s.UpdateTransforms();
    CHECK_NEAR(s.Get<Transform>(c2).WorldPosition().x, wp.x, 1e-3);
    CHECK_NEAR(s.Get<Transform>(c2).WorldPosition().y, wp.y, 1e-3);
}

static void TestAffine() {
    std::printf("[affine]\n");
    const Affine2D m = Affine2D::FromTRS({3, -2}, 0.9f, {2, 0.5f});
    const Affine2D inv = m.Inverse();
    const Vec2 p{7, 11};
    const Vec2 q = inv.TransformPoint(m.TransformPoint(p));
    CHECK_NEAR(q.x, 7, 1e-4); CHECK_NEAR(q.y, 11, 1e-4);
    const Affine2D id = Compose(m, inv);
    CHECK_NEAR(id.a, 1, 1e-4); CHECK_NEAR(id.d, 1, 1e-4); CHECK_NEAR(id.b, 0, 1e-4); CHECK_NEAR(id.tx, 0, 1e-3);
    CHECK_NEAR(m.Rotation(), 0.9, 1e-5);
    CHECK_NEAR(m.Scale().x, 2, 1e-5); CHECK_NEAR(m.Scale().y, 0.5, 1e-5);
    CHECK(!Affine2D::FromTRS({0, 0}, 0, {0, 1}).Invertible());
    CHECK_NEAR(LerpAngle(3.0f, -3.0f, 0.5f), 3.0f + 0.5f * (std::remainder(-6.0f, 2 * kPi)), 1e-5);   // ±π 경계에서 짧은 길로
}

static void TestDestroyAndEvents() {
    std::printf("[scene destroy / events]\n");
    EventBus bus;
    Scene s;
    s.SetEventBus(&bus);
    std::vector<std::string> log;
    auto sub1 = bus.Subscribe<EntityCreatedEvent>([&](const EntityCreatedEvent& e) { log.push_back("+" + s.Get<Name>(e.entity).value); });
    auto sub2 = bus.Subscribe<EntityDestroyedEvent>([&](const EntityDestroyedEvent& e) {
        CHECK(s.IsAlive(e.entity) && s.Has<Transform>(e.entity));                 // 발행 시점엔 아직 살아있음
        log.push_back("-" + s.Get<Name>(e.entity).value);
    });
    Entity root = s.Create("root");
    Entity a = s.Create("a", {}, root);
    Entity b = s.Create("b", {}, a);
    Entity other = s.Create("other");
    CHECK(s.Count() == 4);
    CHECK(s.Find("b") == b && !s.Find("nope").Valid());

    log.clear();
    CHECK(s.Destroy(root));                                                       // 하위 트리 전체
    CHECK(s.Count() == 1 && !s.IsAlive(a) && !s.IsAlive(b) && s.IsAlive(other));
    CHECK(log.size() == 3 && log[0] == "-b" && log[1] == "-a" && log[2] == "-root");   // 자식 -> 부모 순
    CHECK(!s.Destroy(root));

    // 자식 하나만 삭제하면 부모의 연결 리스트에서 빠진다
    Entity p = s.Create("p"), c1 = s.Create("c1", {}, p), c2 = s.Create("c2", {}, p);
    CHECK(s.Destroy(c1));
    CHECK(s.ChildCount(p) == 1 && s.FirstChild(p) == c2);

    // 순회 중 삭제 예약
    s.Each<Name>([&](Entity e, Name& n) { if (n.value == "c2") s.DestroyLater(e); });
    CHECK(s.IsAlive(c2));
    CHECK(s.FlushDestroyed() == 1 && !s.IsAlive(c2) && s.ChildCount(p) == 0);

    s.Clear();
    CHECK(s.Count() == 0);
}

static void TestInterpolation() {
    std::printf("[transform interpolation]\n");
    Scene s;
    Entity e = s.Create("e", {0, 0});
    s.UpdateTransforms();
    CHECK(!s.Get<Transform>(e).hasPrev);
    CHECK_NEAR(s.Get<Transform>(e).InterpolatedPosition(0.5f).x, 0, 1e-6);       // 첫 틱: 보간 없음
    s.BeginTick();
    s.Get<Transform>(e).position = {10, 0};
    s.UpdateTransforms();
    CHECK_NEAR(s.Get<Transform>(e).InterpolatedPosition(0.25f).x, 2.5, 1e-5);
    CHECK_NEAR(s.Get<Transform>(e).InterpolatedPosition(1.0f).x, 10, 1e-5);
    s.BeginTick();
    s.Get<Transform>(e).position = {1000, 0};
    s.ResetInterpolation(e);                                                     // 텔레포트: 중간을 지나가지 않음
    s.UpdateTransforms();
    CHECK_NEAR(s.Get<Transform>(e).InterpolatedPosition(0.5f).x, 1000, 1e-3);
}

// ------------------------------------------------------------------ 상태 머신
enum class S { Idle, Chase, Attack, Paused };

static void TestStateMachine() {
    std::printf("[state machine]\n");
    StateMachine<S> fsm;
    std::vector<std::string> log;
    float dist = 500.0f;
    fsm.Define(S::Idle).onEnter = [&] { log.push_back("enter Idle"); };
    fsm.Define(S::Idle).onExit  = [&] { log.push_back("exit Idle"); };
    fsm.Define(S::Chase).onEnter = [&] { log.push_back("enter Chase"); };
    fsm.Define(S::Chase).onUpdate = [&](double dt) { dist -= static_cast<float>(dt) * 100.0f; };
    fsm.Define(S::Chase).onExit = [&] { log.push_back("exit Chase"); };
    fsm.Define(S::Attack).onEnter = [&] { log.push_back("enter Attack"); };
    fsm.AddTransition(S::Idle, S::Chase, [&] { return dist < 600; });
    fsm.AddTransition(S::Chase, S::Attack, [&] { return dist < 100; });
    int changes = 0;
    fsm.SetOnChange([&](S, S) { ++changes; });

    fsm.Start(S::Idle);
    CHECK(fsm.Is(S::Idle) && log.size() == 1 && log[0] == "enter Idle");
    fsm.Update(0.1);                                    // Idle -> Chase (조건 참)
    CHECK(fsm.Is(S::Chase));
    CHECK(log.size() == 3 && log[1] == "exit Idle" && log[2] == "enter Chase");
    CHECK(fsm.TimeInState() == 0.0);                    // 막 들어옴
    for (int i = 0; i < 100 && !fsm.Is(S::Attack); ++i) fsm.Update(0.1);
    CHECK(fsm.Is(S::Attack) && changes == 2);
    CHECK(log.back() == "enter Attack");

    // 우선순위: 같은 상태에서 두 전이가 동시에 참이면 먼저 등록된 것
    StateMachine<S> pri;
    pri.Define(S::Idle); pri.Define(S::Chase); pri.Define(S::Attack);
    pri.AddTransition(S::Idle, S::Chase, [] { return true; });
    pri.AddTransition(S::Idle, S::Attack, [] { return true; });
    pri.Start(S::Idle); pri.Update(0.0);
    CHECK(pri.Is(S::Chase));

    // Any 전이
    StateMachine<S> any;
    bool kill = false;
    any.Define(S::Idle); any.Define(S::Chase); any.Define(S::Attack);
    any.AddAnyTransition(S::Idle, [&] { return kill; });
    any.Start(S::Attack);
    any.Update(0.1);
    CHECK(any.Is(S::Attack));
    kill = true;
    any.Update(0.1);
    CHECK(any.Is(S::Idle));
    any.Update(0.1);                                    // 이미 Idle 인데 조건이 계속 참 -> 자기 자신으로 재진입하지 않음
    CHECK(any.Is(S::Idle));

    // 스택: Push/Pop + onPause/onResume, Update 는 맨 위에만
    StateMachine<S> st;
    std::vector<std::string> sl;
    int idleTicks = 0, pausedTicks = 0;
    st.Define(S::Idle).onUpdate = [&](double) { ++idleTicks; };
    st.Define(S::Idle).onPause = [&] { sl.push_back("pause Idle"); };
    st.Define(S::Idle).onResume = [&] { sl.push_back("resume Idle"); };
    st.Define(S::Paused).onUpdate = [&](double) { ++pausedTicks; };
    st.Define(S::Paused).onEnter = [&] { sl.push_back("enter Paused"); };
    st.Define(S::Paused).onExit = [&] { sl.push_back("exit Paused"); };
    st.Start(S::Idle);
    st.Push(S::Paused);
    st.Update(0.1); st.Update(0.1);
    CHECK(idleTicks == 0 && pausedTicks == 2 && st.Depth() == 2 && st.Contains(S::Idle));
    st.Pop();
    CHECK(st.Is(S::Idle) && st.Depth() == 1);
    CHECK(sl.size() == 4 && sl[0] == "pause Idle" && sl[1] == "enter Paused" && sl[2] == "exit Paused" && sl[3] == "resume Idle");
    st.Update(0.1);
    CHECK(idleTicks == 1);

    // 재진입: onEnter 안에서 Change -> 콜백이 끝난 뒤 처리 (스택이 꼬이지 않음)
    StateMachine<S> re;
    std::vector<std::string> rl;
    re.Define(S::Idle).onEnter = [&] { rl.push_back("enter Idle"); re.Change(S::Chase); rl.push_back("after Change in onEnter"); };
    re.Define(S::Idle).onExit = [&] { rl.push_back("exit Idle"); };
    re.Define(S::Chase).onEnter = [&] { rl.push_back("enter Chase"); };
    re.Start(S::Idle);
    CHECK(re.Is(S::Chase) && re.Depth() == 1);
    CHECK(rl.size() == 4 && rl[0] == "enter Idle" && rl[1] == "after Change in onEnter" && rl[2] == "exit Idle" && rl[3] == "enter Chase");

    // Request 는 다음 Update 시작에 적용, Stop 은 전부 Exit
    StateMachine<S> rq;
    rq.Define(S::Idle); rq.Define(S::Chase);
    rq.Start(S::Idle);
    rq.Request(S::Chase);
    CHECK(rq.Is(S::Idle));
    rq.Update(0.016);
    CHECK(rq.Is(S::Chase));
    rq.Stop();
    CHECK(!rq.Running() && rq.Depth() == 0);
}

// ------------------------------------------------------------------ 이미지 디코더
static std::vector<std::uint8_t> MakeTGA(int w, int h, bool topLeft, bool rle) {
    std::vector<std::uint8_t> f(18, 0);
    f[2] = rle ? 10 : 2;
    f[12] = static_cast<std::uint8_t>(w); f[14] = static_cast<std::uint8_t>(h);
    f[16] = 32; f[17] = static_cast<std::uint8_t>((topLeft ? 0x20 : 0) | 8);
    // 픽셀 i: B=i, G=2i, R=3i, A=255 (저장 순서대로)
    std::vector<std::uint8_t> px;
    for (int i = 0; i < w * h; ++i) { px.push_back(static_cast<std::uint8_t>(i)); px.push_back(static_cast<std::uint8_t>(2 * i)); px.push_back(static_cast<std::uint8_t>(3 * i)); px.push_back(255); }
    if (!rle) { f.insert(f.end(), px.begin(), px.end()); return f; }
    // 전부 리터럴 패킷 1개 (w*h <= 128)
    f.push_back(static_cast<std::uint8_t>(w * h - 1));
    f.insert(f.end(), px.begin(), px.end());
    return f;
}

static void TestImages() {
    std::printf("[image decode]\n");
    // BMP 왕복 (위->아래 32bpp)
    std::vector<std::uint8_t> src;
    const int W = 5, H = 3;                                              // 가로 5 -> 24bpp 라면 패딩이 필요한 크기
    for (int i = 0; i < W * H; ++i) { src.push_back(static_cast<std::uint8_t>(10 + i)); src.push_back(static_cast<std::uint8_t>(50 + i)); src.push_back(static_cast<std::uint8_t>(90 + i)); src.push_back(static_cast<std::uint8_t>(200 + i)); }
    const std::vector<std::uint8_t> bmp = EncodeBMP(W, H, src.data());
    ImageData img;
    CHECK(DecodeImage(bmp.data(), bmp.size(), img));
    CHECK(img.width == W && img.height == H && img.rgba == src);

    // 24bpp 아래->위 BMP (행 패딩 포함)
    {
        const int w = 3, h = 2;
        const std::size_t row = ((static_cast<std::size_t>(w) * 24 + 31) / 32) * 4;      // 12 바이트 (9 + 패딩 3)
        std::vector<std::uint8_t> f(54 + row * h, 0);
        f[0] = 'B'; f[1] = 'M'; f[10] = 54; f[14] = 40; f[18] = w; f[22] = h; f[26] = 1; f[28] = 24;
        for (int y = 0; y < h; ++y) for (int x = 0; x < w; ++x) {                         // 저장 순서: 아래 행부터
            f[54 + row * static_cast<std::size_t>(y) + static_cast<std::size_t>(x) * 3 + 0] = static_cast<std::uint8_t>(1 + y);   // B
            f[54 + row * static_cast<std::size_t>(y) + static_cast<std::size_t>(x) * 3 + 1] = static_cast<std::uint8_t>(20 + x);  // G
            f[54 + row * static_cast<std::size_t>(y) + static_cast<std::size_t>(x) * 3 + 2] = static_cast<std::uint8_t>(30);      // R
        }
        CHECK(DecodeImage(f.data(), f.size(), img));
        CHECK(img.width == 3 && img.height == 2);
        // 저장 행 0 = 이미지 맨 아래 -> rgba 의 마지막 행. B 는 1+y
        CHECK(img.rgba[(1 * 3 + 0) * 4 + 2] == 1 && img.rgba[(0 * 3 + 0) * 4 + 2] == 2);
        CHECK(img.rgba[(0 * 3 + 2) * 4 + 1] == 22 && img.rgba[3] == 255);
    }

    // TGA: 비압축 / RLE, 원점 위치 (내장 디코더를 직접 검증 + 공개 DecodeImage 와 결과 일치)
    const std::vector<std::uint8_t> tgaBottom = MakeTGA(4, 2, false, false);
    { ImageData viaStb; CHECK(DecodeImageBuiltin(tgaBottom.data(), tgaBottom.size(), img) && DecodeImage(tgaBottom.data(), tgaBottom.size(), viaStb) && img.rgba == viaStb.rgba); }
    CHECK(DecodeImageBuiltin(tgaBottom.data(), tgaBottom.size(), img));
    CHECK(img.width == 4 && img.height == 2);
    CHECK(img.rgba[(1 * 4 + 0) * 4 + 2] == 0 && img.rgba[(0 * 4 + 0) * 4 + 2] == 4);      // 아래 원점: 첫 픽셀 행이 이미지 맨 아래
    CHECK(img.rgba[(1 * 4 + 1) * 4 + 0] == 3 && img.rgba[(1 * 4 + 1) * 4 + 3] == 255);   // R = 3i (i=1)
    const std::vector<std::uint8_t> tgaTop = MakeTGA(4, 2, true, true);
    CHECK(DecodeImageBuiltin(tgaTop.data(), tgaTop.size(), img));
    CHECK(img.rgba[(0 * 4 + 0) * 4 + 2] == 0 && img.rgba[(1 * 4 + 0) * 4 + 2] == 4);      // 위 원점 + RLE

    // 손상/악의적 입력: 크래시 없이 실패
    CHECK(!DecodeImage(nullptr, 0, img));
    std::vector<std::uint8_t> trunc(bmp.begin(), bmp.begin() + 40);
    CHECK(!DecodeImage(trunc.data(), trunc.size(), img) && !img.Valid());
    std::vector<std::uint8_t> hugeBmp = bmp;
    hugeBmp[18] = hugeBmp[19] = hugeBmp[20] = 0x7F;                                        // 거대한 가로
    CHECK(!DecodeImage(hugeBmp.data(), hugeBmp.size(), img));
    std::vector<std::uint8_t> shortTga(tgaBottom.begin(), tgaBottom.end() - 5);
    CHECK(!DecodeImageBuiltin(shortTga.data(), shortTga.size(), img));                     // 내장 디코더는 잘린 TGA 를 엄격히 거부 (stb 는 관대하게 부분 디코드)
    { ImageData tmp; (void)DecodeImage(shortTga.data(), shortTga.size(), tmp); }          // 어느 쪽이든 크래시는 없어야 함
    std::vector<std::uint8_t> garbage(256);
    for (std::size_t i = 0; i < garbage.size(); ++i) garbage[i] = static_cast<std::uint8_t>(i * 37 + 11);
    CHECK(!DecodeImage(garbage.data(), garbage.size(), img));
    for (std::size_t cut = 0; cut < bmp.size(); cut += 7) { ImageData tmp; (void)DecodeImage(bmp.data(), cut, tmp); }   // 어떤 길이로 잘라도 크래시 없음
    for (std::size_t cut = 0; cut < tgaTop.size(); cut += 3) { ImageData tmp; (void)DecodeImage(tgaTop.data(), cut, tmp); }
}

// ------------------------------------------------------------------ 에셋 매니저
struct Counted {
    static inline int alive = 0;
    int value = 0;
    explicit Counted(int v = 0) : value(v) { ++alive; }
    Counted(const Counted& o) : value(o.value) { ++alive; }
    Counted(Counted&& o) noexcept : value(o.value) { ++alive; }
    Counted& operator=(const Counted&) = default;
    Counted& operator=(Counted&&) noexcept = default;
    ~Counted() { --alive; }
};

static void WriteText(const fs::path& p, const std::string& s) { std::ofstream(p, std::ios::binary) << s; }

static void TestAssets() {
    std::printf("[assets]\n");
    const fs::path dir = fs::temp_directory_path() / "engine2d_asset_test";
    fs::remove_all(dir);
    fs::create_directories(dir);
    WriteText(dir / "a.txt", "hello");

    AssetManager am;
    am.SetRoot(dir.string());

    // 캐시: 같은 경로 -> 같은 객체
    auto t1 = am.Load<TextAsset>("a.txt");
    auto t2 = am.Load<TextAsset>("a.txt");
    CHECK(t1 && t1 == t2 && t1.Get() == t2.Get() && t1->text == "hello");
    CHECK(am.Count() == 1 && t1.UseCount() == 2);

    // 실패: 없는 파일 / 로더 없는 타입 -> 빈 핸들, 크래시 없음
    CHECK(!am.Load<TextAsset>("missing.txt"));
    CHECK(!am.Load<Pos>("whatever"));
    CHECK(am.Count() == 1);

    // 사용자 로더 + 절차적 등록
    am.RegisterLoader<Counted>([](const std::string& p) -> std::unique_ptr<Counted> {
        std::ifstream f(p);
        int v; if (!(f >> v)) return nullptr;
        return std::make_unique<Counted>(v);
    });
    WriteText(dir / "n.num", "41");
    auto n = am.Load<Counted>("n.num");
    CHECK(n && n->value == 41 && Counted::alive == 1);
    auto proc = am.Add<Counted>("procedural", std::make_unique<Counted>(7));
    CHECK(proc && am.Get<Counted>("procedural") == proc && Counted::alive == 2);
    auto dup = am.Add<Counted>("procedural", std::make_unique<Counted>(8));           // 같은 키 -> 기존 것 유지
    CHECK(dup == proc && dup->value == 7 && Counted::alive == 2);

    // CollectUnused: 핸들이 남아있는 것만 보존
    n.Reset();
    proc.Reset(); dup.Reset();
    CHECK(am.CollectUnused() == 2);                                                    // n.num + procedural
    CHECK(Counted::alive == 0 && !am.Get<Counted>("n.num") && am.Count() == 1);
    CHECK(t1.IsValid());                                                               // a.txt 는 핸들이 있어 보존

    // 핫 리로드: 같은 주소에 덮어쓰기
    auto n2 = am.Load<Counted>("n.num");
    const Counted* addr = n2.Get();
    const std::uint32_t ver = n2.Version();
    std::this_thread::sleep_for(std::chrono::milliseconds(30));
    WriteText(dir / "n.num", "99");
    fs::last_write_time(dir / "n.num", fs::file_time_type::clock::now() + std::chrono::seconds(2));   // 타임스탬프 해상도 문제 회피
    CHECK(am.ReloadChanged() == 1);
    CHECK(n2.Get() == addr && n2->value == 99 && n2.Version() == ver + 1);
    CHECK(am.ReloadChanged() == 0);                                                    // 변화 없으면 재로드 없음
    WriteText(dir / "n.num", "not a number");                                          // 깨진 수정본 -> 이전 데이터 유지
    fs::last_write_time(dir / "n.num", fs::file_time_type::clock::now() + std::chrono::seconds(4));
    CHECK(am.ReloadChanged() == 0 && n2->value == 99);
    CHECK(am.ReloadChanged() == 0);                                                    // 같은 깨진 파일을 매번 다시 읽지 않음

    // 이미지 디코드 에셋 (GL 없는 ImageData 타입)
    const std::uint8_t px[4 * 4] = {255, 0, 0, 255, 0, 255, 0, 255, 0, 0, 255, 255, 9, 9, 9, 9};
    CHECK(SaveBMP((dir / "i.bmp").string(), 2, 2, px));
    auto idata = am.Load<ImageData>("i.bmp");
    CHECK(idata && idata->width == 2 && idata->rgba[0] == 255 && idata->rgba[4 + 1] == 255 && idata->rgba[12 + 3] == 9);
    WriteText(dir / "bad.bmp", "BMxx garbage");
    CHECK(!am.Load<ImageData>("bad.bmp"));

    // Clear: 데이터는 즉시 파괴되고 남은 핸들은 안전하게 비어있음
    CHECK(Counted::alive == 1);
    am.Clear();
    CHECK(Counted::alive == 0 && !n2.IsValid() && n2.Get() == nullptr && !t1.IsValid());
    CHECK(am.Count() == 0);

    // 핸들이 매니저보다 오래 살아도 안전
    Asset<TextAsset> survivor;
    {
        AssetManager tmp;
        tmp.SetRoot(dir.string());
        survivor = tmp.Load<TextAsset>("a.txt");
        CHECK(survivor.IsValid());
    }
    CHECK(!survivor.IsValid());

    fs::remove_all(dir);
}

// ------------------------------------------------------------------ 물리 연결
static void TestPhysicsSystem() {
    std::printf("[physics system]\n");
    EventBus bus;
    Scene scene;
    scene.SetEventBus(&bus);
    PhysicsWorld world;
    world.SetEventBus(&bus);
    PhysicsSystem sys(scene, world, bus);

    Entity ground = scene.Create("ground", {0, -50});
    BodyDef gd; gd.type = BodyType::Static; gd.shape = Shape::MakeBox(500, 20);
    sys.AttachBody(ground, gd);

    Entity ball = scene.Create("ball", {0, 40});
    BodyDef bd; bd.shape = Shape::MakeCircle(10); bd.restitution = 0.0f;
    const BodyId bid = sys.AttachBody(ball, bd);
    CHECK(bid.Valid() && sys.BodyOf(ball) == bid && sys.EntityOf(bid) == ball);
    CHECK(sys.EntityOf(BodyId{}) == kNullEntity);

    Entity zone = scene.Create("zone", {0, -20});
    BodyDef zd; zd.type = BodyType::Static; zd.isSensor = true; zd.shape = Shape::MakeBox(100, 8);
    sys.AttachBody(zone, zd);

    int hits = 0, enters = 0;
    Entity hitA, hitB, enterOther;
    auto s1 = bus.Subscribe<EntityCollisionBeginEvent>([&](const EntityCollisionBeginEvent& e) { ++hits; hitA = e.a; hitB = e.b; });
    auto s2 = bus.Subscribe<EntityTriggerEnterEvent>([&](const EntityTriggerEnterEvent& e) { ++enters; enterOther = e.other; CHECK(e.sensor == zone); });

    scene.UpdateTransforms();
    for (int i = 0; i < 120; ++i) {
        scene.BeginTick();
        world.Step(1.0f / 60.0f);
        sys.SyncFromPhysics();
        scene.UpdateTransforms();
    }
    CHECK(hits >= 1 && ((hitA == ball && hitB == ground) || (hitA == ground && hitB == ball)));
    CHECK(enters == 1 && enterOther == ball);
    // 공은 바닥(윗면 y=-30) 위, 반지름 10 -> 중심 y ≈ -20 근처에서 정지
    CHECK_NEAR(scene.Get<Transform>(ball).WorldPosition().y, -20.0, 1.5);
    CHECK(scene.Get<Transform>(ground).position.y == -50.0f);                          // Static 은 건드리지 않음

    // 텔레포트: 바디와 Transform 이 같이 이동, 보간 끊김
    sys.Teleport(ball, {300, 200}, 0.0f);
    scene.UpdateTransforms();
    CHECK_NEAR(world.Get(bid)->position.x, 300, 1e-4);
    CHECK_NEAR(scene.Get<Transform>(ball).WorldPosition().y, 200, 1e-4);
    CHECK(!scene.Get<Transform>(ball).hasPrev);

    // 엔티티 삭제 -> 바디도 삭제, 매핑 해제
    const int before = world.Stats().bodies;
    (void)before;
    CHECK(scene.Destroy(ball));
    CHECK(!world.IsValid(bid) && sys.EntityOf(bid) == kNullEntity);

    // 자식 엔티티에 붙은 바디: 부모 변환을 반영해 월드 -> 로컬 역산
    Entity pivot = scene.Create("pivot", {1000, 1000});
    scene.Get<Transform>(pivot).rotation = 0.0f;
    Entity child = scene.Create("child", {0, 0}, pivot);
    scene.UpdateTransforms();
    BodyDef cd; cd.shape = Shape::MakeCircle(5); cd.gravityScale = 0.0f; cd.velocity = {60, 0};
    sys.AttachBody(child, cd);
    CHECK_NEAR(world.Get(sys.BodyOf(child))->position.x, 1000, 1e-3);                  // 자식이므로 월드 값으로 생성
    world.Step(1.0f);
    sys.SyncFromPhysics();
    scene.UpdateTransforms();
    CHECK_NEAR(scene.Get<Transform>(child).WorldPosition().x, 1060, 0.5);
    CHECK_NEAR(scene.Get<Transform>(child).position.x, 60, 0.5);                       // 로컬 = 월드 - 부모
}

static void TestBehaviors() {
    std::printf("[behaviors]\n");
    Scene scene;
    int starts = 0, updates = 0;
    Entity spawned;
    Entity e = scene.Create("script");
    Behavior b;
    b.onStart = [&](Entity, Scene&) { ++starts; };
    b.onUpdate = [&](Entity self, Scene& sc, double) {
        ++updates;
        if (updates == 2) {                                                            // 업데이트 중 생성 + 자기 삭제 + 컴포넌트 추가: 모두 안전해야 함
            spawned = sc.Create("child");
            sc.Add<Behavior>(spawned, Behavior{});
            sc.DestroyLater(self);
        }
    };
    scene.Add<Behavior>(e, b);
    UpdateBehaviors(scene, 0.016);
    UpdateBehaviors(scene, 0.016);
    CHECK(starts == 1 && updates == 2);
    scene.FlushDestroyed();
    UpdateBehaviors(scene, 0.016);
    CHECK(updates == 2 && !scene.IsAlive(e) && scene.IsAlive(spawned));
}

int main() {
    TestEcs();
    TestAffine();
    TestHierarchy();
    TestDestroyAndEvents();
    TestInterpolation();
    TestStateMachine();
    TestImages();
    TestAssets();
    TestPhysicsSystem();
    TestBehaviors();
    std::printf("\n%d checks, %d failed\n", g_checks, g_fail);
    return g_fail == 0 ? 0 : 1;
}
