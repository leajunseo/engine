// Phase 3 물리 단위 테스트 (창/GL 불필요). 실패하면 종료 코드 1.
#include <algorithm>
#include <cmath>
#include <cstdio>
#include <random>
#include <set>
#include <vector>

#include "Core/EventBus.hpp"
#include "Physics/Collision.hpp"
#include "Physics/PhysicsWorld.hpp"
#include "Physics/Quadtree.hpp"

using namespace engine;

static int g_fail = 0, g_checks = 0;
#define CHECK(cond)                                                                   \
    do { ++g_checks; if (!(cond)) { ++g_fail; std::printf("  FAIL %s:%d  %s\n", __FILE__, __LINE__, #cond); } } while (0)
#define CHECK_NEAR(a, b, tol)                                                         \
    do { ++g_checks; const double va = (a), vb = (b);                                 \
         if (std::fabs(va - vb) > (tol)) { ++g_fail; std::printf("  FAIL %s:%d  %s=%g  expected %g (+-%g)\n", __FILE__, __LINE__, #a, va, vb, (double)(tol)); } } while (0)

static Transform2D X(float x, float y, float a = 0.0f) { return Transform2D::Make({x, y}, a); }

static void TestCircles() {
    std::printf("[circles]\n");
    Manifold m;
    const Shape c = Shape::MakeCircle(1.0f);
    CHECK(CollideCircles(c, X(0, 0), c, X(1.5f, 0), m));
    CHECK_NEAR(m.normal.x, 1.0, 1e-5);
    CHECK_NEAR(m.points[0].separation, -0.5, 1e-5);
    CHECK(!CollideCircles(c, X(0, 0), c, X(2.1f, 0), m));
    CHECK(CollideCircles(c, X(0, 0), c, X(0, 0), m));        // 완전 일치 -> 임의 법선이지만 NaN 이 아니어야 함
    CHECK(std::isfinite(m.normal.x) && std::isfinite(m.normal.y));
}

static void TestBoxes() {
    std::printf("[boxes]\n");
    const Shape b = Shape::MakeBox(1.0f, 1.0f);
    Manifold fast, sat;
    CHECK(CollideAABBs(b, X(0, 0), b, X(1.9f, 0.3f), fast));
    CHECK(CollidePolygons(b, X(0, 0), b, X(1.9f, 0.3f), sat));
    CHECK(fast.count == 2 && sat.count == 2);
    CHECK_NEAR(fast.normal.x, sat.normal.x, 1e-5);
    CHECK_NEAR(fast.points[0].separation, sat.points[0].separation, 1e-4);
    CHECK_NEAR(fast.points[0].separation, -0.1, 1e-4);

    Manifold m;
    CHECK(!CollideAABBs(b, X(0, 0), b, X(2.1f, 0), m));
    CHECK(!CollidePolygons(b, X(0, 0), b, X(0, 2.1f), m));

    // 45도 회전한 박스의 모서리가 A 의 오른쪽 면을 0.214 침투
    CHECK(Collide(b, X(0, 0), b, X(2.2f, 0, kPi * 0.25f), m));
    CHECK_NEAR(m.normal.x, 1.0, 0.01);
    CHECK_NEAR(m.normal.y, 0.0, 0.01);
    CHECK_NEAR(m.points[0].separation, -0.2147, 0.01);

    // 법선은 항상 A -> B
    Manifold ab, ba;
    CHECK(Collide(b, X(0, 0, 0.3f), b, X(1.7f, 0.4f, -0.2f), ab));
    CHECK(Collide(b, X(1.7f, 0.4f, -0.2f), b, X(0, 0, 0.3f), ba));
    CHECK_NEAR(ab.normal.x, -ba.normal.x, 1e-3);
    CHECK_NEAR(ab.normal.y, -ba.normal.y, 1e-3);
}

static void TestCircleBox() {
    std::printf("[circle-box]\n");
    const Shape box = Shape::MakeBox(1.0f, 1.0f), c = Shape::MakeCircle(1.0f);
    Manifold m;
    CHECK(Collide(box, X(0, 0), c, X(0, 1.8f), m));           // 면 위
    CHECK_NEAR(m.normal.y, 1.0, 1e-5);
    CHECK_NEAR(m.points[0].separation, -0.2, 1e-4);
    CHECK(Collide(c, X(0, 1.8f), box, X(0, 0), m));           // 순서 반대 -> 법선 뒤집힘
    CHECK_NEAR(m.normal.y, -1.0, 1e-5);
    CHECK(Collide(box, X(0, 0), c, X(1.6f, 1.6f), m));        // 모서리 영역: 대각선 법선
    CHECK_NEAR(m.normal.x, 0.7071, 0.02);
    CHECK_NEAR(m.normal.y, 0.7071, 0.02);
    CHECK(!Collide(box, X(0, 0), c, X(2.2f, 2.2f), m));       // 모서리 반경 밖 (거리 1.7 > 1)
    CHECK(Collide(box, X(0, 0), c, X(0, 0.2f), m));           // 원 중심이 박스 내부
    CHECK(std::isfinite(m.normal.x) && m.points[0].separation < 0.0f);
}

static void TestPolygon() {
    std::printf("[polygon]\n");
    Shape tri = Shape::MakeRegularPolygon(3, 1.0f);
    CHECK(tri.count == 3);
    CHECK_NEAR(tri.Area(), 1.299, 0.01);                      // 3*sqrt(3)/4 * R^2
    Vec2 cen{0, 0};
    for (int i = 0; i < tri.count; ++i) cen += tri.verts[i];
    CHECK_NEAR(cen.Length(), 0.0, 1e-4);

    Shape bad;
    const Vec2 concave[4] = {{0, 0}, {2, 0}, {1, 0.5f}, {2, 2}};   // 오목
    CHECK(!Shape::TryMakePolygon(concave, 4, bad));
    const Vec2 line[3] = {{0, 0}, {1, 1}, {2, 2}};
    CHECK(!Shape::TryMakePolygon(line, 3, bad));
    const Vec2 cw[4] = {{0, 0}, {0, 2}, {2, 2}, {2, 0}};           // 시계방향도 허용
    CHECK(Shape::TryMakePolygon(cw, 4, bad));
    CHECK_NEAR(bad.Area(), 4.0, 1e-4);

    Manifold m;
    const Shape hex = Shape::MakeRegularPolygon(6, 1.0f), box = Shape::MakeBox(1, 1);
    CHECK(Collide(hex, X(0, 0), box, X(1.7f, 0.2f), m));
    CHECK(m.normal.x > 0.5f);
    CHECK(!Collide(hex, X(0, 0), box, X(3.0f, 0), m));
    // 박스 관성 = m(w^2+h^2)/12 : 밀도 1, 2x2 -> 면적 4, I = 4*(4+4)/12
    CHECK_NEAR(box.InertiaPerDensity(), 4.0 * 8.0 / 12.0, 1e-4);
    // 정6각형은 다각형 공식으로 구한 값과 원 근사치가 합리적 범위
    CHECK(hex.InertiaPerDensity() > 0.0f);
}

static void TestQuadtree() {
    std::printf("[quadtree vs brute force]\n");
    std::mt19937 rng(7);
    std::uniform_real_distribution<float> px(-1000, 1000), py(-600, 600), sz(2, 60), big(300, 900);
    std::vector<AABB> boxes;
    for (int i = 0; i < 1500; ++i) {
        const Vec2 c{px(rng), py(rng)};
        const float w = (i % 97 == 0) ? big(rng) : sz(rng), h = (i % 89 == 0) ? big(rng) : sz(rng);
        boxes.push_back({{c.x - w, c.y - h}, {c.x + w, c.y + h}});
    }
    AABB root{{-3000, -3000}, {3000, 3000}};
    Quadtree tree;
    tree.Reset(root);
    for (std::size_t i = 0; i < boxes.size(); ++i) tree.Insert(static_cast<std::uint32_t>(i), boxes[i]);

    std::vector<std::pair<std::uint32_t, std::uint32_t>> pairs;
    tree.QueryPairs(pairs);
    std::set<std::pair<std::uint32_t, std::uint32_t>> got, want;
    for (auto p : pairs) { if (p.first > p.second) std::swap(p.first, p.second); got.insert(p); }
    CHECK(got.size() == pairs.size());                         // 중복 없음
    for (std::uint32_t i = 0; i < boxes.size(); ++i)
        for (std::uint32_t j = i + 1; j < boxes.size(); ++j)
            if (boxes[i].Overlaps(boxes[j])) want.insert({i, j});
    CHECK(got == want);
    std::printf("  pairs=%zu nodes=%zu\n", want.size(), tree.NodeCount());

    // 영역 질의 + 루트 밖 아이템
    tree.Insert(5000, AABB{{5000, 5000}, {5100, 5100}});
    std::vector<std::uint32_t> q;
    tree.Query(AABB{{4900, 4900}, {5200, 5200}}, q);
    CHECK(q.size() == 1 && q[0] == 5000);
    const AABB area{{-100, -100}, {100, 100}};
    tree.Query(area, q);
    std::set<std::uint32_t> qs(q.begin(), q.end()), qw;
    for (std::uint32_t i = 0; i < boxes.size(); ++i) if (boxes[i].Overlaps(area)) qw.insert(i);
    CHECK(qs == qw);
}

static void TestBounce() {
    std::printf("[ball bounce]\n");
    PhysicsWorld w;
    BodyDef ground; ground.type = BodyType::Static; ground.shape = Shape::MakeBox(500, 20); ground.position = {0, -20};
    ground.restitution = 0.5f;
    w.CreateBody(ground);
    BodyDef ball; ball.shape = Shape::MakeCircle(20); ball.position = {0, 320}; ball.restitution = 0.5f;
    const BodyId id = w.CreateBody(ball);

    const float dt = 1.0f / 60.0f;
    float apex = 0, prevVy = 0;
    bool bounced = false;
    for (int i = 0; i < 60 * 8; ++i) {
        w.Step(dt);
        const Body& b = *w.Get(id);
        if (!bounced && prevVy < 0 && b.velocity.y > 0) bounced = true;
        if (bounced && b.position.y > apex && b.velocity.y > 0) apex = b.position.y;
        prevVy = b.velocity.y;
        CHECK(std::isfinite(b.position.y));
    }
    CHECK(bounced);
    const double h0 = 300.0, h1 = apex - 20.0;                  // 낙하 높이(중심-바닥에서 반지름 뺀) vs 첫 튕김 높이
    std::printf("  first bounce height ratio = %.3f (이론 0.25)\n", h1 / h0);
    CHECK(h1 / h0 > 0.15 && h1 / h0 < 0.35);
    const Body& b = *w.Get(id);
    CHECK(std::fabs(b.velocity.y) < 30.0f);                     // 8초 후 정지
    CHECK_NEAR(b.position.y, 20.0 - 0.5, 1.5);                  // 표면 위 (허용 침투 slop 만큼)
}

static void TestStack() {
    std::printf("[box stack]\n");
    PhysicsWorld w;
    BodyDef ground; ground.type = BodyType::Static; ground.shape = Shape::MakeBox(500, 20); ground.position = {0, -20};
    w.CreateBody(ground);
    std::vector<BodyId> ids;
    for (int i = 0; i < 6; ++i) {
        BodyDef d; d.shape = Shape::MakeBox(20, 20); d.position = {0, 20.0f + 41.0f * static_cast<float>(i)};
        d.restitution = 0.0f;
        ids.push_back(w.CreateBody(d));
    }
    for (int i = 0; i < 60 * 5; ++i) w.Step(1.0f / 60.0f);
    float maxV = 0, maxDx = 0;
    for (BodyId id : ids) {
        const Body& b = *w.Get(id);
        maxV = std::max(maxV, b.velocity.Length());
        maxDx = std::max(maxDx, std::fabs(b.position.x));
        CHECK(std::fabs(b.rotation) < 0.02f);
    }
    std::printf("  top y=%.2f (이상적 %.1f)  max|v|=%.2f  max|dx|=%.3f\n",
                w.Get(ids.back())->position.y, 20.0 + 40.0 * 5, maxV, maxDx);
    CHECK(maxV < 8.0f);
    CHECK(maxDx < 1.5f);
    CHECK_NEAR(w.Get(ids.back())->position.y, 220.0, 8.0);      // 무너지지 않고 거의 이상 높이
}

static void TestHeadOn() {
    std::printf("[elastic head-on]\n");
    PhysicsWorld w;
    w.Settings().gravity = {0, 0};
    BodyDef a; a.shape = Shape::MakeCircle(10); a.position = {-100, 0}; a.velocity = {400, 0}; a.restitution = 1.0f; a.angularDamping = 0;
    BodyDef b = a; b.position = {100, 0}; b.velocity = {-200, 0};
    const BodyId ia = w.CreateBody(a), ib = w.CreateBody(b);
    for (int i = 0; i < 60; ++i) w.Step(1.0f / 60.0f);
    // 같은 질량 완전 탄성 -> 속도 교환
    CHECK_NEAR(w.Get(ia)->velocity.x, -200.0, 2.0);
    CHECK_NEAR(w.Get(ib)->velocity.x, 400.0, 2.0);
}

static void TestEvents() {
    std::printf("[events]\n");
    EventBus bus;
    PhysicsWorld w;
    w.SetEventBus(&bus);
    int begins = 0, ends = 0, enters = 0, exits = 0;
    float impact = 0;
    auto s1 = bus.Subscribe<CollisionBeginEvent>([&](const CollisionBeginEvent& e) { ++begins; impact = e.impactSpeed; });
    auto s2 = bus.Subscribe<CollisionEndEvent>([&](const CollisionEndEvent&) { ++ends; });
    auto s3 = bus.Subscribe<TriggerEnterEvent>([&](const TriggerEnterEvent&) { ++enters; });
    auto s4 = bus.Subscribe<TriggerExitEvent>([&](const TriggerExitEvent&) { ++exits; });

    BodyDef ground; ground.type = BodyType::Static; ground.shape = Shape::MakeBox(500, 20); ground.position = {0, -20};
    ground.restitution = 0.0f;                                  // 반발은 두 물체 중 큰 값 -> 바닥도 0 으로
    w.CreateBody(ground);
    BodyDef zone; zone.type = BodyType::Static; zone.isSensor = true; zone.shape = Shape::MakeBox(60, 60); zone.position = {0, 150};
    w.CreateBody(zone);
    BodyDef ball; ball.shape = Shape::MakeCircle(15); ball.position = {0, 400}; ball.restitution = 0.0f;
    const BodyId id = w.CreateBody(ball);

    for (int i = 0; i < 60 * 3; ++i) w.Step(1.0f / 60.0f);
    CHECK(enters == 1);                                        // 낙하 중 센서 통과
    CHECK(exits == 1);
    CHECK(begins == 1);                                        // 바닥 접촉은 한 번만 (정지 후 재발행 없음)
    CHECK(impact > 300.0f);
    CHECK(ends == 0);
    w.ApplyImpulse(id, {0, 3000.0f * w.Get(id)->mass}, w.Get(id)->position);   // 위로 쏘아 올림 -> 접촉 종료
    for (int i = 0; i < 10; ++i) w.Step(1.0f / 60.0f);
    CHECK(ends == 1);

    // 레이어 필터: 마스크 0 이면 충돌하지 않음
    PhysicsWorld w2;
    BodyDef g2 = ground; g2.layer = 2;
    BodyDef b2 = ball; b2.position = {0, 20}; b2.mask = 1;      // 레이어 2 와 충돌 안 함
    w2.CreateBody(g2);
    const BodyId id2 = w2.CreateBody(b2);
    for (int i = 0; i < 60; ++i) w2.Step(1.0f / 60.0f);
    CHECK(w2.Get(id2)->position.y < -100.0f);                   // 바닥을 통과해 추락
}

static void TestDestroyAndQuery() {
    std::printf("[destroy / query / pick]\n");
    PhysicsWorld w;
    BodyDef d; d.shape = Shape::MakeCircle(20); d.position = {50, 50};
    const BodyId a = w.CreateBody(d);
    CHECK(w.IsValid(a));
    CHECK(w.PickBody({55, 45}) == a);
    CHECK(!w.PickBody({200, 200}).Valid());
    std::vector<BodyId> hits;
    w.QueryAABB(AABB{{0, 0}, {100, 100}}, hits);
    CHECK(hits.size() == 1);
    w.DestroyBody(a);
    CHECK(!w.IsValid(a));
    const BodyId b = w.CreateBody(d);                           // 슬롯 재사용 -> 세대가 달라 옛 id 는 무효
    CHECK(b.index == a.index && b.generation != a.generation);
    CHECK(!w.IsValid(a) && w.IsValid(b));
    w.Step(1.0f / 60.0f);                                       // 파괴/생성 후에도 크래시 없음
}

static std::vector<float> RunScenario() {
    PhysicsWorld w;
    BodyDef ground; ground.type = BodyType::Static; ground.shape = Shape::MakeBox(2000, 20); ground.position = {0, -20};
    w.CreateBody(ground);
    BodyDef wall = ground; wall.shape = Shape::MakeBox(20, 600);                       // 양쪽 벽 (옆으로 굴러 떨어지지 않게)
    wall.position = {-700, 500}; w.CreateBody(wall);
    wall.position = { 700, 500}; w.CreateBody(wall);
    std::mt19937 rng(99);
    std::uniform_real_distribution<float> px(-300, 300), py(50, 700), r(8, 24);
    for (int i = 0; i < 120; ++i) {
        BodyDef d;
        d.position = {px(rng), py(rng)};
        d.rotation = px(rng) * 0.01f;
        d.shape = (i % 3 == 0) ? Shape::MakeCircle(r(rng)) : (i % 3 == 1) ? Shape::MakeBox(r(rng), r(rng)) : Shape::MakeRegularPolygon(5, r(rng));
        w.CreateBody(d);
    }
    for (int i = 0; i < 240; ++i) w.Step(1.0f / 60.0f);
    std::vector<float> out;
    w.ForEachBody([&](BodyId, const Body& b) { out.push_back(b.position.x); out.push_back(b.position.y); out.push_back(b.rotation); });
    return out;
}

static void TestDeterminismAndStress() {
    std::printf("[determinism / stress]\n");
    const std::vector<float> a = RunScenario(), b = RunScenario();
    CHECK(a == b);                                              // 비트 단위로 동일
    bool finite = true;
    for (float v : a) finite = finite && std::isfinite(v);
    CHECK(finite);
    float minY = 1e9f;
    for (std::size_t i = 1; i < a.size(); i += 3) minY = std::min(minY, a[i]);
    std::printf("  lowest body y = %.1f\n", minY);
    CHECK(minY > -30.0f);                                       // 바닥을 뚫고 떨어진 물체 없음
}

int main() {
    TestCircles();
    TestBoxes();
    TestCircleBox();
    TestPolygon();
    TestQuadtree();
    TestBounce();
    TestStack();
    TestHeadOn();
    TestEvents();
    TestDestroyAndQuery();
    TestDeterminismAndStress();
    std::printf("\n%d checks, %d failed\n", g_checks, g_fail);
    return g_fail == 0 ? 0 : 1;
}
