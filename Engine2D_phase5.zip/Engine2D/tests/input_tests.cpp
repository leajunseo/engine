// Phase 5 입력 단위 테스트 (창/SDL 장치 불필요: EventBus 에 이벤트를 직접 발행). 실패하면 종료 코드 1.
#include <cmath>
#include <cstdio>
#include <string>
#include <vector>

#include <SDL.h>

#include "Core/EventBus.hpp"
#include "Core/Events.hpp"
#include "Input/InputManager.hpp"
#include "Input/KeyCode.hpp"

using namespace engine;

static int g_fail = 0, g_checks = 0;
#define CHECK(cond) do { ++g_checks; if (!(cond)) { ++g_fail; std::printf("  FAIL %s:%d  %s\n", __FILE__, __LINE__, #cond); } } while (0)
#define CHECK_NEAR(a, b, tol) do { ++g_checks; const double va = (a), vb = (b); if (std::fabs(va - vb) > (tol)) { ++g_fail; std::printf("  FAIL %s:%d  %s=%g expected %g\n", __FILE__, __LINE__, #a, va, vb); } } while (0)

static void Key(EventBus& bus, KeyCode k, bool pressed, bool repeat = false) { bus.Publish(KeyEvent{0, pressed, repeat, k}); }
static void Click(EventBus& bus, int sdlButton, bool pressed, float x = 0, float y = 0) { bus.Publish(MouseButtonEvent{sdlButton, pressed, x, y}); }

static void TestKeyCodes() {
    std::printf("[keycodes]\n");
    CHECK(KeyCodeFromScancode(SDL_SCANCODE_A) == KeyCode::A);
    CHECK(KeyCodeFromScancode(SDL_SCANCODE_Z) == KeyCode::Z);
    CHECK(KeyCodeFromScancode(SDL_SCANCODE_0) == KeyCode::Num0);
    CHECK(KeyCodeFromScancode(SDL_SCANCODE_9) == KeyCode::Num9);
    CHECK(KeyCodeFromScancode(SDL_SCANCODE_F12) == KeyCode::F12);
    CHECK(KeyCodeFromScancode(SDL_SCANCODE_SPACE) == KeyCode::Space);
    CHECK(KeyCodeFromScancode(SDL_SCANCODE_KP_9) == KeyCode::Keypad9);
    CHECK(KeyCodeFromScancode(SDL_SCANCODE_RALT) == KeyCode::RAlt);
    CHECK(KeyCodeFromScancode(SDL_SCANCODE_UNKNOWN) == KeyCode::Unknown);
    CHECK(KeyCodeFromScancode(-5) == KeyCode::Unknown);
    CHECK(KeyCodeFromScancode(100000) == KeyCode::Unknown);
    CHECK(KeyCodeFromScancode(SDL_SCANCODE_CAPSLOCK) == KeyCode::Unknown);       // 미지원 키

    // 모든 KeyCode 는 이름이 있고, 이름 -> 코드 왕복이 맞다 (이름은 서로 달라야 함)
    bool roundTrip = true;
    for (int i = 1; i < kKeyCount; ++i) {
        const KeyCode k = static_cast<KeyCode>(i);
        if (KeyCodeFromName(KeyName(k)) != k) { roundTrip = false; std::printf("  name round-trip failed: %d %s\n", i, KeyName(k)); }
    }
    CHECK(roundTrip);
    CHECK(KeyCodeFromName("space") == KeyCode::Space);       // 대소문자 무시
    CHECK(KeyCodeFromName("LSHIFT") == KeyCode::LShift);
    CHECK(KeyCodeFromName("nope") == KeyCode::Unknown);
    CHECK(KeyCodeFromName("") == KeyCode::Unknown);
    CHECK(std::string(KeyName(KeyCode::Count)) == "Unknown");

    CHECK(MouseButtonFromSdl(SDL_BUTTON_LEFT) == MouseButton::Left);
    CHECK(MouseButtonFromSdl(SDL_BUTTON_X2) == MouseButton::X2);
    CHECK(MouseButtonFromSdl(0) == MouseButton::Count);
    CHECK(MouseButtonFromSdl(99) == MouseButton::Count);
    MouseButton mb;
    CHECK(MouseButtonFromName("right", mb) && mb == MouseButton::Right);
    CHECK(!MouseButtonFromName("nope", mb));
}

static void TestRawState() {
    std::printf("[raw state]\n");
    EventBus bus; InputManager in(bus);
    CHECK(!in.Down(KeyCode::A));
    Key(bus, KeyCode::A, true);
    CHECK(in.Down(KeyCode::A) && in.Pressed(KeyCode::A) && in.PressedTick(KeyCode::A));
    CHECK(!in.Released(KeyCode::A));
    CHECK(in.LastPressedKey() == KeyCode::A);
    CHECK(in.AnyKeyDown());

    Key(bus, KeyCode::A, true, /*repeat*/ true);               // 반복 이벤트는 무시: 엣지가 다시 생기지 않는다
    in.EndTick(); in.EndFrame();
    Key(bus, KeyCode::A, true, true);
    CHECK(in.Down(KeyCode::A) && !in.Pressed(KeyCode::A));
    CHECK(in.LastPressedKey() == KeyCode::Unknown);

    Key(bus, KeyCode::A, false);
    CHECK(!in.Down(KeyCode::A) && in.Released(KeyCode::A) && in.ReleasedTick(KeyCode::A));
    CHECK(!in.AnyKeyDown());

    // Unknown / 범위 밖 키는 무시
    Key(bus, KeyCode::Unknown, true);
    Key(bus, KeyCode::Count, true);
    CHECK(!in.AnyKeyDown());
    CHECK(!in.Down(KeyCode::Unknown) && !in.Down(KeyCode::Count));

    // 마우스
    Click(bus, SDL_BUTTON_LEFT, true, 10, 20);
    CHECK(in.Down(MouseButton::Left) && in.Pressed(MouseButton::Left));
    CHECK_NEAR(in.MousePosition().x, 10, 1e-6); CHECK_NEAR(in.MousePosition().y, 20, 1e-6);
    Click(bus, SDL_BUTTON_LEFT, false, 10, 20);
    CHECK(!in.Down(MouseButton::Left) && in.Released(MouseButton::Left));
    Click(bus, 77, true);                                      // 모르는 버튼은 무시
    CHECK(!in.Down(MouseButton::Count));
}

static void TestEdgeSemantics() {
    std::printf("[frame / tick edges]\n");
    EventBus bus; InputManager in(bus);

    // 틱이 한 번도 안 돈 프레임: 틱 엣지가 다음 틱까지 유지된다 (누락 없음)
    Key(bus, KeyCode::Space, true);
    in.EndFrame();                                              // 프레임 끝: 프레임 엣지 소멸
    CHECK(!in.Pressed(KeyCode::Space));
    CHECK(in.PressedTick(KeyCode::Space));                      // 틱 엣지는 살아있음
    in.EndTick();
    CHECK(!in.PressedTick(KeyCode::Space));                     // 한 틱에서 소비

    // 한 프레임에 틱이 두 번: 두 번째 틱에서는 false (중복 없음)
    Key(bus, KeyCode::Enter, true);
    CHECK(in.PressedTick(KeyCode::Enter)); in.EndTick();
    CHECK(!in.PressedTick(KeyCode::Enter)); in.EndTick();
    CHECK(in.Pressed(KeyCode::Enter));                          // 프레임 엣지는 프레임 끝까지
    in.EndFrame();
    CHECK(!in.Pressed(KeyCode::Enter));

    // 한 프레임 안에서 눌렀다 뗐다: 두 엣지 모두 보이고 Down 은 false
    Key(bus, KeyCode::E, true); Key(bus, KeyCode::E, false);
    CHECK(in.Pressed(KeyCode::E) && in.Released(KeyCode::E) && !in.Down(KeyCode::E));
    in.EndTick(); in.EndFrame();
}

static void TestMouseMotion() {
    std::printf("[mouse motion / wheel]\n");
    EventBus bus; InputManager in(bus);
    bus.Publish(MouseMoveEvent{100, 100});                      // 첫 이벤트: 이동량 없음 (점프 방지)
    CHECK_NEAR(in.MouseDelta().x, 0, 1e-6);
    bus.Publish(MouseMoveEvent{110, 95});
    bus.Publish(MouseMoveEvent{115, 95});
    CHECK_NEAR(in.MouseDelta().x, 15, 1e-5); CHECK_NEAR(in.MouseDelta().y, -5, 1e-5);
    bus.Publish(MouseWheelEvent{1}); bus.Publish(MouseWheelEvent{2});
    CHECK_NEAR(in.Wheel(), 3, 1e-6);
    in.EndFrame();
    CHECK_NEAR(in.MouseDelta().x, 0, 1e-6); CHECK_NEAR(in.Wheel(), 0, 1e-6);
    CHECK_NEAR(in.MousePosition().x, 115, 1e-6);                // 위치는 유지
}

static void TestFocusLoss() {
    std::printf("[focus loss]\n");
    EventBus bus; InputManager in(bus);
    ActionId fire = in.DefineAction("Fire");
    in.BindKey(fire, KeyCode::F);
    Key(bus, KeyCode::W, true); Key(bus, KeyCode::F, true); Click(bus, SDL_BUTTON_RIGHT, true);
    in.EndTick(); in.EndFrame();
    CHECK(in.Down(KeyCode::W) && in.Down(fire) && in.Down(MouseButton::Right));
    bus.Publish(WindowFocusEvent{false});
    CHECK(!in.Down(KeyCode::W) && !in.Down(fire) && !in.Down(MouseButton::Right));
    CHECK(in.Released(KeyCode::W) && in.Released(fire) && in.ReleasedTick(fire));
    bus.Publish(WindowFocusEvent{true});                        // 포커스 획득은 아무 일도 없음
    CHECK(!in.Down(KeyCode::W));
}

static void TestActions() {
    std::printf("[actions]\n");
    EventBus bus; InputManager in(bus);
    ActionId jump = in.DefineAction("Jump");
    CHECK(jump.Valid() && in.DefineAction("Jump") == jump);     // 같은 이름 -> 같은 id
    CHECK(in.FindAction("Jump") == jump);
    CHECK(!in.FindAction("Nope").Valid());
    in.BindKey(jump, KeyCode::Space);
    in.BindKey(jump, KeyCode::Space);                           // 중복 바인딩은 무시
    in.BindMouse(jump, MouseButton::Left);
    in.BindKey(jump, KeyCode::Unknown);                         // 잘못된 바인딩은 무시

    Key(bus, KeyCode::Space, true);
    CHECK(in.Down(jump) && in.Pressed(jump) && in.PressedTick(jump));
    in.EndTick(); in.EndFrame();
    Click(bus, SDL_BUTTON_LEFT, true);                          // 이미 눌린 액션: 두 번째 입력은 새 Pressed 가 아님
    CHECK(in.Down(jump) && !in.Pressed(jump));
    Key(bus, KeyCode::Space, false);
    CHECK(in.Down(jump) && !in.Released(jump));                 // 마우스가 아직 눌려 있음
    Click(bus, SDL_BUTTON_LEFT, false);
    CHECK(!in.Down(jump) && in.Released(jump));

    // 바인딩 교체/해제
    in.EndTick(); in.EndFrame();
    Key(bus, KeyCode::J, true);
    CHECK(!in.Down(jump));
    in.ClearBindings(jump);
    in.BindKey(jump, KeyCode::J);
    CHECK(in.Down(jump));                                       // 이미 눌려 있던 J 가 새 바인딩으로 인식됨
    in.ClearBindings(jump);
    CHECK(!in.Down(jump) && in.Released(jump));                 // 바인딩 제거 -> 뗌 처리
    CHECK(in.FindActionUsing(KeyCode::J).empty());
    in.BindKey(jump, KeyCode::K);
    CHECK(in.FindActionUsing(KeyCode::K) == "Jump");

    // 잘못된 id 는 안전
    ActionId bad;
    CHECK(!in.Down(bad) && !in.Pressed(bad) && !in.Released(bad));
    in.BindKey(bad, KeyCode::A); in.ClearBindings(bad);
    ActionId outOfRange{999};
    CHECK(!in.Down(outOfRange));
}

static void TestAxes() {
    std::printf("[axes]\n");
    EventBus bus; InputManager in(bus);
    AxisId x = in.DefineAxis("MoveX");
    CHECK(x.Valid() && in.DefineAxis("MoveX") == x && in.FindAxis("MoveX") == x && !in.FindAxis("zz").Valid());
    in.BindAxisKeys(x, KeyCode::A, KeyCode::D);
    in.BindAxisKeys(x, KeyCode::Left, KeyCode::Right);
    CHECK_NEAR(in.Value(x), 0, 1e-6);
    Key(bus, KeyCode::D, true);                CHECK_NEAR(in.Value(x), 1, 1e-6);
    Key(bus, KeyCode::A, true);                CHECK_NEAR(in.Value(x), 0, 1e-6);       // 반대 키 동시 입력 = 상쇄
    Key(bus, KeyCode::D, false);               CHECK_NEAR(in.Value(x), -1, 1e-6);
    Key(bus, KeyCode::Left, true);             CHECK_NEAR(in.Value(x), -1, 1e-6);       // 같은 방향 두 키 = 합이 1 로 제한
    Key(bus, KeyCode::A, false); Key(bus, KeyCode::Left, false);
    CHECK_NEAR(in.Value(x), 0, 1e-6);

    AxisId half = in.DefineAxis("Throttle");
    in.BindAxisKeys(half, KeyCode::S, KeyCode::W, 0.5f);
    Key(bus, KeyCode::W, true);                CHECK_NEAR(in.Value(half), 0.5, 1e-6);

    AxisId look = in.DefineAxis("Look");
    in.BindAxisMouseX(look, 0.1f);
    in.BindAxisWheel(look, 2.0f);
    bus.Publish(MouseMoveEvent{0, 0}); bus.Publish(MouseMoveEvent{50, 0});
    bus.Publish(MouseWheelEvent{1});
    CHECK_NEAR(in.Value(look), 50 * 0.1 + 2.0, 1e-4);           // 마우스/휠은 제한 없이 더해짐
    in.EndFrame();
    CHECK_NEAR(in.Value(look), 0, 1e-6);

    in.ClearBindings(x);
    Key(bus, KeyCode::D, true);                CHECK_NEAR(in.Value(x), 0, 1e-6);
    AxisId bad;
    CHECK_NEAR(in.Value(bad), 0, 1e-9);
    in.BindAxisKeys(bad, KeyCode::A, KeyCode::D); in.BindAxisWheel(bad, 1);
}

static void TestSerialization() {
    std::printf("[bindings serialize / parse]\n");
    EventBus bus; InputManager a(bus);
    ActionId jump = a.DefineAction("Jump"); a.BindKey(jump, KeyCode::Space); a.BindMouse(jump, MouseButton::Left);
    a.DefineAction("Unbound");
    AxisId mx = a.DefineAxis("MoveX"); a.BindAxisKeys(mx, KeyCode::A, KeyCode::D); a.BindAxisKeys(mx, KeyCode::Left, KeyCode::Right, 0.5f);
    AxisId lk = a.DefineAxis("Look"); a.BindAxisMouseX(lk, 0.25f); a.BindAxisWheel(lk, -1.5f);

    const std::string text = a.SerializeBindings();
    EventBus bus2; InputManager b(bus2);
    std::vector<std::string> errs;
    CHECK(b.ParseBindings(text, &errs) && errs.empty());
    CHECK(b.SerializeBindings() == text);                       // 왕복 후 동일
    CHECK(b.FindAction("Unbound").Valid());                     // 바인딩 없는 정의도 보존

    Key(bus2, KeyCode::Right, true);
    CHECK_NEAR(b.Value(b.FindAxis("MoveX")), 0.5, 1e-6);
    Key(bus2, KeyCode::Space, true);
    CHECK(b.Down(b.FindAction("Jump")));

    // 오류가 있는 줄은 건너뛰고 나머지는 적용, 오류는 보고
    EventBus bus3; InputManager c(bus3);
    errs.clear();
    const std::string bad =
        "# comment\n\n"
        "action Jump key Space\n"
        "action Jump key Banana\n"                // 모르는 키
        "action Jump mouse Nope\n"                // 모르는 버튼
        "action Jump pad A\n"                     // 모르는 종류
        "axis Move keys A\n"                      // 인자 부족
        "axis Move keys A D abc\n"                // 잘못된 숫자
        "axis Move keys A D 2\n"                  // 정상
        "axis Look mousex\n"                      // 인자 부족
        "axis Look nothing 1\n"                   // 모르는 소스
        "frobnicate x y\n"                        // 모르는 명령
        "action\n";                               // 이름 없음
    CHECK(!c.ParseBindings(bad, &errs));
    CHECK(errs.size() == 9);
    CHECK(c.FindAction("Jump").Valid() && c.FindAxis("Move").Valid());
    Key(bus3, KeyCode::Space, true);
    CHECK(c.Down(c.FindAction("Jump")));                        // 정상 줄은 적용됨
    Key(bus3, KeyCode::D, true);
    CHECK_NEAR(c.Value(c.FindAxis("Move")), 1.0, 1e-6);         // 2 * 1 -> [-1,1] 로 제한
    CHECK(errs.empty() == false && errs[0].find("line 4") != std::string::npos);

    // 파싱은 '언급된' 액션의 기존 바인딩만 교체한다
    EventBus bus4; InputManager d(bus4);
    ActionId f = d.DefineAction("Fire"); d.BindKey(f, KeyCode::F);
    ActionId g = d.DefineAction("Guard"); d.BindKey(g, KeyCode::G);
    CHECK(d.ParseBindings("action Fire key X\n"));
    Key(bus4, KeyCode::F, true); CHECK(!d.Down(f));             // 옛 바인딩 교체됨
    Key(bus4, KeyCode::X, true); CHECK(d.Down(f));
    Key(bus4, KeyCode::G, true); CHECK(d.Down(g));              // 언급 안 된 액션은 그대로

    // 숫자 로케일/CRLF 줄바꿈도 견딘다
    EventBus bus5; InputManager e(bus5);
    CHECK(e.ParseBindings("action Jump key Space\r\naxis A keys Q E 0.5\r\n"));

    // 파일 저장/불러오기
    const std::string path = "input_bindings_test.cfg";
    CHECK(a.SaveBindings(path));
    EventBus bus6; InputManager h(bus6);
    CHECK(h.LoadBindings(path));
    CHECK(h.SerializeBindings() == text);
    CHECK(!h.LoadBindings("no_such_file.cfg"));                 // 파일 없음: false, 상태는 그대로
    std::remove(path.c_str());
}

static void TestLifetime() {
    std::printf("[lifetime]\n");
    // InputManager 가 EventBus 보다 먼저 파괴돼도, EventBus 가 먼저 파괴돼도 안전해야 한다
    {
        EventBus bus;
        { InputManager in(bus); }
        Key(bus, KeyCode::A, true);                             // 구독이 해제됐으므로 크래시 없음
    }
    {
        auto bus = std::make_unique<EventBus>();
        InputManager in(*bus);
        bus.reset();                                            // 버스가 먼저 사라짐 -> in 소멸자가 안전해야 함
    }
    CHECK(true);
}

int main() {
    TestKeyCodes();
    TestRawState();
    TestEdgeSemantics();
    TestMouseMotion();
    TestFocusLoss();
    TestActions();
    TestAxes();
    TestSerialization();
    TestLifetime();
    std::printf("\n%d checks, %d failed\n", g_checks, g_fail);
    return g_fail == 0 ? 0 : 1;
}
