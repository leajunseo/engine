// Phase 5 오디오 단위 테스트: WAV 코덱 · 믹서 · 스트리밍 음악 · 스레드 안전성 (소리 장치 불필요). 실패하면 종료 코드 1.
#include <atomic>
#include <chrono>
#include <cmath>
#include <cstdint>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <fstream>
#include <memory>
#include <random>
#include <string>
#include <thread>
#include <vector>

#include <SDL.h>

#include "Audio/AudioManager.hpp"
#include "Audio/Mixer.hpp"
#include "Audio/MusicStream.hpp"
#include "Audio/Wav.hpp"

using namespace engine;

static int g_fail = 0, g_checks = 0;
#define CHECK(cond) do { ++g_checks; if (!(cond)) { ++g_fail; std::printf("  FAIL %s:%d  %s\n", __FILE__, __LINE__, #cond); } } while (0)
#define CHECK_NEAR(a, b, tol) do { ++g_checks; const double va = (a), vb = (b); if (std::fabs(va - vb) > (tol)) { ++g_fail; std::printf("  FAIL %s:%d  %s=%g expected %g (+-%g)\n", __FILE__, __LINE__, #a, va, vb, (double)(tol)); } } while (0)

namespace {

constexpr int kRate = 48000;
constexpr float kPi = 3.14159265358979f;

std::vector<float> Render(Mixer& m, int frames) {
    std::vector<float> out(static_cast<std::size_t>(frames) * 2);
    m.Mix(out.data(), frames);
    return out;
}

AudioClip ConstClip(float v, int frames, int rate = kRate) {
    std::vector<float> d(static_cast<std::size_t>(frames), v);
    return AudioClip::FromMono(d.data(), d.size(), rate);
}

int CountNonZeroFrames(const std::vector<float>& o) {
    int n = 0;
    for (std::size_t i = 0; i + 1 < o.size(); i += 2) if (o[i] != 0.0f || o[i + 1] != 0.0f) ++n;
    return n;
}

// ---- 손으로 만드는 WAV (다양한 포맷/이상한 헤더 테스트용) ----
void P16(std::vector<std::uint8_t>& v, unsigned x) { v.push_back(x & 255); v.push_back((x >> 8) & 255); }
void P32(std::vector<std::uint8_t>& v, std::uint32_t x) { for (int i = 0; i < 4; ++i) v.push_back(static_cast<std::uint8_t>(x >> (8 * i))); }
void Tag(std::vector<std::uint8_t>& v, const char* t) { v.insert(v.end(), t, t + 4); }

struct WavSpec {
    unsigned format = 1, channels = 1, rate = 8000, bits = 16;
    bool extensible = false;
    std::vector<std::uint8_t> data;
    bool listChunkBefore = false;      // 홀수 크기 LIST 청크 (패딩 바이트 검증)
    std::int64_t dataSizeOverride = -1;
};

std::vector<std::uint8_t> MakeWav(const WavSpec& s) {
    std::vector<std::uint8_t> v;
    Tag(v, "RIFF"); P32(v, 0); Tag(v, "WAVE");
    Tag(v, "fmt ");
    if (s.extensible) {
        P32(v, 40); P16(v, 0xFFFE); P16(v, s.channels); P32(v, s.rate); P32(v, s.rate * s.channels * s.bits / 8);
        P16(v, s.channels * s.bits / 8); P16(v, s.bits); P16(v, 22); P16(v, s.bits); P32(v, 0);
        P16(v, s.format); for (int i = 0; i < 14; ++i) v.push_back(0);      // SubFormat GUID (앞 2바이트가 포맷)
    } else {
        P32(v, 16); P16(v, s.format); P16(v, s.channels); P32(v, s.rate); P32(v, s.rate * s.channels * s.bits / 8);
        P16(v, s.channels * s.bits / 8); P16(v, s.bits);
    }
    if (s.listChunkBefore) { Tag(v, "LIST"); P32(v, 3); v.push_back(1); v.push_back(2); v.push_back(3); v.push_back(0); }   // 3바이트 + 패딩 1
    Tag(v, "data");
    P32(v, s.dataSizeOverride >= 0 ? static_cast<std::uint32_t>(s.dataSizeOverride) : static_cast<std::uint32_t>(s.data.size()));
    v.insert(v.end(), s.data.begin(), s.data.end());
    return v;
}

class MemoryStream final : public IAudioStream {
public:
    MemoryStream(float value, int frames, bool* destroyed = nullptr, int* reads = nullptr, bool underrunAtEnd = false)
        : value_(value), frames_(frames), destroyed_(destroyed), reads_(reads), underrun_(underrunAtEnd) {}
    ~MemoryStream() override { if (destroyed_) *destroyed_ = true; }
    int Read(float* dst, int n) override {
        if (reads_) ++*reads_;
        const int k = std::min(n, frames_ - pos_);
        for (int i = 0; i < k; ++i) { dst[2 * i] = value_; dst[2 * i + 1] = value_; }
        pos_ += k;
        return k;
    }
    bool Finished() const override { return !underrun_ && pos_ >= frames_; }
private:
    float value_; int frames_, pos_ = 0; bool* destroyed_; int* reads_; bool underrun_;
};

std::string TempPath(const char* name) { return std::string("audio_test_") + name; }

// 사인파 WAV 파일 (모노 16bit)
std::string WriteSineWav(const char* name, int rate, double seconds, double freq, float amp = 0.5f) {
    const std::size_t n = static_cast<std::size_t>(rate * seconds);
    std::vector<float> d(n);
    for (std::size_t i = 0; i < n; ++i) d[i] = amp * std::sin(2.0f * kPi * static_cast<float>(freq) * static_cast<float>(i) / static_cast<float>(rate));
    const std::string path = TempPath(name);
    SaveWav16(path, d.data(), n, 1, rate);
    return path;
}

// 끝날 때까지(또는 시간 초과) 스트림을 읽어 모은다. 버퍼 부족이면 잠깐 기다린다.
std::vector<float> Drain(StreamingMusic& s, std::size_t maxFrames, int timeoutMs = 5000) {
    std::vector<float> all, buf(1024 * 2);
    const auto t0 = std::chrono::steady_clock::now();
    while (all.size() / 2 < maxFrames) {
        const int n = s.Read(buf.data(), static_cast<int>(std::min<std::size_t>(1024, maxFrames - all.size() / 2)));   // maxFrames 를 넘겨 읽지 않음
        all.insert(all.end(), buf.begin(), buf.begin() + n * 2);
        if (n == 0) {
            if (s.Finished()) break;
            std::this_thread::sleep_for(std::chrono::milliseconds(1));
        }
        if (std::chrono::steady_clock::now() - t0 > std::chrono::milliseconds(timeoutMs)) { std::printf("  (Drain timeout)\n"); break; }
    }
    return all;
}

} // namespace

// ============================================================================ WAV
static void TestWavRoundTrip() {
    std::printf("[wav round trip]\n");
    std::vector<float> mono(1000);
    for (std::size_t i = 0; i < mono.size(); ++i) mono[i] = 0.8f * std::sin(static_cast<float>(i) * 0.05f);
    auto bytes = EncodeWav16(mono.data(), mono.size(), 1, 22050);
    CHECK(bytes.size() == 44 + 2000);
    AudioClip c;
    CHECK(DecodeWav(bytes.data(), bytes.size(), c));
    CHECK(c.sampleRate == 22050 && c.FrameCount() == 1000 && c.Valid());
    CHECK_NEAR(c.Duration(), 1000.0 / 22050.0, 1e-9);
    double maxErr = 0;
    for (std::size_t i = 0; i < mono.size(); ++i) {
        maxErr = std::max(maxErr, static_cast<double>(std::fabs((*c.samples)[2 * i] - mono[i])));
        maxErr = std::max(maxErr, static_cast<double>(std::fabs((*c.samples)[2 * i + 1] - mono[i])));   // 모노는 양 채널로 복제
    }
    CHECK(maxErr < 2.0 / 32768.0);

    std::vector<float> st = {0.5f, -0.5f, 1.0f, -1.0f, 0.25f, 0.0f};
    bytes = EncodeWav16(st.data(), 3, 2, 44100);
    CHECK(DecodeWav(bytes.data(), bytes.size(), c) && c.FrameCount() == 3);
    CHECK_NEAR((*c.samples)[0], 0.5, 1e-3); CHECK_NEAR((*c.samples)[1], -0.5, 1e-3);
    CHECK_NEAR((*c.samples)[2], 1.0, 1e-3); CHECK_NEAR((*c.samples)[3], -1.0, 1e-3);

    // 범위를 벗어난 값은 인코딩 시 클램프
    std::vector<float> loud = {5.0f, -5.0f};
    bytes = EncodeWav16(loud.data(), 2, 1, 8000);
    CHECK(DecodeWav(bytes.data(), bytes.size(), c));
    CHECK_NEAR((*c.samples)[0], 32767.0 / 32768.0, 1e-4); CHECK_NEAR((*c.samples)[2], -32767.0 / 32768.0, 1e-4);

    // 파일 저장/불러오기
    const std::string path = TempPath("rt.wav");
    CHECK(SaveWav16(path, mono.data(), mono.size(), 1, 22050));
    AudioClip f;
    CHECK(LoadWavFile(path, f) && f.FrameCount() == 1000 && f.sampleRate == 22050);
    CHECK(!LoadWavFile("no_such_file.wav", f) && !f.Valid());
    std::remove(path.c_str());
}

static void TestWavFormats() {
    std::printf("[wav formats]\n");
    AudioClip c;
    { WavSpec s; s.bits = 8; s.data = {0, 128, 255};
      auto b = MakeWav(s);
      CHECK(DecodeWav(b.data(), b.size(), c) && c.FrameCount() == 3);
      CHECK_NEAR((*c.samples)[0], -1.0, 1e-6); CHECK_NEAR((*c.samples)[2], 0.0, 1e-6); CHECK_NEAR((*c.samples)[4], 127.0 / 128.0, 1e-6); }
    { WavSpec s; s.bits = 24; s.data = {0x00, 0x00, 0x80,  0xFF, 0xFF, 0x7F,  0x00, 0x00, 0x40};   // -1.0, ~+1.0, +0.5
      auto b = MakeWav(s);
      CHECK(DecodeWav(b.data(), b.size(), c) && c.FrameCount() == 3);
      CHECK_NEAR((*c.samples)[0], -1.0, 1e-6); CHECK_NEAR((*c.samples)[2], 8388607.0 / 8388608.0, 1e-6); CHECK_NEAR((*c.samples)[4], 0.5, 1e-6); }
    { WavSpec s; s.bits = 32; s.data = {0, 0, 0, 0x80,  0, 0, 0, 0x40};                             // INT32_MIN, 0x40000000
      auto b = MakeWav(s);
      CHECK(DecodeWav(b.data(), b.size(), c) && c.FrameCount() == 2);
      CHECK_NEAR((*c.samples)[0], -1.0, 1e-9); CHECK_NEAR((*c.samples)[2], 0.5, 1e-9); }
    { WavSpec s; s.format = 3; s.bits = 32; float f[4] = {0.25f, -0.75f, 3.0f, NAN}; s.data.resize(sizeof(f)); std::memcpy(s.data.data(), f, sizeof(f));
      auto b = MakeWav(s);
      CHECK(DecodeWav(b.data(), b.size(), c) && c.FrameCount() == 4);
      CHECK_NEAR((*c.samples)[0], 0.25, 1e-9); CHECK_NEAR((*c.samples)[2], -0.75, 1e-9);
      CHECK_NEAR((*c.samples)[4], 1.0, 1e-9);                                                        // 범위 밖은 클램프
      CHECK_NEAR((*c.samples)[6], 0.0, 1e-9); }                                                      // NaN -> 0
    { WavSpec s; s.format = 3; s.bits = 32; s.extensible = true; float f[2] = {0.5f, -0.5f}; s.data.resize(sizeof(f)); std::memcpy(s.data.data(), f, sizeof(f));
      auto b = MakeWav(s);
      CHECK(DecodeWav(b.data(), b.size(), c) && c.FrameCount() == 2);
      CHECK_NEAR((*c.samples)[0], 0.5, 1e-9); }
    { WavSpec s; s.channels = 2; s.data = {0x00, 0x40, 0x00, 0xC0,  0x00, 0x20, 0x00, 0xE0};          // L=0.5 R=-0.5 / L=0.25 R=-0.25
      auto b = MakeWav(s);
      CHECK(DecodeWav(b.data(), b.size(), c) && c.FrameCount() == 2);
      CHECK_NEAR((*c.samples)[0], 0.5, 1e-4); CHECK_NEAR((*c.samples)[1], -0.5, 1e-4); CHECK_NEAR((*c.samples)[2], 0.25, 1e-4); }
    { WavSpec s; s.channels = 3; s.data = {0x00, 0x40, 0x00, 0x20, 0xFF, 0x7F};                       // 3채널: 앞 2채널만 사용
      auto b = MakeWav(s);
      CHECK(DecodeWav(b.data(), b.size(), c) && c.FrameCount() == 1);
      CHECK_NEAR((*c.samples)[0], 0.5, 1e-4); CHECK_NEAR((*c.samples)[1], 0.25, 1e-4); }
    { WavSpec s; s.listChunkBefore = true; s.data = {0x00, 0x40};                                     // LIST(홀수 크기+패딩) 뒤의 data 도 찾는다
      auto b = MakeWav(s);
      CHECK(DecodeWav(b.data(), b.size(), c) && c.FrameCount() == 1); CHECK_NEAR((*c.samples)[0], 0.5, 1e-4); }
    { WavSpec s; s.data = {1, 0, 2, 0, 3, 0, 4, 0}; s.dataSizeOverride = 0xFFFFFFFFll;               // 크기를 모르는 스트리밍 헤더
      auto b = MakeWav(s);
      CHECK(DecodeWav(b.data(), b.size(), c) && c.FrameCount() == 4); }
    { WavSpec s; s.data = {1, 0, 2, 0, 3, 0, 4, 0, 5};                                                // 홀수 바이트 꼬리는 버림
      auto b = MakeWav(s);
      CHECK(DecodeWav(b.data(), b.size(), c) && c.FrameCount() == 4); }
}

static void TestWavMalformed() {
    std::printf("[wav malformed]\n");
    AudioClip c;
    CHECK(!DecodeWav(nullptr, 0, c));
    std::uint8_t one = 0;
    CHECK(!DecodeWav(&one, 1, c));
    const std::vector<std::uint8_t> garbage(500, 0xAB);
    CHECK(!DecodeWav(garbage.data(), garbage.size(), c));
    { WavSpec s; s.format = 2; s.data = {0, 0};                         auto b = MakeWav(s); CHECK(!DecodeWav(b.data(), b.size(), c)); }   // ADPCM
    { WavSpec s; s.channels = 0; s.data = {0, 0};                       auto b = MakeWav(s); CHECK(!DecodeWav(b.data(), b.size(), c)); }
    { WavSpec s; s.channels = 9; s.data = std::vector<std::uint8_t>(18); auto b = MakeWav(s); CHECK(!DecodeWav(b.data(), b.size(), c)); }
    { WavSpec s; s.rate = 0; s.data = {0, 0};                           auto b = MakeWav(s); CHECK(!DecodeWav(b.data(), b.size(), c)); }
    { WavSpec s; s.rate = 10000000; s.data = {0, 0};                    auto b = MakeWav(s); CHECK(!DecodeWav(b.data(), b.size(), c)); }
    { WavSpec s; s.bits = 12; s.data = {0, 0};                          auto b = MakeWav(s); CHECK(!DecodeWav(b.data(), b.size(), c)); }
    { WavSpec s; s.format = 3; s.bits = 16; s.data = {0, 0};            auto b = MakeWav(s); CHECK(!DecodeWav(b.data(), b.size(), c)); }   // 16bit float 는 없음
    { WavSpec s;                                                        auto b = MakeWav(s); CHECK(!DecodeWav(b.data(), b.size(), c)); }   // data 비어 있음
    { WavSpec s; s.data = {0};                                          auto b = MakeWav(s); CHECK(!DecodeWav(b.data(), b.size(), c)); }   // 1바이트 < 1프레임

    WavSpec ok; ok.data = std::vector<std::uint8_t>(200, 1);
    const auto good = MakeWav(ok);
    CHECK(DecodeWav(good.data(), good.size(), c));
    for (std::size_t cut : {0u, 3u, 11u, 12u, 20u, 35u, 43u, 44u})                 // 헤더 중간에서 잘림
        CHECK(!DecodeWav(good.data(), cut, c));
    CHECK(DecodeWav(good.data(), 44 + 100, c) && c.FrameCount() == 50);            // data 가 잘림: 있는 만큼만
    { auto b = good; b[40] = 0xFF; b[41] = 0xFF; b[42] = 0xFF; b[43] = 0x7F;       // data 크기가 파일보다 훨씬 큼
      CHECK(DecodeWav(b.data(), b.size(), c) && c.FrameCount() == 100); }
    { auto b = good; b[16] = 0xFF; b[17] = 0xFF; b[18] = 0xFF; b[19] = 0x7F;       // fmt 크기 거짓말
      CHECK(!DecodeWav(b.data(), b.size(), c)); }
    { WavSpec s; s.extensible = true; s.format = 1; s.data = {0, 0};               // extensible 정상
      auto b = MakeWav(s); CHECK(DecodeWav(b.data(), b.size(), c));
      b.resize(40);                                                               // extensible fmt 가 중간에 끊김
      CHECK(!DecodeWav(b.data(), b.size(), c)); }

    // 퍼징: 정상 파일의 바이트를 무작위로 망가뜨려도 크래시/무한루프가 없다 (ASAN/UBSAN 빌드에서 특히 유효)
    std::mt19937 rng(12345);
    int accepted = 0;
    for (int iter = 0; iter < 4000; ++iter) {
        auto b = good;
        const int edits = 1 + static_cast<int>(rng() % 4);
        for (int e = 0; e < edits; ++e) b[rng() % 60] = static_cast<std::uint8_t>(rng());   // 헤더 영역 집중 공략
        if (rng() % 4 == 0) b.resize(rng() % b.size());
        if (DecodeWav(b.data(), b.size(), c)) { ++accepted; CHECK(c.Valid() && c.samples->size() == c.FrameCount() * 2); }
    }
    CHECK(accepted > 0);
}

// ============================================================================ Mixer
static void TestMixerBasics() {
    std::printf("[mixer basics]\n");
    Mixer m(kRate, 8);
    Render(m, 1);                                                    // 게인 램프 초기화
    const AudioClip clip = ConstClip(0.5f, 1000);
    CHECK(!m.Play(AudioClip{}).Valid());                              // 빈 클립은 재생 안 됨

    VoiceId v = m.Play(clip);
    CHECK(v.Valid() && m.IsPlaying(v) && m.ActiveVoices() == 1);
    auto out = Render(m, 400);
    const float center = 0.5f * std::cos(kPi / 4);                    // 등전력 패닝: 가운데는 각 채널 0.7071
    CHECK_NEAR(out[0], center, 1e-5); CHECK_NEAR(out[1], center, 1e-5);
    CHECK_NEAR(out[2 * 399], center, 1e-5);
    out = Render(m, 1000);                                            // 남은 600 프레임 + 무음
    CHECK(CountNonZeroFrames(out) == 600);
    CHECK(!m.IsPlaying(v) && m.ActiveVoices() == 0);                  // 끝나면 자동으로 해제
    CHECK(m.FramesMixed() == 1u + 400u + 1000u);

    // 패닝
    VoiceId l = m.Play(clip, {1.0f, 1.0f, -1.0f, false});
    out = Render(m, 10);
    CHECK_NEAR(out[0], 0.5, 1e-5); CHECK_NEAR(out[1], 0.0, 1e-5);
    m.Stop(l, 0.0f);
    VoiceId r = m.Play(clip, {1.0f, 1.0f, 1.0f, false});
    out = Render(m, 10);
    CHECK_NEAR(out[0], 0.0, 1e-5); CHECK_NEAR(out[1], 0.5, 1e-5);
    m.Stop(r, 0.0f);

    // 등전력: 어느 패닝에서도 L^2 + R^2 가 같다 (같은 소리 크기로 들림)
    for (int i = -10; i <= 10; ++i) {
        const float pan = static_cast<float>(i) / 10.0f;
        VoiceId id = m.Play(clip, {1.0f, 1.0f, pan, false});
        out = Render(m, 1);
        CHECK_NEAR(out[0] * out[0] + out[1] * out[1], 0.25, 1e-5);
        m.Stop(id, 0.0f);
    }

    // 볼륨 / 범위 밖 값 클램프
    VoiceId h = m.Play(clip, {0.5f, 1.0f, 0.0f, false});
    out = Render(m, 1);
    CHECK_NEAR(out[0], center * 0.5, 1e-5);
    m.Stop(h, 0.0f);
    VoiceId weird = m.Play(clip, {-3.0f, 100.0f, 50.0f, false});      // 음수 볼륨 -> 0, 피치 -> 8, 팬 -> 1
    out = Render(m, 1);
    CHECK_NEAR(out[0], 0.0, 1e-6); CHECK_NEAR(out[1], 0.0, 1e-6);
    m.Stop(weird, 0.0f);

    // 재생 중 파라미터 변경
    VoiceId p = m.Play(clip, {1.0f, 1.0f, 0.0f, true});
    CHECK(m.SetVoiceVolume(p, 0.25f) && m.SetVoicePan(p, -1.0f) && m.SetVoicePitch(p, 2.0f));
    out = Render(m, 1);
    CHECK_NEAR(out[0], 0.5 * 0.25, 1e-5); CHECK_NEAR(out[1], 0.0, 1e-5);
    m.Stop(p, 0.0f);
    CHECK(!m.SetVoiceVolume(p, 1.0f));                                // 멈춘 보이스는 false
    CHECK(!m.SetVoiceVolume(VoiceId{}, 1.0f));
    CHECK(!m.IsPlaying(VoiceId{999, 1}));
    m.Stop(VoiceId{999, 1}); m.Stop(VoiceId{});                       // 잘못된 id 는 안전
}

static void TestMixerPitchAndRate() {
    std::printf("[mixer pitch / sample rate]\n");
    Mixer m(kRate, 8);
    m.Play(ConstClip(0.5f, 1000), {1.0f, 2.0f, 0.0f, false});         // 피치 2배 -> 절반 길이
    CHECK(std::abs(CountNonZeroFrames(Render(m, 2000)) - 500) <= 1);
    m.Play(ConstClip(0.5f, 1000), {1.0f, 0.5f, 0.0f, false});         // 피치 0.5배 -> 두 배 길이
    CHECK(std::abs(CountNonZeroFrames(Render(m, 4000)) - 2000) <= 1);
    m.Play(ConstClip(0.5f, 1000, 24000));                             // 24kHz 클립은 48kHz 믹서에서 2배 길이
    CHECK(std::abs(CountNonZeroFrames(Render(m, 4000)) - 2000) <= 1);
    m.Play(ConstClip(0.5f, 1000, 96000));                             // 96kHz 클립은 절반 길이
    CHECK(std::abs(CountNonZeroFrames(Render(m, 2000)) - 500) <= 1);

    // 보간: 0 -> 1 램프를 절반 속도로 재생하면 샘플 사이가 부드럽게 채워진다
    std::vector<float> ramp = {0.0f, 1.0f, 0.0f};
    m.Play(AudioClip::FromMono(ramp.data(), 3, kRate), {1.0f, 0.5f, -1.0f, false});   // 왼쪽 끝 패닝 = 원본 레벨
    auto out = Render(m, 5);
    CHECK_NEAR(out[0], 0.0, 1e-6); CHECK_NEAR(out[2], 0.5, 1e-6); CHECK_NEAR(out[4], 1.0, 1e-6);
    CHECK_NEAR(out[6], 0.5, 1e-6); CHECK_NEAR(out[8], 0.0, 1e-6);
}

static void TestMixerLoopAndStop() {
    std::printf("[mixer loop / stop / fade]\n");
    Mixer m(kRate, 8);
    VoiceId v = m.Play(ConstClip(0.5f, 100), {1.0f, 1.0f, 0.0f, true});
    Render(m, 5000);
    CHECK(m.IsPlaying(v));                                            // 루프는 계속 재생
    auto out = Render(m, 10);
    CHECK(CountNonZeroFrames(out) == 10);
    m.Stop(v);                                                        // 기본 5ms 페이드
    out = Render(m, 240);                                             // 0.005 * 48000 = 240 프레임
    CHECK(!m.IsPlaying(v));
    CHECK(out[0] > out[2 * 100] && out[2 * 100] > out[2 * 200]);      // 단조 감소
    CHECK_NEAR(out[2 * 239], 0.0, 0.01);
    CHECK(CountNonZeroFrames(Render(m, 100)) == 0);

    VoiceId a = m.Play(ConstClip(0.5f, 1000), {1, 1, 0, true});
    VoiceId b = m.Play(ConstClip(0.5f, 1000), {1, 1, 0, true});
    CHECK(m.ActiveVoices() == 2);
    m.StopAll(0.0f);
    CHECK(m.ActiveVoices() == 0 && !m.IsPlaying(a) && !m.IsPlaying(b));

    // 페이드 중 Stop 을 또 불러도 페이드가 처음부터 다시 시작하지 않는다
    VoiceId c = m.Play(ConstClip(0.5f, 1000), {1, 1, 0, true});
    m.Stop(c, 0.01f); Render(m, 100); m.Stop(c, 0.01f);
    Render(m, 400);
    CHECK(!m.IsPlaying(c));                                           // 480프레임 안에 끝남 (두 번째 Stop 이 연장하지 않음)
}

static void TestMixerStealingAndGenerations() {
    std::printf("[mixer voice stealing / generations]\n");
    Mixer m(kRate, 4);
    const AudioClip clip = ConstClip(0.1f, 100000);
    VoiceId v[4];
    for (auto& x : v) x = m.Play(clip);
    CHECK(m.ActiveVoices() == 4);
    VoiceId extra = m.Play(clip);                                     // 가득 참 -> 가장 오래된(v[0]) 을 훔친다
    CHECK(extra.Valid() && m.ActiveVoices() == 4);
    CHECK(!m.IsPlaying(v[0]) && m.IsPlaying(v[1]) && m.IsPlaying(extra));
    m.Stop(v[0], 0.0f);                                               // 옛 핸들로 Stop -> 새 보이스에 영향 없음
    CHECK(m.IsPlaying(extra));

    m.StopAll(0.0f);
    VoiceId loops[3], once;
    for (auto& x : loops) x = m.Play(clip, {1, 1, 0, true});
    once = m.Play(clip);                                              // 비반복 1개 + 반복 3개로 가득 참
    VoiceId n1 = m.Play(clip);
    CHECK(!m.IsPlaying(once) && m.IsPlaying(loops[0]) && m.IsPlaying(n1));   // 비반복 우선 훔침
    m.StopAll(0.0f);
    for (auto& x : loops) x = m.Play(clip, {1, 1, 0, true});
    VoiceId loop4 = m.Play(clip, {1, 1, 0, true});
    VoiceId n2 = m.Play(clip, {1, 1, 0, true});                       // 전부 반복이면 가장 오래된 것
    CHECK(!m.IsPlaying(loops[0]) && m.IsPlaying(loop4) && m.IsPlaying(n2));

    // 슬롯 재사용: 끝난 뒤 같은 슬롯에 새 보이스가 들어와도 옛 id 는 무효
    Mixer m2(kRate, 1);
    VoiceId first = m2.Play(ConstClip(0.1f, 10));
    Render(m2, 100);
    VoiceId second = m2.Play(ConstClip(0.1f, 100000));
    CHECK(first.index == second.index && first.generation != second.generation);
    CHECK(!m2.IsPlaying(first) && m2.IsPlaying(second));
    m2.Stop(first, 0.0f);
    CHECK(m2.IsPlaying(second));
}

static void TestMixerVolumesAndClipping() {
    std::printf("[mixer volumes / clipping / robustness]\n");
    Mixer m(kRate, 8);
    Render(m, 1);
    const float center = 0.5f * std::cos(kPi / 4);
    VoiceId v = m.Play(ConstClip(0.5f, 100000), {1, 1, 0, true});

    m.SetMasterVolume(0.5f); Render(m, 1);                            // 한 블록 동안 램프 -> 다음 블록부터 정확한 값
    auto out = Render(m, 4);
    CHECK_NEAR(out[0], center * 0.5, 1e-5);
    m.SetBusVolume(AudioBus::Music, 0.0f); out = Render(m, 4);
    CHECK_NEAR(out[0], center * 0.5, 1e-5);                           // 음악 버스는 효과음에 영향 없음
    m.SetBusVolume(AudioBus::Sfx, 0.5f); Render(m, 1); out = Render(m, 4);
    CHECK_NEAR(out[0], center * 0.25, 1e-5);
    CHECK_NEAR(m.MasterVolume(), 0.5, 1e-6); CHECK_NEAR(m.BusVolume(AudioBus::Sfx), 0.5, 1e-6);
    m.SetMasterVolume(-1.0f); CHECK_NEAR(m.MasterVolume(), 0.0, 1e-6);   // 음수 -> 0
    m.SetMasterVolume(1000.0f); CHECK_NEAR(m.MasterVolume(), 8.0, 1e-6);  // 상한
    m.Stop(v, 0.0f);

    // 볼륨 변경은 블록 안에서 선형으로 이어진다 (계단 없음 -> 딸깍 소리 방지)
    Mixer r(kRate, 2);
    r.SetMasterVolume(1.0f); Render(r, 1);
    r.Play(ConstClip(1.0f, 100000), {1, 1, -1.0f, true});             // 왼쪽 끝: 레벨 1.0
    Render(r, 8);
    r.SetMasterVolume(0.0f);
    out = Render(r, 480);
    bool monotonic = true;
    for (int f = 1; f < 480; ++f) if (out[2 * f] > out[2 * (f - 1)] + 1e-6f) monotonic = false;
    CHECK(monotonic && out[0] > 0.99f && out[2 * 479] == 0.0f);

    // 클리핑: 합이 1 을 넘으면 출력은 [-1,1], 피크는 클램프 전 값
    Mixer c(kRate, 8);
    for (int i = 0; i < 4; ++i) c.Play(ConstClip(1.0f, 1000), {1, 1, -1.0f, false});
    out = Render(c, 10);
    CHECK_NEAR(out[0], 1.0, 1e-6);
    CHECK_NEAR(c.PeakLevels().left, 4.0, 1e-4); CHECK_NEAR(c.PeakLevels().right, 0.0, 1e-6);
    Render(c, 2000); Render(c, 100); CHECK_NEAR(c.PeakLevels().left, 0.0, 1e-9);   // 소리가 끝난 뒤의 무음 블록 -> 피크 0 (피크는 '마지막 블록' 기준)

    // NaN/Inf 샘플이 들어 있어도 출력은 유한
    std::vector<float> bad = {NAN, INFINITY, -INFINITY, 0.5f};
    Mixer n(kRate, 2);
    n.Play(AudioClip::FromMono(bad.data(), bad.size(), kRate));
    out = Render(n, 8);
    bool finite = true; for (float s : out) if (!std::isfinite(s) || std::fabs(s) > 1.0f) finite = false;
    CHECK(finite);

    // 0 프레임 / nullptr 요청은 안전
    n.Mix(nullptr, 100); n.Mix(out.data(), 0); n.Mix(out.data(), -5);
    CHECK(true);

    // 결정론: 같은 입력 -> 비트 단위로 같은 출력
    auto run = [] {
        Mixer mm(kRate, 8);
        mm.Play(ConstClip(0.3f, 777), {0.8f, 1.37f, -0.3f, true});
        mm.Play(ConstClip(-0.2f, 123, 22050), {1.0f, 0.9f, 0.7f, false});
        std::vector<float> all;
        for (int i = 0; i < 20; ++i) { auto o = Render(mm, 333); all.insert(all.end(), o.begin(), o.end()); }
        return all;
    };
    CHECK(run() == run());
}

// ============================================================================ 음악 (믹서)
static void TestMixerMusic() {
    std::printf("[mixer music]\n");
    Mixer m(kRate, 4);
    Render(m, 1);
    bool destroyed = false;
    m.PlayMusic(std::make_unique<MemoryStream>(0.25f, 1000, &destroyed));
    CHECK(m.IsMusicPlaying());
    auto out = Render(m, 600);
    CHECK_NEAR(out[0], 0.25, 1e-6); CHECK_NEAR(out[2 * 599], 0.25, 1e-6);
    out = Render(m, 600);                                             // 남은 400 프레임 + 무음
    CHECK(CountNonZeroFrames(out) == 400);
    CHECK(!m.IsMusicPlaying());                                       // 끝난 스트림은 자동 제거
    CHECK(!destroyed); m.Update(); CHECK(destroyed);                  // 파괴는 Update (락 밖) 에서

    // 페이드인: 0 -> 1 선형
    destroyed = false;
    m.PlayMusic(std::make_unique<MemoryStream>(0.5f, 100000, &destroyed), 0.01f);      // 480 프레임
    out = Render(m, 480);
    CHECK_NEAR(out[0], 0.5 * (1.0 / 480.0), 1e-3);
    CHECK_NEAR(out[2 * 239], 0.5 * (240.0 / 480.0), 2e-3);
    CHECK_NEAR(out[2 * 479], 0.5, 2e-3);
    out = Render(m, 4); CHECK_NEAR(out[0], 0.5, 1e-6);

    // 크로스페이드: 같은 크기의 두 곡이 겹치는 동안 합은 일정 (선형 크로스페이드의 성질)
    bool oldGone = false;
    m.PlayMusic(std::make_unique<MemoryStream>(0.5f, 100000), 0.01f);
    out = Render(m, 480);
    double minV = 9, maxV = -9;
    for (int f = 0; f < 480; ++f) { minV = std::min<double>(minV, out[2 * f]); maxV = std::max<double>(maxV, out[2 * f]); }
    CHECK(minV > 0.499 && maxV < 0.501);
    (void)oldGone;
    m.Update(); CHECK(destroyed);                                     // 페이드아웃이 끝난 옛 곡은 제거됨

    // 정지(페이드아웃)
    m.StopMusic(0.01f);
    CHECK(!m.IsMusicPlaying());                                       // 페이드아웃 중에는 '재생 중' 이 아님
    out = Render(m, 480);
    CHECK(out[0] > out[2 * 240] && out[2 * 240] > out[2 * 470]);
    out = Render(m, 10); CHECK(CountNonZeroFrames(out) == 0);

    // 즉시 정지 / 일시정지 (일시정지 중에는 스트림을 읽지 않음)
    int reads = 0;
    m.PlayMusic(std::make_unique<MemoryStream>(0.5f, 100000, nullptr, &reads));
    Render(m, 10);
    const int before = reads;
    m.SetMusicPaused(true); CHECK(m.MusicPaused());
    out = Render(m, 100);
    CHECK(CountNonZeroFrames(out) == 0 && reads == before);
    m.SetMusicPaused(false);
    CHECK(CountNonZeroFrames(Render(m, 10)) == 10);
    m.StopMusic(0.0f);
    CHECK(!m.IsMusicPlaying() && CountNonZeroFrames(Render(m, 10)) == 0);

    // 음악 버스/마스터 볼륨, nullptr 스트림
    m.PlayMusic(nullptr); CHECK(!m.IsMusicPlaying());
    m.PlayMusic(std::make_unique<MemoryStream>(0.5f, 100000));
    m.SetBusVolume(AudioBus::Music, 0.5f); Render(m, 1);
    out = Render(m, 4); CHECK_NEAR(out[0], 0.25, 1e-5);
    m.SetBusVolume(AudioBus::Sfx, 0.0f); Render(m, 1);
    out = Render(m, 4); CHECK_NEAR(out[0], 0.25, 1e-5);               // Sfx 버스는 음악에 영향 없음
    m.StopMusic(0.0f);

    // 버퍼 부족(끝나지 않았는데 데이터가 모자람): 나머지는 무음이고 음악은 계속 '재생 중'
    m.PlayMusic(std::make_unique<MemoryStream>(0.5f, 50, nullptr, nullptr, /*underrun*/ true));
    out = Render(m, 100);
    CHECK(CountNonZeroFrames(out) == 50 && m.IsMusicPlaying());
    m.StopMusic(0.0f);

    // 슬롯 상한: 곡을 연달아 바꿔도 무한히 쌓이지 않는다
    for (int i = 0; i < 20; ++i) m.PlayMusic(std::make_unique<MemoryStream>(0.1f, 100000), 1.0f);
    Render(m, 100);
    CHECK(m.IsMusicPlaying());
    m.StopMusic(0.0f);
}

// ============================================================================ 스트리밍 음악
static void TestStreamingSameRate() {
    std::printf("[streaming music: same rate]\n");
    const std::string path = WriteSineWav("same.wav", kRate, 0.5, 440.0);
    AudioClip ref; CHECK(LoadWavFile(path, ref));

    std::string err;
    auto s = StreamingMusic::Open(path, kRate, false, &err);
    CHECK(s != nullptr);
    if (!s) return;
    CHECK_NEAR(s->DurationSeconds(), 0.5, 1e-6);
    CHECK(s->WaitUntilBuffered(2000));
    auto all = Drain(*s, 100000);
    CHECK(all.size() / 2 == ref.FrameCount());
    CHECK(s->Finished());
    bool same = all.size() == ref.samples->size();
    for (std::size_t i = 0; same && i < all.size(); ++i) if (all[i] != (*ref.samples)[i]) same = false;
    CHECK(same);                                                      // 같은 레이트는 디코딩 결과와 정확히 같다
    CHECK(s->Read(all.data(), 100) == 0 && s->Finished());            // 끝난 뒤 읽기는 0
    std::remove(path.c_str());
}

static void TestStreamingResample() {
    std::printf("[streaming music: resample]\n");
    const std::string path = WriteSineWav("rs.wav", 8000, 1.0, 440.0, 0.8f);
    auto s = StreamingMusic::Open(path, kRate, false);
    CHECK(s != nullptr);
    if (!s) return;
    auto all = Drain(*s, 1000000);
    const std::size_t frames = all.size() / 2;
    CHECK(frames >= 47990 && frames <= 48010);                        // 8000 -> 48000: 길이가 6배
    double maxJump = 0;
    for (std::size_t i = 1; i < frames; ++i) maxJump = std::max<double>(maxJump, std::fabs(all[2 * i] - all[2 * (i - 1)]));
    CHECK(maxJump < 0.07);                                            // 청크 경계에서도 불연속 없음 (440Hz, 진폭 0.8 -> 이론상 ~0.058)
    double peak = 0; for (std::size_t i = 0; i < frames; ++i) peak = std::max<double>(peak, std::fabs(all[2 * i]));
    CHECK(peak > 0.78 && peak < 0.81);
    CHECK(all[0] == all[1]);                                          // 모노 -> 양 채널 동일

    // 다운샘플: 96kHz -> 48kHz
    const std::string p2 = WriteSineWav("rs2.wav", 96000, 0.25, 440.0);
    auto s2 = StreamingMusic::Open(p2, kRate, false);
    CHECK(s2 != nullptr);
    if (s2) { auto a = Drain(*s2, 1000000); CHECK(a.size() / 2 >= 11990 && a.size() / 2 <= 12010); }

    // 아주 낮은 레이트 (1Hz, 4프레임): 청크가 링 버퍼보다 커지는 경우에도 교착 없이 끝난다
    WavSpec tiny; tiny.rate = 1; tiny.data = {0x00, 0x40, 0x00, 0x40, 0x00, 0x40, 0x00, 0x40};
    const std::string p3 = TempPath("tiny.wav");
    { auto b = MakeWav(tiny); std::ofstream f(p3, std::ios::binary); f.write(reinterpret_cast<const char*>(b.data()), static_cast<std::streamsize>(b.size())); }
    auto s3 = StreamingMusic::Open(p3, kRate, false);
    CHECK(s3 != nullptr);
    if (s3) { auto a = Drain(*s3, 1000000, 10000); CHECK(a.size() / 2 >= 140000 && s3->Finished()); }

    std::remove(path.c_str()); std::remove(p2.c_str()); std::remove(p3.c_str());
}

static void TestStreamingLoopAndErrors() {
    std::printf("[streaming music: loop / errors / lifetime]\n");
    const std::string path = WriteSineWav("loop.wav", kRate, 0.1, 440.0);       // 4800 프레임
    auto s = StreamingMusic::Open(path, kRate, true);
    CHECK(s != nullptr);
    if (s) {
        auto all = Drain(*s, 4800 * 5);
        CHECK(all.size() / 2 == 4800 * 5 && !s->Finished());                   // 5바퀴를 돌아도 끝나지 않음
        bool seamless = true;                                                   // 루프 이음매에서 같은 샘플이 다시 시작
        for (int lap = 1; lap < 5; ++lap) if (all[static_cast<std::size_t>(lap) * 4800 * 2] != all[0]) seamless = false;
        CHECK(seamless);
    }

    std::string err;
    CHECK(StreamingMusic::Open("no_such.wav", kRate, false, &err) == nullptr && !err.empty());
    const std::string junk = TempPath("junk.wav");
    { std::ofstream f(junk, std::ios::binary); f << "this is not a wav file at all, just text"; }
    err.clear();
    CHECK(StreamingMusic::Open(junk, kRate, false, &err) == nullptr && !err.empty());
    CHECK(StreamingMusic::Open(path, 100, false) == nullptr);                  // 이상한 출력 레이트
    std::remove(junk.c_str());

    // 데이터가 중간에 잘린 파일: 있는 만큼만 재생하고 정상 종료
    {
        std::vector<float> d(20000, 0.3f);
        auto b = EncodeWav16(d.data(), d.size(), 1, kRate);
        b.resize(44 + 10001);                                                   // 홀수 바이트에서 잘림 (5000 프레임 + 1바이트)
        const std::string tp = TempPath("trunc.wav");
        std::ofstream f(tp, std::ios::binary); f.write(reinterpret_cast<const char*>(b.data()), static_cast<std::streamsize>(b.size())); f.close();
        auto t = StreamingMusic::Open(tp, kRate, false);
        CHECK(t != nullptr);
        if (t) { auto a = Drain(*t, 100000); CHECK(a.size() / 2 == 5000 && t->Finished()); }
        std::remove(tp.c_str());
    }

    // 소멸: 읽지 않고 바로 파괴 / 한 번도 안 읽고 루프 중 파괴 해도 멈추지 않는다
    const auto t0 = std::chrono::steady_clock::now();
    for (int i = 0; i < 50; ++i) { auto x = StreamingMusic::Open(path, kRate, true); }
    CHECK(std::chrono::steady_clock::now() - t0 < std::chrono::seconds(5));

    // 믹서와 함께: 끝까지 재생 -> 자동 제거 -> 스레드 정리
    Mixer m(kRate, 4);
    const std::string p2 = WriteSineWav("mix.wav", kRate, 0.05, 440.0);          // 2400 프레임
    auto st = StreamingMusic::Open(p2, kRate, false);
    CHECK(st != nullptr);
    if (st) {
        st->WaitUntilBuffered(2000);
        m.PlayMusic(std::move(st));
        int guard = 0;
        while (m.IsMusicPlaying() && guard++ < 100) { Render(m, 512); std::this_thread::sleep_for(std::chrono::milliseconds(1)); }
        CHECK(!m.IsMusicPlaying()); m.Update();
    }
    std::remove(path.c_str()); std::remove(p2.c_str());
}

// ============================================================================ 스레드 / 장치
static void TestThreadStress() {
    std::printf("[thread stress: audio thread vs. main thread]\n");
    const std::string path = WriteSineWav("stress.wav", kRate, 0.2, 330.0);
    Mixer m(kRate, 16);
    std::atomic<bool> stop{false};
    std::atomic<long> blocks{0};
    std::thread audio([&] {
        std::vector<float> out(512 * 2);
        while (!stop.load()) { m.Mix(out.data(), 512); ++blocks; std::this_thread::sleep_for(std::chrono::microseconds(200)); }
    });
    const AudioClip clip = ConstClip(0.2f, 3000);
    std::mt19937 rng(7);
    const auto t0 = std::chrono::steady_clock::now();
    std::vector<VoiceId> ids;
    while (std::chrono::steady_clock::now() - t0 < std::chrono::milliseconds(400)) {
        switch (rng() % 8) {
            case 0: case 1: case 2: ids.push_back(m.Play(clip, {1, 0.5f + static_cast<float>(rng() % 20) / 10.0f, 0, (rng() & 1) != 0})); break;
            case 3: if (!ids.empty()) m.Stop(ids[rng() % ids.size()]); break;
            case 4: if (!ids.empty()) m.SetVoiceVolume(ids[rng() % ids.size()], 0.5f); break;
            case 5: { auto s = StreamingMusic::Open(path, kRate, true); if (s) m.PlayMusic(std::move(s), 0.01f); break; }
            case 6: m.SetMasterVolume(static_cast<float>(rng() % 100) / 100.0f); m.SetBusVolume(AudioBus::Music, 0.7f); break;
            default: m.StopMusic(0.005f); m.Update(); break;
        }
        if (ids.size() > 200) ids.clear();
    }
    stop.store(true);
    audio.join();
    m.StopMusic(0.0f); m.Update();
    CHECK(blocks.load() > 10);
    CHECK(true);                                                       // 크래시/교착 없이 여기까지 왔다
    std::remove(path.c_str());
}

static void TestAudioManager() {
    std::printf("[audio manager]\n");
    SDL_setenv("SDL_AUDIODRIVER", "dummy", 1);                         // 소리 장치 없이도 콜백 경로 검증 (SDL 더미 드라이버)
    {
        AudioConfig cfg; cfg.sampleRate = kRate; cfg.bufferFrames = 512; cfg.maxVoices = 8;
        AudioManager am(cfg);
        const bool opened = am.Init();
        CHECK(am.Init() == opened);                                    // 여러 번 호출해도 안전
        CHECK(am.GetMixer().SampleRate() == kRate && am.SampleRate() == kRate);

        VoiceId v = am.PlaySfx(ConstClip(0.3f, 100000), {1, 1, 0, true});
        CHECK(v.Valid());
        if (opened) {
            CHECK(am.HasDevice());
            const auto t0 = std::chrono::steady_clock::now();
            while (am.GetMixer().FramesMixed() < 4800 && std::chrono::steady_clock::now() - t0 < std::chrono::seconds(3))
                std::this_thread::sleep_for(std::chrono::milliseconds(5));
            CHECK(am.GetMixer().FramesMixed() >= 4800);                // 오디오 스레드가 실제로 믹서를 구동한다
        } else {
            std::printf("  (no SDL dummy audio driver here: silent-mode path only)\n");
            CHECK(!am.HasDevice());
        }
        const std::string path = WriteSineWav("am.wav", kRate, 0.5, 440.0);
        CHECK(am.PlayMusic(path, true, 0.0f));
        CHECK(am.GetMixer().IsMusicPlaying());
        CHECK(!am.PlayMusic("no_such_music.wav"));                     // 실패해도 이전 음악 유지
        CHECK(am.GetMixer().IsMusicPlaying());
        am.StopMusic(0.0f);
        CHECK(!am.GetMixer().IsMusicPlaying());
        am.Update();
        am.Shutdown(); am.Shutdown();                                  // 멱등
        CHECK(!am.HasDevice() && am.GetMixer().ActiveVoices() == 0);
        am.PlaySfx(ConstClip(0.3f, 100));                              // 종료 후 호출도 안전 (무음)
        std::remove(path.c_str());
    }
    {   // 장치를 아예 못 여는 환경: 무음 모드
        SDL_setenv("SDL_AUDIODRIVER", "this_driver_does_not_exist", 1);
        AudioManager am;
        CHECK(!am.Init() && !am.HasDevice());
        CHECK(am.PlaySfx(ConstClip(0.3f, 100)).Valid());               // 믹서는 동작
        am.Update();
    }
    SDL_setenv("SDL_AUDIODRIVER", "dummy", 1);
}

int main() {
    TestWavRoundTrip();
    TestWavFormats();
    TestWavMalformed();
    TestMixerBasics();
    TestMixerPitchAndRate();
    TestMixerLoopAndStop();
    TestMixerStealingAndGenerations();
    TestMixerVolumesAndClipping();
    TestMixerMusic();
    TestStreamingSameRate();
    TestStreamingResample();
    TestStreamingLoopAndErrors();
    TestThreadStress();
    TestAudioManager();
    std::printf("\n%d checks, %d failed\n", g_checks, g_fail);
    return g_fail == 0 ? 0 : 1;
}
